import http from 'node:http';
import { makeD1 } from './d1.mjs';
import { seed } from './seed.mjs';
import worker from './worker.test.mjs';
const db = makeD1();
const env = { DB: db, DASHBOARD_PASSWORD: 'pw-test', IP_HASH_SECRET: 'k', ALLOWED_ORIGINS: 'http://localhost:8766' };
const ctx = { waitUntil: p => p };
await worker.fetch(new Request('http://localhost/statistics.json'), env, ctx);   // creates the schema
if (!process.env.NOSEED) { const n = seed(db.raw, { days: 75, sessions: 900, rngSeed: 5 }); console.log('seeded', n, 'sessions'); }
http.createServer(async (req, res) => {
  if (req.url === '/__dump') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ visits: db.raw.prepare('SELECT * FROM visits ORDER BY id').all(), events: db.raw.prepare('SELECT * FROM events ORDER BY id').all() })); }
  const chunks = []; for await (const c of req) chunks.push(c);
  const r = new Request(new URL(req.url, 'http://localhost:8790'), { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) });
  Object.defineProperty(r, 'cf', { value: { country: 'SI', city: 'Ljubljana', region: 'Ljubljana', continent: 'EU', timezone: 'Europe/Ljubljana' } });
  const out = await worker.fetch(r, env, ctx);
  const h = {}; out.headers.forEach((v, k) => { if (k !== 'set-cookie') h[k] = v; });
  const sc = out.headers.getSetCookie(); if (sc.length) h['set-cookie'] = sc;
  res.writeHead(out.status, h); res.end(Buffer.from(await out.arrayBuffer()));
}).listen(8790, () => console.log('listening 8790'));
