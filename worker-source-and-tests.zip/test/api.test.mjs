import { pathToFileURL } from 'node:url';
import { makeD1 } from './d1.mjs';
import { seed } from './seed.mjs';
const W = await import(pathToFileURL(new URL('./worker.test.mjs', import.meta.url).pathname).href);
const worker = W.default;
const db = makeD1();
const env = { DB: db, DASHBOARD_PASSWORD: 'pw-test', IP_HASH_SECRET: 'k' };
const ORIGIN = 'https://pavleradojevic07.github.io';
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => { if (cond) pass++; else { fail++; console.log('FAIL', name, extra); } };

async function call(path, { method = 'GET', body, cookie, cf, ip = '203.0.113.9', ua = 'Mozilla/5.0 (Windows NT 10.0) Chrome/120 Safari/537.36', origin = ORIGIN, form } = {}) {
  const headers = { 'User-Agent': ua, 'CF-Connecting-IP': ip };
  if (origin) headers.Origin = origin;
  if (cookie) headers.Cookie = cookie;
  let b;
  if (form) { b = new URLSearchParams(form); headers['Content-Type'] = 'application/x-www-form-urlencoded'; }
  else if (body !== undefined) { b = JSON.stringify(body); headers['Content-Type'] = 'application/json'; }
  const req = new Request('https://t.example' + path, { method, headers, body: b });
  Object.defineProperty(req, 'cf', { value: cf || { country: 'SI', city: 'Ljubljana', region: 'Ljubljana', continent: 'EU', timezone: 'Europe/Ljubljana' } });
  const res = await worker.fetch(req, env, { waitUntil: p => p });
  return res;
}
const J = async r => r.json();

// ── 1. ingest: old client format still works, new fields stored ─────────────────────────────────
let r = await call('/track', { method: 'POST', body: { browser: 'Chrome', os: 'Win32', device: 'Desktop', referrer: 'Direct', page: '/pavle.radojevic/', entryTime: new Date().toISOString(), previousPage: null, visitorToken: 'legacy-token-1', utm: {} } });
ok('legacy /track accepted', r.status === 200 && (await J(r)).success === true);
r = await call('/track-event', { method: 'POST', body: { type: 'click', label: 'Instagram', url: 'https://instagram.com/x', referrer: 'Direct' } });
ok('legacy /track-event (no token) accepted', r.status === 200);
r = await call('/track', { method: 'POST', body: { page: '/pavle.radojevic/basketball.html', visitorToken: 'tok-new-0001', pvId: 'pv-0001-aaaa', language: 'en-GB', screen: 'md', theme: 'dark', referrer: 'https://www.google.com/', utm: { utm_source: 'Newsletter', utm_medium: 'Email' }, previousPage: null, entryTime: new Date().toISOString() } });
ok('new /track accepted', r.status === 200 && !(await J(r)).skipped);
const row = db.raw.prepare("SELECT * FROM visits WHERE pv_id='pv-0001-aaaa'").get();
ok('new fields stored', row && row.language === 'en-GB' && row.screen === 'md' && row.theme === 'dark' && row.continent === 'EU' && row.region === 'Ljubljana' && typeof row.visitor_hour === 'number', JSON.stringify(row));
ok('referrer normalised', row.referrer === 'google.com', row.referrer);
r = await call('/track-engage', { method: 'POST', body: { pvId: 'pv-0001-aaaa', visitorToken: 'tok-new-0001', active: 42, scroll: 80 } });
ok('engage accepted', r.status === 200 && (await J(r)).skipped !== true);
const row2 = db.raw.prepare("SELECT active_s, max_scroll FROM visits WHERE pv_id='pv-0001-aaaa'").get();
ok('engagement written to the page view', row2.active_s === 42 && row2.max_scroll === 80);
await call('/track-engage', { method: 'POST', body: { pvId: 'pv-0001-aaaa', visitorToken: 'tok-new-0001', active: 10, scroll: 20 } });
ok('engagement only ever grows', db.raw.prepare("SELECT active_s FROM visits WHERE pv_id='pv-0001-aaaa'").get().active_s === 42);
r = await call('/track-engage', { method: 'POST', body: { pvId: 'pv-0001-aaaa', visitorToken: 'tok-new-0001', active: 99999, scroll: 5000 } });
const row3 = db.raw.prepare("SELECT active_s, max_scroll FROM visits WHERE pv_id='pv-0001-aaaa'").get();
ok('engagement values clamped', row3.active_s === 1800 && row3.max_scroll === 100);
r = await call('/track-engage', { method: 'POST', body: { pvId: 'x', visitorToken: 'y' } });
ok('engage with bad payload -> 400', r.status === 400);
r = await call('/track-event', { method: 'POST', body: { type: 'video', label: 'Highlights', url: 'https://youtu.be/x', page: '/pavle.radojevic/basketball.html', visitorToken: 'tok-new-0001', pvId: 'pv-0001-aaaa', meta: { where: 'basketball', bad_key: { a: 1 }, 'Bad Key': 'x' } } });
ok('new event stored', r.status === 200);
const ev = db.raw.prepare("SELECT * FROM events WHERE type='video'").get();
ok('event meta cleaned to scalar keys', ev && ev.visitor_token === 'tok-new-0001' && ev.meta === '{"where":"basketball"}', JSON.stringify(ev));
r = await call('/track-event', { method: 'POST', body: { type: 'hack', label: 'x' } });
ok('unknown event type -> 400', r.status === 400);
r = await call('/track-event', { method: 'POST', body: { type: 'contact', label: 'x', visitorToken: 'never-seen-token' } });
ok('event for an unknown session is skipped', (await J(r)).skipped === true);
r = await call('/track', { method: 'POST', body: { page: '/' }, ua: 'Googlebot/2.1' });
ok('bots skipped', (await J(r)).skipped === true);
r = await call('/track', { method: 'POST', body: { page: '/' }, origin: 'https://evil.example' });
ok('foreign origin refused', r.status === 403);
for (let i = 0; i < 62; i++) await call('/track', { method: 'POST', body: { page: '/', visitorToken: 'flood-' + i + '-xxxx' }, ip: '198.51.100.7' });
ok('page-view flood from one visitor is rate limited', db.raw.prepare("SELECT COUNT(*) c FROM visits WHERE visitor_token LIKE 'flood-%'").get().c === 60);

// ── 2. public statistics contract unchanged ─────────────────────────────────────────────────────
r = await call('/statistics.json', { origin: ORIGIN });
const pub = await J(r);
ok('/statistics.json contract', ['totalVisitors', 'visitorsToday', 'countries', 'citiesCount', 'avgSession', 'returningVisitors', 'liveVisitors', 'liveCountries', 'lastVisitor', 'status'].every(k => k in pub), Object.keys(pub).join());
ok('/statistics.json leaks nothing private', !('pageViews' in pub) && !('sessions' in pub));

// ── 3. auth ────────────────────────────────────────────────────────────────────────────────────
r = await call('/api/overview');
ok('/api requires login', r.status === 401);
r = await call('/dashboard', { method: 'POST', form: { password: 'wrong' } });
ok('wrong password -> 401', r.status === 401);
r = await call('/dashboard', { method: 'POST', form: { password: 'pw-test' } });
ok('right password -> 302 + cookie', r.status === 302 && /dashboard_session=/.test(r.headers.get('Set-Cookie') || ''));
const cookie = (r.headers.get('Set-Cookie') || '').split(';')[0];
r = await call('/dashboard', { cookie });
const html = await r.text();
ok('dashboard page served with CSP nonce and no CDN', r.status === 200 && /script-src 'nonce-[^']+'; style-src/.test(r.headers.get('Content-Security-Policy')) && !/jsdelivr/.test(r.headers.get('Content-Security-Policy')) && html.includes('nonce="') && !html.includes('__NONCE__'));

// ── 4. SQL helpers ─────────────────────────────────────────────────────────────────────────────
const q1 = (sql, ...a) => db.raw.prepare(sql).get(...a);
const loc = ts => q1(`SELECT ${W.localSql('?')} AS l`.replace(/\?/g, "'" + ts + "'")).l;
ok('local time: winter (+1h)', loc('2026-01-15T10:00:00.000Z') === '2026-01-15 11:00:00');
ok('local time: before DST start', loc('2026-03-29T00:59:00.000Z') === '2026-03-29 01:59:00');
ok('local time: DST start (last Sun Mar 01:00 UTC)', loc('2026-03-29T01:00:00.000Z') === '2026-03-29 03:00:00');
ok('local time: summer (+2h)', loc('2026-07-01T10:00:00.000Z') === '2026-07-01 12:00:00');
ok('local time: before DST end', loc('2026-10-25T00:59:00.000Z') === '2026-10-25 02:59:00');
ok('local time: DST end (last Sun Oct 01:00 UTC)', loc('2026-10-25T01:00:00.000Z') === '2026-10-25 02:00:00');
ok('local time: day rolls over', loc('2026-07-01T22:30:00.000Z') === '2026-07-02 00:30:00');
const pg = p => q1(`SELECT ${W.pageSql('?')} AS p`.replace(/\?/g, "'" + p + "'")).p;
ok('page names', pg('/pavle.radojevic/') === 'index' && pg('/pavle.radojevic/index.html') === 'index' && pg('/') === 'index' && pg('/pavle.radojevic/basketball.html') === 'basketball' && pg('/plates.html') === 'plates');
const src = (ref, medium = null, utm = null) => q1(`SELECT ${W.SRC_SQL} AS s FROM (SELECT ? AS referrer, ? AS utm_medium, ? AS utm_source, lower(COALESCE(?,'') || ' ' || COALESCE(?,'')) AS refstr)`, ref, medium, utm, ref, utm).s;
ok('source: direct/search/social/email/internal/other',
  src('Direct') === 'Direct' && src('google.com') === 'Search' && src('l.instagram.com') === 'Social' && src('t.co') === 'Social' && src('Direct', null, 'linkedin') === 'Social' &&
  src('Direct', 'email', 'x') === 'Email' && src('pavleradojevic07.github.io') === 'Internal' && src('microsoft.com') === 'Other' && src('netflix.com') === 'Other' && src('eurobasket.com') === 'Other');

// ── 5. analytics on realistic data ─────────────────────────────────────────────────────────────
db.raw.exec('DELETE FROM visits; DELETE FROM events;');
const nSess = seed(db.raw, { days: 60, sessions: 420, rngSeed: 11 });
const A = async (path, extra = '') => { const res = await call(path + (path.includes('?') ? '&' : '?') + 'range=all' + extra, { cookie }); const body = await res.json(); return { status: res.status, body }; };
const o = await A('/api/overview');
ok('overview 200', o.status === 200, JSON.stringify(o.body).slice(0, 300));
const k = o.body.core.kpi;
const truth = db.raw.prepare("SELECT COUNT(DISTINCT visitor_token) c FROM visits").get().c;
ok('KPI sessions == distinct sessions in DB', k.sessions === truth, `${k.sessions} vs ${truth}`);
ok('KPI views == rows in visits', k.views === db.raw.prepare('SELECT COUNT(*) c FROM visits').get().c);
ok('KPI events == rows in events (all in scope)', k.events === db.raw.prepare('SELECT COUNT(*) c FROM events').get().c, `${k.events}`);
ok('conversions <= sessions, bounced <= sessions', k.conv <= k.sessions && k.bounced <= k.sessions && k.ret_n <= k.sessions);
ok('class counts add up to sessions', o.body.classes.reduce((a, c) => a + c.n, 0) === k.sessions);
ok('series cover the data', o.body.series.views.reduce((a, x) => a + x.views, 0) === k.views);
ok('heatmap covers the sessions', o.body.core.heat.length > 10 && o.body.core.heat.every(h => h.dow >= 0 && h.dow <= 6 && h.hr >= 0 && h.hr <= 23));
ok('options for filters present', o.body.options.countries.length > 5 && o.body.options.sources.length === 6);
ok('funnel is monotonic', (f => f.s1 >= f.s2 && f.s2 >= f.s3 && f.s2 >= f.s4)(o.body.core.funnel), JSON.stringify(o.body.core.funnel));
ok('goals computed', o.body.core.goals.some(g => g.goal === 'Video play') && o.body.core.goals.some(g => g.goal === 'Player sheet download'), JSON.stringify(o.body.core.goals));
const o30 = await A('/api/overview', '').then(() => call('/api/overview?range=30d', { cookie })).then(r => r.json());
ok('30d overview has previous-period bundle', o30.prev && o30.prev.kpi.sessions >= 0 && o30.core.kpi.sessions > 0);
const oday = await (await call('/api/overview?range=today', { cookie })).json();
ok('today range is hourly', oday.series.hourly === true);

// filters change results consistently
for (const [name, qs] of [['country', '&country=RS'], ['device', '&device=Mobile'], ['src', '&src=Social'], ['ret', '&ret=returning'], ['ret new', '&ret=new'], ['lang', '&lang=sl'], ['combo', '&country=SI&device=Desktop&src=Direct&ret=new']]) {
  const x = await A('/api/overview', qs);
  ok(`filter ${name}: 200 and <= unfiltered`, x.status === 200 && x.body.core.kpi.sessions <= k.sessions, `${x.status} ${x.body.error || x.body.core.kpi.sessions}`);
}
const rs = await A('/api/overview', '&country=RS');
const rsTruth = db.raw.prepare("SELECT COUNT(DISTINCT visitor_token) c FROM visits WHERE country='RS'").get().c;
ok('country filter == SQL truth', rs.body.core.kpi.sessions === rsTruth, `${rs.body.core.kpi.sessions} vs ${rsTruth}`);
const ret = await A('/api/overview', '&ret=returning'), nw = await A('/api/overview', '&ret=new');
ok('new + returning == all sessions', ret.body.core.kpi.sessions + nw.body.core.kpi.sessions === k.sessions, `${ret.body.core.kpi.sessions}+${nw.body.core.kpi.sessions} vs ${k.sessions}`);
const soc = await A('/api/overview', '&src=Social'); const dir = await A('/api/overview', '&src=Direct');
ok('source filter keeps whole sessions', soc.body.core.kpi.sessions > 0 && dir.body.core.kpi.sessions > 0 && soc.body.core.kpi.sessions + dir.body.core.kpi.sessions < k.sessions);

for (const ep of ['pages', 'behavior', 'sources', 'audience', 'goals', 'insights', 'sessions']) {
  const x = await A('/api/' + ep, '&device=Mobile&src=Direct');
  ok(`/api/${ep} (filtered) 200`, x.status === 200, `${x.status} ${JSON.stringify(x.body).slice(0, 200)}`);
}
const pages = (await A('/api/pages')).body;
ok('pages: per-page rows with engagement', pages.pages.length >= 4 && pages.pages[0].avg_active > 0 && pages.pages.every(p => p.entrances <= p.views && p.exits <= p.views), JSON.stringify(pages.pages[0]));
ok('pages: transitions + paths', pages.transitions.length > 3 && pages.paths.length > 3 && pages.transitions.every(t => t.src !== t.dst), JSON.stringify(pages.paths.slice(0, 2)));
const beh = (await A('/api/behavior')).body;
ok('behavior: types and labels', beh.types.length >= 6 && beh.labels.faq && beh.labels.globe && beh.funnel.s2 > 0);
const srcs = (await A('/api/sources')).body;
ok('sources: types, referrers, campaigns', srcs.sources.length >= 4 && srcs.referrers.length >= 4 && srcs.campaigns.some(c => c.campaign === 'november-outreach'), JSON.stringify(srcs.campaigns));
const aud = (await A('/api/audience')).body;
ok('audience: countries, devices, languages, local hours', aud.countries.length >= 8 && aud.devices.length >= 3 && aud.langs.length >= 4 && aud.localHours.length >= 6 && aud.returning.length === 2);
const gl = (await A('/api/goals')).body;
ok('goals: list + funnel', gl.goals.length >= 4 && gl.funnel.s1 > 0 && gl.byPage.length > 0);
const gl30 = await (await call('/api/goals?range=30d', { cookie })).json();
ok('goals vs previous period', gl30.hasPrev && gl30.goals.every(g => typeof g.prev === 'number'));
const ins = (await A('/api/insights')).body;
ok('insights produced', ins.insights.length >= 4 && ins.insights.every(i => i.title && ['good', 'warn', 'info'].includes(i.level)), JSON.stringify(ins.insights.map(i => i.title)));
const ins30 = await (await call('/api/insights?range=30d', { cookie })).json();
ok('insights with comparison', ins30.hasPrev === true);

// sessions list + detail
const sl = (await A('/api/sessions', '&limit=20')).body;
ok('sessions list', sl.sessions.length === 20 && sl.total === k.sessions && sl.sessions[0].t0 >= sl.sessions[19].t0);
const acted = (await A('/api/sessions', '&only=goal&limit=200')).body;
ok('"took action" sessions all have goals', acted.sessions.length > 5 && acted.sessions.every(s => s.goals > 0 && s.goal_names.length > 0));
const sid = acted.sessions.find(s => s.pages >= 2).sid;
const sd = (await call('/api/session?sid=' + sid, { cookie }).then(r => r.json()));
ok('session detail: timeline merges views and events in time order', sd.timeline.length >= 3 && sd.timeline.some(t => t.kind === 'view') && sd.timeline.some(t => t.kind === 'event') && sd.timeline.every((t, i, a) => i === 0 || a[i - 1].t <= t.t), JSON.stringify(sd).slice(0, 300));
ok('session detail: attributes', sd.country && sd.device && sd.visitor.length === 8 && sd.goals.length > 0);
ok('session detail: unknown -> 404, bad -> 400', (await call('/api/session?sid=nope-nope', { cookie })).status === 404 && (await call("/api/session?sid=a'b", { cookie })).status === 400);
const legacy = db.raw.prepare("SELECT visitor_token FROM visits WHERE pv_id IS NULL LIMIT 1").get();
ok('legacy (pre-update) sessions still open', (await call('/api/session?sid=' + legacy.visitor_token, { cookie })).status === 200);

// live
const live = await (await call('/api/live', { cookie })).json();
ok('live: active sessions, feed, per-minute', live.active.length >= 3 && live.feed.length >= 3 && Array.isArray(live.perMinute), JSON.stringify(live).slice(0, 200));

// health + export
const hl = await (await call('/api/health', { cookie })).json();
ok('health', hl.visits > 400 && hl.events > 50 && hl.with_engagement > 0 && hl.retentionDays === '365' && hl.hashKeyed === true);
db.raw.prepare("INSERT INTO events (type,label,url,timestamp,visitor_token) VALUES ('click','=HYPERLINK(\"http://x\")','https://x.example',?, ?)").run(new Date().toISOString(), sid);
const csvRes = await call('/api/export?kind=events&range=all', { cookie });
const csvBuf = new Uint8Array(await csvRes.arrayBuffer());
const csv = new TextDecoder('utf-8', { ignoreBOM: true }).decode(csvBuf);
ok('CSV export: UTF-8 BOM, header, injection guard, attachment', csvBuf[0] === 0xEF && csv.startsWith('\ufefftimestamp,sid,type') && csv.includes("\"'=HYPERLINK(") && /attachment; filename="visitors-events-/.test(csvRes.headers.get('Content-Disposition')), csv.slice(0, 80));
const csv2 = await (await call('/api/export?kind=sessions&range=all', { cookie })).text();
ok('CSV sessions rows', csv2.split('\r\n').length > 300);
ok('invalid range -> 400', (await call('/api/overview?range=custom&start=2026-13-01&end=x', { cookie })).status === 400);

// insights rules (pure function)
const base = { kpi: { sessions: 100, views: 200, visitors: 80, engaged: 3000, with_eng: 90, bounced: 75, conv: 5, events: 40, ret_n: 30 }, goals: [{ goal: 'Contact intent', n: 2, sessions: 2 }], bySrc: [{ src: 'Direct', sessions: 70, conv: 2, bounced: 55 }, { src: 'Social', sessions: 30, conv: 3, bounced: 20 }], byCountry: [{ country: 'SI', sessions: 50, conv: 4 }, { country: 'CA', sessions: 8, conv: 2 }],
  byDevice: [{ device: 'Mobile', sessions: 60, conv: 1, bounced: 50 }, { device: 'Desktop', sessions: 40, conv: 4, bounced: 20 }], funnel: { s1: 100, s2: 50, s3: 12, s4: 4, plays: 3, sheet: 0 },
  pages: [{ pg: 'academic', views: 30, m: 25, avg_scroll: 22, s75: 2 }], heat: [{ dow: 2, hr: 18, n: 60 }, { dow: 3, hr: 18, n: 20 }, { dow: 5, hr: 9, n: 20 }], topLabels: [{ type: 'faq', label: 'How can I get in touch?', n: 9 }], langs: [{ lang: 'sl', sessions: 50 }, { lang: 'en', sessions: 40 }] };
const prevB = { kpi: { sessions: 50, conv: 5, ret_n: 0 }, byCountry: [{ country: 'SI' }], goals: [], bySrc: [] };
const titles = W.buildInsights(base, prevB, 40).map(i => i.title).join(' | ');
for (const [name, re] of [['traffic up', /up 100%/], ['direct share', /Direct/], ['mobile gap', /Mobile visitors act less/], ['weak page', /Academic/], ['video', /highlight video/], ['sheet', /player sheet/], ['contact', /started contact/], ['busiest', /Busiest time: Tuesdays, around 18:00/], ['new country', /New countries: Canada/], ['returning', /return visitors/], ['bounce', /bounce/], ['faq', /Most opened FAQ/], ['language', /browser language/]]) ok('insight rule: ' + name, re.test(titles), titles);
ok('insights: empty range handled', W.buildInsights({ kpi: { sessions: 0 } }, null)[0].title === 'No visits in this range');

console.log(`${pass} passed, ${fail} failed (${nSess} synthetic sessions)`);
process.exit(fail ? 1 : 0);
