// Deterministic synthetic traffic, written straight into the tables (so timestamps can be in the past).
function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }
const pick = (r, arr) => { let t = r() * arr.reduce((a, x) => a + x[1], 0); for (const [v, w] of arr) { if ((t -= w) <= 0) return v; } return arr[0][0]; };
const hex = r => Array.from({ length: 64 }, () => '0123456789abcdef'[Math.floor(r() * 16)]).join('');
const uuid = r => Array.from({ length: 24 }, () => '0123456789abcdef'[Math.floor(r() * 16)]).join('');
const COUNTRIES = [
  ['RS', 'Belgrade', 'Central Serbia', 'EU', 'Europe/Belgrade', 'sr', 22], ['SI', 'Ljubljana', 'Ljubljana', 'EU', 'Europe/Ljubljana', 'sl', 20], ['HU', 'Budapest', 'Budapest', 'EU', 'Europe/Budapest', 'hu', 13],
  ['US', 'Madison', 'Wisconsin', 'NA', 'America/Chicago', 'en-US', 12], ['DE', 'Berlin', 'Berlin', 'EU', 'Europe/Berlin', 'de', 7], ['GB', 'London', 'England', 'EU', 'Europe/London', 'en-GB', 5],
  ['HR', 'Zagreb', 'Zagreb', 'EU', 'Europe/Zagreb', 'hr', 5], ['AT', 'Vienna', 'Vienna', 'EU', 'Europe/Vienna', 'de', 4], ['IT', 'Trieste', 'Friuli', 'EU', 'Europe/Rome', 'it', 4], ['BA', 'Sarajevo', 'Sarajevo', 'EU', 'Europe/Sarajevo', 'bs', 3], ['CA', 'Toronto', 'Ontario', 'NA', 'America/Toronto', 'en-CA', 3], ['AU', 'Sydney', 'NSW', 'OC', 'Australia/Sydney', 'en-AU', 2]
];
const REFS = [['Direct', 42], ['google.com', 10], ['l.instagram.com', 9], ['linkedin.com', 8], ['whatsapp-share', 6], ['eurobasket.com', 5], ['kzs.si', 3], ['bing.com', 2], ['github.com', 2], ['email-club', 3]];
const BROWSERS = [['Chrome', 60], ['Safari', 24], ['Firefox', 8], ['Edge', 8]];
const OSES = { Mobile: [['Android', 55], ['iOS', 45]], Desktop: [['Windows', 60], ['macOS', 30], ['Linux', 10]] };
const NEXT = { index: [['basketball', 40], ['academic', 15], ['plates', 18], ['visitors', 4], [null, 45]], basketball: [['academic', 18], ['plates', 8], ['index', 10], [null, 64]],
  academic: [['basketball', 22], ['plates', 8], [null, 70]], plates: [['basketball', 15], ['index', 8], [null, 77]], visitors: [['index', 20], [null, 80]] };
const PATH = { index: '/pavle.radojevic/', basketball: '/pavle.radojevic/basketball.html', academic: '/pavle.radojevic/academic.html', plates: '/pavle.radojevic/plates.html', visitors: '/pavle.radojevic/visitors.html' };
const FAQ = ['What position do you play?', 'How can I get in touch?', 'Are you open to transfer or recruitment conversations?', 'What is your eligibility or graduation timeline?'];
const GLOBE = ['Serbia', 'USA-Texas', 'Germany', 'Japan', 'USA-California', 'Brazil'];

export function seed(raw, { days = 60, sessions = 420, rngSeed = 7, now = Date.now() } = {}) {
  const r = rng(rngSeed);
  const insV = raw.prepare(`INSERT INTO visits (country, city, region, browser, os, device, referrer, page, timestamp, ip_hash, session_duration, visitor_token, utm_source, utm_medium, utm_campaign,
      pv_id, language, screen, theme, continent, visitor_hour, active_s, max_scroll) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const insE = raw.prepare(`INSERT INTO events (type, label, url, referrer, country, city, timestamp, visitor_token, pv_id, page, meta) VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  const pool = Array.from({ length: 70 }, () => hex(r));
  let n = 0;
  const run = (startMs, legacy, force) => {
    const c = force && force.c || pick(r, COUNTRIES.map(x => [x, x[6]]));
    const device = pick(r, [['Mobile', 55], ['Desktop', 42], ['Tablet', 3]]);
    const browser = pick(r, BROWSERS), os = pick(r, OSES[device === 'Tablet' ? 'Mobile' : device]);
    const ip = r() < 0.2 ? pool[Math.floor(r() * pool.length)] : hex(r);
    const ref = pick(r, REFS);
    const utm = ref === 'email-club' ? ['club-mailing', 'email', 'november-outreach'] : ref === 'whatsapp-share' ? ['whatsapp', 'social', 'share'] : [null, null, null];
    const token = uuid(r), screen = device === 'Desktop' ? pick(r, [['lg', 60], ['xl', 25], ['md', 15]]) : pick(r, [['xs', 70], ['sm', 25], ['md', 5]]);
    const theme = r() < 0.7 ? 'dark' : 'light';
    let page = force && force.page || pick(r, [['index', 55], ['basketball', 27], ['academic', 7], ['plates', 9], ['visitors', 2]]);
    let t = startMs, i = 0;
    while (page && i < 7) {
      const pv = uuid(r);
      const basket = page === 'basketball';
      const active = legacy ? null : Math.round((basket ? 40 : 14) * (0.2 + r() * 2.2));
      const scroll = legacy ? null : (page === 'index' ? 100 : Math.min(100, Math.round(10 + r() * (basket ? 105 : 85))));
      insV.run(c[0], c[1], c[2], browser, os, device, i === 0 ? (ref === 'Direct' || ref === 'email-club' || ref === 'whatsapp-share' ? 'Direct' : ref) : 'pavleradojevic07.github.io', PATH[page], new Date(t).toISOString(), ip, 0, token,
        i === 0 ? utm[0] : null, i === 0 ? utm[1] : null, i === 0 ? utm[2] : null, legacy ? null : pv, legacy ? null : c[5], legacy ? null : screen, legacy ? null : theme, c[3], legacy ? null : (new Date(t).getUTCHours() + 5) % 24, active, scroll);
      const ev = (type, label, url, extra = {}) => { insE.run(type, label, url || '', 'Direct', c[0], c[1], new Date(t + 4000 + Math.floor(r() * 20000)).toISOString(), legacy ? null : token, legacy ? null : pv, legacy ? null : PATH[page], extra.meta || null); };
      if (!legacy) {
        if (basket) {
          if (r() < 0.27) ev('video', 'Pavle Radojevic - Highlights 2025/26 (played on site)', 'https://youtu.be/clxgFeRJaLQ');
          if (r() < 0.09) ev('download', 'Player sheet (PDF)', 'files/pavle-radojevic-player-sheet.pdf');
          if (r() < 0.04) ev('contact', 'Recruiting inquiry', 'mailto:pavle.radojevic07@gmail.com', { meta: JSON.stringify({ where: 'profile' }) });
          if (r() < 0.14) ev('faq', FAQ[Math.floor(r() * FAQ.length)]);
          if (r() < 0.1) ev('click', 'Eurobasket Profile', 'https://basketball.eurobasket.com/player/Pavle-Radojevic/686578');
        }
        if (page === 'academic' && r() < 0.2) ev('course', 'Programming 2');
        if (page === 'academic' && r() < 0.07) ev('download', 'Download Project (PDF)', 'files/fleet-procurement-risk.pdf');
        if (page === 'plates' && r() < 0.4) ev('globe', GLOBE[Math.floor(r() * GLOBE.length)]);
        if (page === 'plates' && r() < 0.25) ev('plate', 'Germany');
        if (r() < 0.05) ev('click', 'LinkedIn', 'https://linkedin.com/in/pavle-radojevic-3677b4255/');
        if (r() < 0.05) ev('theme', 'dark to light');
        if (r() < 0.04) ev('search', 'Career highs');
      }
      t += (active || 20) * 1000 + 8000;
      page = pick(r, NEXT[page]);
      i++;
    }
    n++;
  };
  const dow = [0.7, 1, 1.1, 1.1, 1, 0.9, 0.7];
  for (let k = 0; k < sessions; k++) {
    const day = Math.floor(Math.pow(r(), 0.85) * days);
    let d = new Date(now - day * 864e5);
    if (r() > dow[d.getUTCDay()]) d = new Date(d.getTime() - 864e5);
    const hour = pick(r, [[9, 4], [10, 5], [11, 5], [12, 5], [13, 5], [14, 6], [15, 7], [16, 8], [17, 10], [18, 12], [19, 12], [20, 10], [21, 6], [22, 3], [7, 2], [8, 3], [1, 1]]);
    const ts = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), hour - 1, Math.floor(r() * 60), Math.floor(r() * 60));
    if (ts > now - 6 * 60e3) continue;
    run(ts, day > days - 8, null);
  }
  // sessions "live" right now
  for (let k = 0; k < 3; k++) run(now - (60 + k * 70) * 1000, false, { page: ['basketball', 'plates', 'index'][k], c: COUNTRIES[k * 2] });
  return n;
}
