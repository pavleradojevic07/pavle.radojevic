// Minimal Cloudflare D1 stand-in on top of node:sqlite (a real SQLite engine) so the Worker's SQL is genuinely executed.
import { DatabaseSync } from 'node:sqlite';
export function makeD1() {
  const db = new DatabaseSync(':memory:');
  const clean = a => a.map(x => (x === undefined ? null : x));
  class Stmt {
    constructor(sql, args = []) { this.sql = sql; this.args = args; }
    bind(...a) { return new Stmt(this.sql, clean(a)); }
    async run() { const r = db.prepare(this.sql).run(...this.args); return { success: true, results: [], meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } }; }
    async all() { return { success: true, results: db.prepare(this.sql).all(...this.args).map(o => ({ ...o })), meta: {} }; }
    async first() { const r = db.prepare(this.sql).get(...this.args); return r ? { ...r } : null; }
  }
  return { raw: db, prepare: sql => new Stmt(sql), async batch(list) { const out = []; for (const s of list) out.push(await s.all()); return out; } };
}
