// Cloudflare limits a single request to 50 D1 queries (free plan). Count what every endpoint really uses.
import { pathToFileURL } from 'node:url';
import { makeD1 } from './d1.mjs';
import { seed } from './seed.mjs';
const url = pathToFileURL(new URL('./worker.test.mjs', import.meta.url).pathname).href;
let fail = 0; const ok = (n, c, x = '') => { if (!c) { fail++; console.log('FAIL', n, x); } };
function counting(d1) {
  const c = { n: 0 };
  const wrap = s => { const o = { bind: (...a) => wrap(s.bind(...a)), run: () => { c.n++; return s.run(); }, all: () => { c.n++; return s.all(); }, first: () => { c.n++; return s.first(); }, _s: s }; return o; };
  return { c, db: { raw: d1.raw, prepare: sql => wrap(d1.prepare(sql)), batch: list => { c.n += list.length; return d1.batch(list.map(x => x._s || x)); } } };
}
const { c, db } = (() => { const d1 = makeD1(); return counting(d1); })();
// legacy database exactly as the previous Worker created it
db.raw.exec(`CREATE TABLE visits (id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, city TEXT, region TEXT, browser TEXT, os TEXT, device TEXT, referrer TEXT, page TEXT, timestamp TEXT, ip_hash TEXT, session_duration INTEGER DEFAULT 0, visitor_token TEXT, utm_source TEXT, utm_medium TEXT, utm_campaign TEXT, utm_term TEXT, utm_content TEXT);
 CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, label TEXT, url TEXT, referrer TEXT, country TEXT, city TEXT, timestamp TEXT);
 CREATE TABLE login_attempts (ip_hash TEXT, timestamp TEXT);
 INSERT INTO visits (country,city,browser,os,device,referrer,page,timestamp,ip_hash,session_duration,visitor_token) VALUES ('RS','Belgrade','Chrome','Windows','Desktop','Direct','/pavle.radojevic/','2026-10-01T10:00:00.000Z','abc',0,'old-token-1');
 INSERT INTO events (type,label,url,referrer,country,city,timestamp) VALUES ('download','Fleet paper','files/fleet-procurement-risk.pdf','Direct','RS','Belgrade','2026-10-01T10:01:00.000Z');`);
const W = (await import(url + '?cold=1')).default;
const env = { DB: db, DASHBOARD_PASSWORD: 'pw', IP_HASH_SECRET: 'k' };
const req = (p, extra = {}) => { const r = new Request('https://t.example' + p, { headers: { 'User-Agent': 'Mozilla/5.0 Chrome/120', Origin: 'https://pavleradojevic07.github.io', ...extra } }); Object.defineProperty(r, 'cf', { value: { country: 'SI' } }); return r; };
c.n = 0; const first = await W.fetch(req('/statistics.json'), env, { waitUntil() {} });
ok('legacy database migrates on the first request', first.status === 200, String(first.status));
console.log('cold start + migration of an old database:', c.n, 'queries');
ok('cold start migration within budget', c.n <= 40, String(c.n));
const cols = db.raw.prepare('PRAGMA table_info(visits)').all().map(x => x.name);
ok('new columns added, old data kept', ['pv_id', 'language', 'screen', 'theme', 'continent', 'visitor_hour', 'active_s', 'max_scroll'].every(x => cols.includes(x)) && db.raw.prepare('SELECT COUNT(*) c FROM visits').get().c === 1);
c.n = 0; await W.fetch(req('/statistics.json'), env, { waitUntil() {} });
console.log('warm /statistics.json:', c.n, 'queries'); ok('warm public stats small', c.n <= 14, String(c.n));
const login = await W.fetch(Object.assign(new Request('https://t.example/dashboard', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'CF-Connecting-IP': '1.1.1.1' }, body: 'password=pw' }), {}), env, { waitUntil() {} });
const cookie = login.headers.get('Set-Cookie').split(';')[0];
db.raw.exec('DELETE FROM visits; DELETE FROM events;'); seed(db.raw, { days: 60, sessions: 300, rngSeed: 3 });
for (const ep of ['overview', 'insights', 'pages', 'behavior', 'sources', 'audience', 'goals', 'sessions', 'live', 'health', 'options']) {
  c.n = 0; const r = await W.fetch(req(`/api/${ep}?range=30d&device=Mobile&src=Direct&ret=new`, { Cookie: cookie }), env, { waitUntil() {} });
  console.log(`/api/${ep.padEnd(9)} ${r.status}  ${c.n} queries`);
  ok(`/api/${ep} OK and under the 50-query limit`, r.status === 200 && c.n <= 30, `${r.status} ${c.n}`);
}
console.log(fail ? 'FAILED' : 'limits OK'); process.exit(fail ? 1 : 0);
