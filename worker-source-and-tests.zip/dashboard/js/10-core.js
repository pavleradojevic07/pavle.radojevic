(function () {
'use strict';
var $ = function (s, r) { return (r || document).querySelector(s); };
var TZ = 'Europe/Belgrade';

// ---- tiny DOM helper ----------------------------------------------------------
function add(n, kids) {
  if (kids === null || kids === undefined || kids === false) return;
  if (!Array.isArray(kids)) kids = [kids];
  kids.forEach(function (k) {
    if (k === null || k === undefined || k === false) return;
    if (Array.isArray(k)) add(n, k); else n.appendChild(typeof k === 'object' ? k : document.createTextNode(String(k)));
  });
}
function el(tag, props, kids) {
  var n = document.createElement(tag);
  for (var k in (props || {})) {
    var v = props[k];
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'on') { for (var e in v) n.addEventListener(e, v[e]); }
    else if (v !== false && v !== null && v !== undefined) n.setAttribute(k, v === true ? '' : v);
  }
  add(n, kids);
  return n;
}
var NS = 'http://www.w3.org/2000/svg';
function sv(tag, attrs, kids) {
  var n = document.createElementNS(NS, tag);
  for (var k in (attrs || {})) n.setAttribute(k, attrs[k]);
  add(n, kids);
  return n;
}

// ---- formatting ----------------------------------------------------------------
var nf = function (n) { return n === null || n === undefined ? '-' : Math.round(n).toLocaleString('en-GB'); };
var pc = function (a, b, d) { return b > 0 ? (a / b * 100).toFixed(d || 0) + '%' : '-'; };
function dur(s) {
  if (s === null || s === undefined || isNaN(s)) return '-';
  s = Math.round(s);
  if (s < 60) return s + 's';
  var m = Math.floor(s / 60);
  if (m < 60) return m + 'm ' + ('0' + (s % 60)).slice(-2) + 's';
  return Math.floor(m / 60) + 'h ' + ('0' + (m % 60)).slice(-2) + 'm';
}
var dtFmt = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
var tFmt = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
var fullFmt = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, weekday: 'short', day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
var fmtDT = function (i) { return i ? dtFmt.format(new Date(i)) : '-'; };
var fmtT = function (i) { return i ? tFmt.format(new Date(i)) : '-'; };
var fmtFull = function (i) { return i ? fullFmt.format(new Date(i)) : '-'; };
function ago(iso) {
  var s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return s + 's ago';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  return Math.floor(s / 86400) + 'd ago';
}
var regionNames = null;
function cname(code) {
  if (code === 'XK') return 'Kosovo';
  if (code === 'T1') return 'Tor network';
  try { regionNames = regionNames || new Intl.DisplayNames(['en'], { type: 'region' }); return regionNames.of(code) || code; } catch (e) { return code; }
}
var PAGES = { index: 'Home', basketball: 'Basketball', academic: 'Academic', plates: 'Atlas', visitors: 'Visitors', privacy: 'Privacy', terms: 'Terms', cookies: 'Cookies' };
var pname = function (p) { return PAGES[p] || p || '-'; };
var ccBadge = function (code) { return el('span', { class: 'cc', text: code || '??' }); };
var country = function (code, city) { return [ccBadge(code), cname(code) + (city && city !== 'Unknown' ? ', ' + city : '')]; };
var SRC_HINT = { Direct: 'typed, bookmarked, or shared in an app without a source', Search: 'search engines', Social: 'social networks', Email: 'tagged email links', Internal: 'from this site', Other: 'other websites' };

// delta vs previous period (counts: % change, rates: percentage points)
function delta(cur, prev, o) {
  o = o || {};
  if (prev === null || prev === undefined || !S.cmp) return null;
  var up, txt;
  if (o.rate) { var dp = (cur - prev) * 100; if (Math.abs(dp) < 0.05) return el('div', { class: 'd', text: 'same as previous' }); up = dp > 0; txt = (up ? '+' : '') + dp.toFixed(1) + ' pts'; }
  else { if (prev === 0) return cur === 0 ? null : el('div', { class: 'd', text: 'new (was 0)' }); var ch = (cur - prev) / prev * 100; if (Math.abs(ch) < 0.5) return el('div', { class: 'd', text: 'same as previous' }); up = ch > 0; txt = (up ? '+' : '') + ch.toFixed(0) + '%'; }
  var good = o.invert ? !up : up;
  return el('div', { class: 'd ' + (good ? 'up' : 'down'), text: (up ? '\u25B2 ' : '\u25BC ') + txt + ' vs previous' });
}

// ---- state + API ----------------------------------------------------------------
var S = { tab: 'overview', range: '30d', start: '', end: '', cmp: true, f: { country: '', device: '', src: '', ret: '', lang: '' }, seq: 0 };
var cache = {};
function qs(extra) {
  var p = new URLSearchParams();
  p.set('range', S.range);
  if (S.range === 'custom') { p.set('start', S.start); p.set('end', S.end); }
  ['country', 'device', 'src', 'ret', 'lang'].forEach(function (k) { if (S.f[k]) p.set(k, S.f[k]); });
  for (var k in (extra || {})) p.set(k, extra[k]);
  return p.toString();
}
function api(path, extra, o) {
  o = o || {};
  var url = path + '?' + (o.raw ? new URLSearchParams(extra || {}).toString() : qs(extra));
  var hit = cache[url];
  if (!o.fresh && hit && Date.now() - hit.t < 60000) return Promise.resolve(hit.d);
  return fetch(url, { credentials: 'same-origin', cache: 'no-store' }).then(function (res) {
    if (res.status === 401) { window.location.href = '/dashboard'; throw new Error('Session expired'); }
    if (!res.ok) throw new Error(path + ' returned ' + res.status);
    return res.json();
  }).then(function (d) { cache[url] = { t: Date.now(), d: d }; return d; });
}

// ---- building blocks --------------------------------------------------------------
function card(title, body, o) {
  o = o || {};
  return el('section', { class: 'card' + (o.cls ? ' ' + o.cls : '') }, [title ? el('h2', { text: title }) : null, o.sub ? el('div', { class: 'sub', text: o.sub }) : null, body]);
}
function kpi(label, value, d, hint) {
  return el('div', { class: 'card kpi', title: hint || '' }, [el('div', { class: 'v', text: value }), el('div', { class: 'l', text: label }), d]);
}
function bars(items, o) {
  o = o || {};
  var max = Math.max.apply(null, items.map(function (i) { return i.value; }).concat([1]));
  if (!items.length) return el('div', { class: 'note', text: o.empty || 'No data for this range' });
  return el('div', { class: 'bars' }, items.map(function (i) {
    var bar = el('div', { class: 'bar' + (i.on ? ' click' : ''), title: i.title || '' }, [
      el('i', { style: 'width:' + Math.max(1, i.value / max * 100) + '%' }),
      el('span', null, i.label),
      el('b', null, [(o.fmt || nf)(i.value), i.sub ? el('small', { text: i.sub }) : null])
    ]);
    if (i.on) { bar.tabIndex = 0; bar.setAttribute('role', 'button'); bar.addEventListener('click', i.on); bar.addEventListener('keydown', function (e) { if (e.key === 'Enter') i.on(); }); }
    return bar;
  }));
}
function table(cols, data, o) {
  o = o || {};
  var sort = o.sort || null;
  var wrap = el('div', { class: 'tbl-wrap' });
  function draw() {
    var rowsData = data.slice();
    if (sort) { var c = cols[sort.i]; rowsData.sort(function (a, b) { var x = c.v(a), y = c.v(b); if (x === y) return 0; if (x === null || x === undefined) return 1; if (y === null || y === undefined) return -1; return (x > y ? 1 : -1) * sort.dir; }); }
    var head = el('tr', null, cols.map(function (c, i) {
      var th = el('th', { class: (c.cls || '') + (c.v ? ' s' : '') + (sort && sort.i === i ? (sort.dir > 0 ? ' asc' : ' desc') : ''), text: c.h, scope: 'col' });
      if (c.v) { th.tabIndex = 0; var go = function () { sort = { i: i, dir: sort && sort.i === i ? -sort.dir : (c.cls === 'n' ? -1 : 1) }; draw(); }; th.addEventListener('click', go); th.addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); }); }
      return th;
    }));
    var body = rowsData.length ? rowsData.slice(0, o.limit || 500).map(function (r) {
      var tr = el('tr', { class: o.onRow ? 'click' : '' }, cols.map(function (c) { return el('td', { class: c.cls || '' }, c.r(r)); }));
      if (o.onRow) { tr.tabIndex = 0; tr.addEventListener('click', function () { o.onRow(r); }); tr.addEventListener('keydown', function (e) { if (e.key === 'Enter') o.onRow(r); }); }
      return tr;
    }) : [el('tr', null, el('td', { class: 'empty', colspan: cols.length, text: o.empty || 'No data for this range' }))];
    wrap.textContent = '';
    wrap.appendChild(el('table', null, [el('thead', null, head), el('tbody', null, body)]));
  }
  draw();
  return wrap;
}
function chip(text, cls) { return el('span', { class: 'chip ' + (cls || ''), text: text }); }
var CLS_CHIP = { 'High intent': 'hi', Engaged: 'en', Browsed: 'br', Bounced: 'bo' };
var clsChip = function (c) { return chip(c, CLS_CHIP[c]); };

// ---- charts (plain SVG, no library) ----------------------------------------------------
function niceMax(v) { if (v <= 4) return 4; var p = Math.pow(10, Math.floor(Math.log10(v))), f = v / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; }
function lineChart(o) {
  var wrap = el('div', { class: 'chart' });
  var n = o.labels.length;
  if (!n) { wrap.appendChild(el('div', { class: 'note', text: 'No data for this range' })); return wrap; }
  var W = o.w || 900, H = o.h || 230, m = { l: 40, r: 12, t: 10, b: 26 };
  var max = niceMax(Math.max.apply(null, [1].concat.apply([], o.series.map(function (s) { return s.data; }))));
  var X = function (i) { return m.l + (n <= 1 ? (W - m.l - m.r) / 2 : i * (W - m.l - m.r) / (n - 1)); };
  var Y = function (v) { return H - m.b - (v / max) * (H - m.t - m.b); };
  var svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + H, width: '100%', role: 'img', 'aria-label': o.aria || 'Line chart' });
  for (var g = 0; g <= 4; g++) {
    var gy = Y(max * g / 4);
    svg.appendChild(sv('line', { x1: m.l, x2: W - m.r, y1: gy, y2: gy, stroke: '#1e1e2c' }));
    svg.appendChild(sv('text', { x: m.l - 6, y: gy + 3, 'text-anchor': 'end' }, nf(max * g / 4)));
  }
  var step = Math.ceil(n / 8);
  o.labels.forEach(function (l, i) { if ((i % step === 0 && n - 1 - i >= step / 2) || i === n - 1) svg.appendChild(sv('text', { x: X(i), y: H - 8, 'text-anchor': 'middle' }, l)); });
  o.series.forEach(function (s, si) {
    var pts = s.data.map(function (v, i) { return X(i) + ',' + Y(v); });
    if (si === 0 && n > 1) svg.appendChild(sv('polygon', { points: X(0) + ',' + Y(0) + ' ' + pts.join(' ') + ' ' + X(n - 1) + ',' + Y(0), fill: s.color, opacity: '.12' }));
    svg.appendChild(sv('polyline', { points: pts.join(' '), fill: 'none', stroke: s.color, 'stroke-width': 2, 'stroke-linejoin': 'round' }));
    if (n <= 40) s.data.forEach(function (v, i) { svg.appendChild(sv('circle', { cx: X(i), cy: Y(v), r: 2.4, fill: s.color })); });
  });
  var cur = sv('line', { y1: m.t, y2: H - m.b, stroke: '#8f8fa8', 'stroke-dasharray': '3 3', visibility: 'hidden' });
  svg.appendChild(cur);
  var tip = el('div', { class: 'tip', hidden: true });
  var hit = sv('rect', { x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: 'transparent' });
  hit.addEventListener('mousemove', function (e) {
    var box = svg.getBoundingClientRect(), px = (e.clientX - box.left) / box.width * W;
    var i = Math.max(0, Math.min(n - 1, Math.round(n <= 1 ? 0 : (px - m.l) / (W - m.l - m.r) * (n - 1))));
    cur.setAttribute('x1', X(i)); cur.setAttribute('x2', X(i)); cur.setAttribute('visibility', 'visible');
    tip.hidden = false; tip.textContent = '';
    add(tip, [el('b', { text: o.labels[i] }), o.series.map(function (s) { return el('div', null, [el('span', { style: 'color:' + s.color, text: '\u25CF ' }), s.name + ': ' + nf(s.data[i])]); })]);
    var left = X(i) / W * box.width + 12; if (left > box.width - 150) left -= 175;
    tip.style.left = left + 'px'; tip.style.top = '8px';
  });
  hit.addEventListener('mouseleave', function () { tip.hidden = true; cur.setAttribute('visibility', 'hidden'); });
  svg.appendChild(hit);
  wrap.appendChild(svg); wrap.appendChild(tip);
  wrap.appendChild(el('div', { class: 'legend' }, o.series.map(function (s) { return el('span', null, [el('i', { style: 'background:' + s.color }), s.name]); })));
  return wrap;
}
var DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function heatmap(cells) {
  var grid = {}, max = 0;
  cells.forEach(function (c) { grid[c.dow + '_' + c.hr] = c.n; if (c.n > max) max = c.n; });
  var h = el('div', { class: 'heat', role: 'img', 'aria-label': 'Sessions by weekday and hour' });
  h.appendChild(el('div', { class: 'lab hl' }));
  for (var hr = 0; hr < 24; hr++) h.appendChild(el('div', { class: 'hl', text: hr % 3 === 0 ? String(hr) : '' }));
  [1, 2, 3, 4, 5, 6, 0].forEach(function (d) {
    h.appendChild(el('div', { class: 'lab', text: DAYS[d] }));
    for (var hr2 = 0; hr2 < 24; hr2++) {
      var v = grid[d + '_' + hr2] || 0;
      h.appendChild(el('div', { style: 'background:' + (v ? 'rgba(212,168,83,' + (0.12 + 0.88 * v / max).toFixed(2) + ')' : 'rgba(255,255,255,.03)'), title: DAYS[d] + ' ' + hr2 + ':00 - ' + v + ' session' + (v === 1 ? '' : 's') }));
    }
  });
  return el('div', { class: 'tbl-wrap' }, h);
}
function donut(items) {
  var total = items.reduce(function (a, i) { return a + i.value; }, 0);
  var wrap = el('div', { class: 'donut-row' });
  if (!total) return el('div', { class: 'note', text: 'No data for this range' });
  var svg = sv('svg', { viewBox: '0 0 120 120', width: 130, height: 130, role: 'img', 'aria-label': 'Share chart' });
  var C = 2 * Math.PI * 42, off = 0;
  items.forEach(function (i) {
    var len = i.value / total * C;
    svg.appendChild(sv('circle', { cx: 60, cy: 60, r: 42, fill: 'none', stroke: i.color, 'stroke-width': 16, 'stroke-dasharray': len + ' ' + (C - len), 'stroke-dashoffset': -off, transform: 'rotate(-90 60 60)' }));
    off += len;
  });
  svg.appendChild(sv('text', { x: 60, y: 64, 'text-anchor': 'middle', style: 'font-size:15px;fill:#e8e8f0;font-weight:700' }, nf(total)));
  wrap.appendChild(svg);
  wrap.appendChild(el('div', { class: 'legend', style: 'flex-direction:column;margin:0' }, items.map(function (i) { return el('span', null, [el('i', { style: 'background:' + i.color }), i.label + ': ' + nf(i.value) + ' (' + pc(i.value, total) + ')']); })));
  return wrap;
}
function funnel(steps) {
  var top = Math.max(1, steps[0].value);
  var f = el('div', { class: 'funnel' });
  steps.forEach(function (s, i) {
    f.appendChild(el('div', { class: 'fstep' }, [el('i', { style: 'width:' + (s.value / top * 100) + '%' }), el('span', { text: s.label }), el('b', { text: nf(s.value) + ' (' + pc(s.value, top) + ')' })]));
    if (i < steps.length - 1) f.appendChild(el('div', { class: 'fdrop', text: steps[i].value > 0 ? '\u2193 ' + pc(steps[i + 1].value, steps[i].value) + ' continue' : '' }));
  });
  return f;
}
function fillKeys(keys, hourly, range) {
  if (hourly) { var o = []; for (var h = 0; h < 24; h++) o.push(('0' + h).slice(-2)); return o; }
  if (!keys.length) return [];
  var a = new Date(keys[0] + 'T00:00:00Z'), b = new Date(keys[keys.length - 1] + 'T00:00:00Z'), out = [];
  for (var d = a; d <= b && out.length < 800; d = new Date(d.getTime() + 864e5)) out.push(d.toISOString().slice(0, 10));
  return out;
}
