// ---- Pages -----------------------------------------------------------------------------------
var DEPTH = ['#ff8a80', '#f07b3b', '#d4a853', '#3ddc84'];
TABS.pages = { label: 'Pages', load: function () {
  return api('/api/pages').then(function (d) {
    var stack = function (r) {
      if (!r.m) return '-';
      var seg = [r.s0, r.s25, r.s50, r.s75];
      return el('div', { class: 'stack', title: '<25%: ' + r.s0 + ', 25-49%: ' + r.s25 + ', 50-74%: ' + r.s50 + ', 75%+: ' + r.s75 }, seg.map(function (v, i) { return el('i', { style: 'width:' + (v / r.m * 100) + '%;background:' + DEPTH[i] }); }));
    };
    var t = table([
      { h: 'Page', v: function (r) { return r.pg; }, r: function (r) { return el('b', { text: pname(r.pg) }); } },
      { h: 'Views', cls: 'n', v: function (r) { return r.views; }, r: function (r) { return nf(r.views); } },
      { h: 'Sessions', cls: 'n', v: function (r) { return r.sessions; }, r: function (r) { return nf(r.sessions); } },
      { h: 'Entrances', cls: 'n', v: function (r) { return r.entrances; }, r: function (r) { return nf(r.entrances); } },
      { h: 'Exit rate', cls: 'n', v: function (r) { return ratio(r.exits, r.views); }, r: function (r) { return pc(r.exits, r.views); } },
      { h: 'Avg time', cls: 'n', v: function (r) { return r.avg_active; }, r: function (r) { return r.avg_active === null ? '-' : dur(r.avg_active); } },
      { h: 'Avg scroll', cls: 'n', v: function (r) { return r.avg_scroll; }, r: function (r) { return r.avg_scroll === null ? '-' : Math.round(r.avg_scroll) + '%'; } },
      { h: 'How far they scroll', r: stack },
      { h: 'Interactions', cls: 'n', v: function (r) { return r.events; }, r: function (r) { return nf(r.events); } },
      { h: 'Goal actions', cls: 'n', v: function (r) { return r.goals; }, r: function (r) { return nf(r.goals); } }
    ], d.pages, { sort: { i: 1, dir: -1 } });
    var legend = el('div', { class: 'legend' }, ['< 25%', '25-49%', '50-74%', '75%+'].map(function (l, i) { return el('span', null, [el('i', { style: 'background:' + DEPTH[i] }), l]); }));
    var arrow = function (s) { return s.split(' > ').map(pname).join(' \u2192 '); };
    return [card('Page performance', [t, legend], { sub: 'Time and scroll are measured from the updated site script onward. Exit rate = share of views that were the last page of a session.' }),
      el('div', { class: 'grid g-2' }, [
        card('Where visitors go next', bars(d.transitions.map(function (x) { return { label: pname(x.src) + ' \u2192 ' + pname(x.dst), value: x.n }; })), { sub: 'Most common moves from one page to another' }),
        card('Most common journeys', bars(d.paths.map(function (x) { return { label: arrow(x.path), value: x.n }; })), { sub: 'Full page sequences, repeats collapsed' })]),
      card('Landing pages', table([
        { h: 'First page seen', v: function (r) { return r.landing; }, r: function (r) { return pname(r.landing); } },
        { h: 'Sessions', cls: 'n', v: function (r) { return r.sessions; }, r: function (r) { return nf(r.sessions); } },
        { h: 'Bounce rate', cls: 'n', v: function (r) { return ratio(r.bounced, r.sessions); }, r: function (r) { return pc(r.bounced, r.sessions); } }
      ], d.landings, { sort: { i: 1, dir: -1 } }))];
  });
} };

// ---- Interactions ----------------------------------------------------------------------------
var TYPE_TITLES = { video: 'Video plays', download: 'Downloads', contact: 'Contact attempts', click: 'Outbound clicks', faq: 'FAQ questions opened', course: 'Courses opened', plate: 'Plates viewed', globe: 'Atlas countries chosen', search: 'Site search results chosen', theme: 'Theme switches', cta: 'Home page buttons', copy: 'Email copied', interaction: 'Other' };
TABS.behavior = { label: 'Interactions', load: function () {
  return api('/api/behavior').then(function (d) {
    var out = [], typeMap = {}; d.types.forEach(function (t) { typeMap[t.type] = t; });
    var tot = d.types.reduce(function (a, t) { return a + t.n; }, 0);
    out.push(el('div', { class: 'grid g-kpi' }, [
      kpi('Sessions with an interaction', pc(d.sessions.interacted, d.sessions.sessions), null, 'Share of sessions with at least one tracked interaction'),
      kpi('Interactions', nf(tot)), kpi('Video plays', nf((typeMap.video || {}).n || 0)), kpi('Downloads', nf((typeMap.download || {}).n || 0)), kpi('Contact attempts', nf((typeMap.contact || {}).n || 0))
    ]));
    var cards = Object.keys(TYPE_TITLES).filter(function (t) { return d.labels[t] && d.labels[t].length; }).map(function (t) {
      return card(TYPE_TITLES[t], bars(d.labels[t].map(function (x) { return { label: t === 'globe' ? x.label.replace('USA-', 'USA, ') : x.label, value: x.n, sub: x.sessions + ' sess.' }; })), { sub: nf((typeMap[t] || {}).n) + ' in total' });
    });
    out.push(cards.length ? el('div', { class: 'grid g-3' }, cards) : card(null, el('div', { class: 'note', text: 'No interactions yet. They appear once visitors who accepted analytics use the updated site script.' })));
    var types = d.types.map(function (t) { return t.type; }), byP = {};
    d.byPage.forEach(function (x) { (byP[x.pg] = byP[x.pg] || {})[x.type] = x.n; });
    var pgs = Object.keys(byP);
    if (pgs.length) out.push(card('Interactions by page', table([{ h: 'Page', r: function (p) { return el('b', { text: pname(p) }); }, v: function (p) { return p; } }].concat(types.map(function (t) { return { h: TYPE_TITLES[t] || t, cls: 'n', v: function (p) { return byP[p][t] || 0; }, r: function (p) { return byP[p][t] || '-'; } }; })), pgs)));
    return out;
  });
} };

// ---- Sources -----------------------------------------------------------------------------------
var SRC_COLORS = { Direct: '#8f8fa8', Search: '#4da6ff', Social: '#f07b3b', Email: '#d4a853', Internal: '#8a5cf5', Other: '#3ddc84' };
var statCols = function (first) {
  return first.concat([
    { h: 'Sessions', cls: 'n', v: function (r) { return r.sessions; }, r: function (r) { return nf(r.sessions); } },
    { h: 'Bounce', cls: 'n', v: function (r) { return ratio(r.bounced, r.sessions); }, r: function (r) { return pc(r.bounced, r.sessions); } },
    { h: 'Action rate', cls: 'n', v: function (r) { return ratio(r.conv, r.sessions); }, r: function (r) { return pc(r.conv, r.sessions); } },
    { h: 'Avg engaged', cls: 'n', v: function (r) { return ratio(r.engaged, r.with_eng); }, r: function (r) { return r.with_eng ? dur(r.engaged / r.with_eng) : '-'; } }
  ]);
};
TABS.sources = { label: 'Sources', load: function () {
  return api('/api/sources').then(function (d) {
    var total = d.sources.reduce(function (a, x) { return a + x.sessions; }, 0);
    return [
      el('div', { class: 'grid g-2' }, [
        card('Traffic by source type', donut(d.sources.map(function (x) { return { label: x.src, value: x.sessions, color: SRC_COLORS[x.src] || '#8f8fa8' }; }))),
        card('Source types', table(statCols([{ h: 'Type', v: function (r) { return r.src; }, r: function (r) { return el('span', { title: SRC_HINT[r.src] }, [el('b', { text: r.src }), ' ' + pc(r.sessions, total)]); } }]), d.sources, { sort: { i: 1, dir: -1 } }))]),
      card('Referrers and link tags', table(statCols([{ h: 'Referrer / tag', v: function (r) { return r.referrer; }, r: function (r) { return [r.referrer || 'Direct', ' ', chip(r.src)]; } }]), d.referrers, { sort: { i: 1, dir: -1 } }),
        { sub: 'A website name, or the tag you added to a link with ?ref=' }),
      card('Campaigns (UTM)', table(statCols([{ h: 'Source / medium / campaign', v: function (r) { return r.source + r.campaign; }, r: function (r) { return [r.source || '-', ' / ' + (r.medium || '-') + ' / ' + (r.campaign || '-')]; } }]), d.campaigns, { empty: 'No tagged links used yet' })),
      card('Landing page by source', table([{ h: 'Landing page', v: function (r) { return r.landing; }, r: function (r) { return pname(r.landing); } }, { h: 'Source', v: function (r) { return r.src; }, r: function (r) { return r.src; } },
        { h: 'Sessions', cls: 'n', v: function (r) { return r.sessions; }, r: function (r) { return nf(r.sessions); } }, { h: 'Action rate', cls: 'n', v: function (r) { return ratio(r.conv, r.sessions); }, r: function (r) { return pc(r.conv, r.sessions); } }], d.landings, { sort: { i: 2, dir: -1 } })),
      card('Tag the links you share', el('div', { class: 'note' }, ['Links shared in chats and emails usually show up as Direct. Add a tag and they become visible here:', el('br'),
        el('code', { text: 'https://pavleradojevic07.github.io/pavle.radojevic/basketball.html?ref=linkedin' }), el('br'),
        el('code', { text: '...?utm_source=club-mailing&utm_medium=email&utm_campaign=nov-outreach' })]))
    ];
  });
} };

// ---- Audience ----------------------------------------------------------------------------------
function columns(vals, label) {
  var max = Math.max.apply(null, vals.concat([1]));
  return el('div', null, [el('div', { style: 'display:flex;align-items:flex-end;gap:2px;height:110px' }, vals.map(function (v, i) { return el('div', { title: label(i) + ': ' + v, style: 'flex:1;background:#4da6ff;opacity:' + (v ? 0.35 + 0.65 * v / max : 0.12) + ';height:' + Math.max(2, v / max * 100) + '%;border-radius:2px 2px 0 0' }); })),
    el('div', { style: 'display:flex;justify-content:space-between;font-size:.68rem;color:var(--muted);margin-top:.2rem' }, [el('span', { text: '00' }), el('span', { text: '06' }), el('span', { text: '12' }), el('span', { text: '18' }), el('span', { text: '23' })])]);
}
TABS.audience = { label: 'Audience', load: function () {
  return api('/api/audience').then(function (d) {
    var hrs = Array(24).fill(0); d.localHours.forEach(function (x) { hrs[x.hr] = x.n; });
    var cpick = function (code) { return function () { S.f.country = code; syncFilters(); renderAll(); }; };
    var rt = { 0: 'New visitors', 1: 'Returning visitors' };
    return [
      card('Countries', table(statCols([{ h: 'Country', v: function (r) { return r.country; }, r: function (r) { return country(r.country); } }, { h: 'Visitors', cls: 'n', v: function (r) { return r.visitors; }, r: function (r) { return nf(r.visitors); } }]), d.countries, { sort: { i: 2, dir: -1 }, onRow: function (r) { cpick(r.country)(); } }), { sub: 'Click a country to filter the whole dashboard to it' }),
      el('div', { class: 'grid g-2' }, [
        card('Cities', bars(d.cities.slice(0, 12).map(function (x) { return { label: [ccBadge(x.country), x.city], value: x.sessions, sub: pc(x.conv, x.sessions) + ' act' }; }))),
        card('New vs returning', table(statCols([{ h: 'Visitor type', r: function (r) { return rt[r.ret]; }, v: function (r) { return r.ret; } }]), d.returning)),
        card('Devices and screens', bars(d.devices.map(function (x) { return { label: x.device + (x.screen ? ' / ' + x.screen : ''), value: x.sessions, sub: pc(x.conv, x.sessions) + ' act' }; })), { sub: 'xs/sm = phones, md = tablets, lg/xl = desktop screens' }),
        card('Browser language', bars(d.langs.map(function (x) { return { label: x.lang, value: x.sessions, sub: pc(x.conv, x.sessions) + ' act' }; })), { sub: 'First two letters of the browser language' })]),
      el('div', { class: 'grid g-3' }, [card('Browsers', bars(d.browsers.map(function (x) { return { label: x.browser, value: x.sessions }; }))), card('Operating systems', bars(d.os.map(function (x) { return { label: x.os, value: x.sessions }; }))),
        card('Theme and continent', [bars(d.themes.map(function (x) { return { label: x.theme + ' theme', value: x.sessions }; })), el('div', { style: 'height:.7rem' }), bars(d.continents.map(function (x) { return { label: x.continent, value: x.sessions }; }))])]),
      el('div', { class: 'grid g-2' }, [card('Visitor local time of day', columns(hrs, function (i) { return i + ':00'; }), { sub: 'Hour of day where the visitor is (from their IP location, zone not stored)' }),
        card('When it is busy for you', heatmap(d.heat), { sub: 'Belgrade/Ljubljana time' })])
    ];
  });
} };

// ---- Goals -------------------------------------------------------------------------------------
TABS.goals = { label: 'Goals', load: function () {
  return api('/api/goals').then(function (d) {
    var f = d.funnel, out = [];
    out.push(el('div', { class: 'grid g-kpi' }, d.goals.length ? d.goals.map(function (g) { return kpi(g.goal, nf(g.n), d.hasPrev ? delta(g.n, g.prev) : null, g.sessions + ' sessions' + (g.strong ? '' : ' (not counted as an action)')); }) : [card(null, el('div', { class: 'note', text: 'No goal actions in this range yet.' }))]));
    out.push(el('div', { class: 'grid g-2' }, [
      card('Basketball funnel', funnel([{ label: 'All sessions', value: f.s1 }, { label: 'Saw the Basketball page', value: f.s2 }, { label: 'Played the video or scrolled 75%+', value: f.s3 }, { label: 'Took an action (sheet, contact, stats profile)', value: f.s4 }]), { sub: 'Sessions, in order of commitment' }),
      card('Daily goal actions', lineChart({ w: 520, h: 190, labels: d.daily.map(function (x) { return x.k.slice(5); }), series: [{ name: 'Goal actions', color: '#3ddc84', data: d.daily.map(function (x) { return x.n; }) }] }))]));
    var rate = function (r) { return pc(r.conv, r.sessions); };
    out.push(el('div', { class: 'grid g-2' }, [
      card('Action rate by device', table(statCols([{ h: 'Device', v: function (r) { return r.device; }, r: function (r) { return r.device; } }]), d.byDevice, { sort: { i: 1, dir: -1 } })),
      card('Action rate by source', table(statCols([{ h: 'Source', v: function (r) { return r.src; }, r: function (r) { return r.src; } }]), d.bySrc, { sort: { i: 1, dir: -1 } }))]));
    out.push(card('Where goals happen', table([{ h: 'Page', v: function (r) { return r.pg; }, r: function (r) { return pname(r.pg); } }, { h: 'Goal', v: function (r) { return r.goal; }, r: function (r) { return r.goal; } }, { h: 'Count', cls: 'n', v: function (r) { return r.n; }, r: function (r) { return nf(r.n); } }], d.byPage, { sort: { i: 2, dir: -1 } })));
    out.push(card('What counts as a goal', el('div', { class: 'note' }, ['Counted as an action: player sheet and paper downloads, contact (email button, copy email, recruiting inquiry, plate donation offer), video plays and clicks to Eurobasket / KZS / SofaScore / Proballers. Social profile clicks are tracked but not counted as an action. You can change the rules in the GOAL_SQL block at the top of the Worker.'])));
    return out;
  });
} };

// ---- Insights ----------------------------------------------------------------------------------
TABS.insights = { label: 'Insights', load: function () {
  return api('/api/insights').then(function (d) {
    return [el('div', { class: 'note', style: 'margin:0 0 .8rem', text: 'Plain-rule analysis of ' + nf(d.sessions) + ' sessions' + (d.hasPrev && S.cmp ? ', compared with the previous period' : '') + '. Every sentence is computed from your own numbers; nothing is sent anywhere.' }),
      el('div', { class: 'grid g-2' }, d.insights.map(insightCard))];
  });
} };
