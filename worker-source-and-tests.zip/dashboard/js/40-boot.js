// ---- Session detail drawer ---------------------------------------------------------------------
var lastFocus = null;
function closeDrawer() { $('#drawer').hidden = true; $('#scrim').hidden = true; if (lastFocus && lastFocus.focus) lastFocus.focus(); }
function openSession(sid) {
  lastFocus = document.activeElement;
  var body = $('#drawerBody'); body.textContent = 'Loading...';
  $('#drawer').hidden = false; $('#scrim').hidden = false; $('#drawerClose').focus();
  api('/api/session', { sid: sid }, { raw: true }).then(function (d) {
    var fact = function (l, v) { return el('div', null, [el('small', { text: l }), v]); };
    var utm = d.utm || {}, utmTxt = [utm.source, utm.medium, utm.campaign].filter(Boolean).join(' / ');
    var items = d.timeline.map(function (x) {
      if (x.kind === 'view') {
        var pgn = (x.page || '').replace('/pavle.radojevic', '').replace(/^\/+/, '').replace(/\.html$/, '') || 'index';
        return el('div', { class: 'it' }, [el('time', { text: fmtT(x.t) }), el('div', { class: 't', text: 'Viewed ' + pname(pgn) }),
          el('div', { class: 'm' }, [x.active_s !== null && x.active_s !== undefined ? dur(x.active_s) + ' active' : 'no time data', x.scroll !== null && x.scroll !== undefined ? [el('span', { class: 'scrollbar' }, el('i', { style: 'width:' + x.scroll + '%' })), x.scroll + '% scrolled'] : null])]);
      }
      var meta = ''; try { meta = x.meta ? Object.keys(JSON.parse(x.meta)).map(function (k) { return k + ': ' + JSON.parse(x.meta)[k]; }).join(', ') : ''; } catch (e) { meta = ''; }
      return el('div', { class: 'it ev' + (x.goal ? ' goal' : '') }, [el('time', { text: fmtT(x.t) }), el('div', { class: 't' }, [chip(x.type, x.goal ? 'go' : 'en'), ' ' + x.label]),
        el('div', { class: 'm', text: [x.goal ? 'Goal: ' + x.goal : '', x.url, meta].filter(Boolean).join('  |  ') })]);
    });
    body.textContent = '';
    add(body, [
      el('h2', { id: 'drawerTitle' }, country(d.country, d.city)),
      el('div', { class: 'note', style: 'margin:.2rem 0 0', text: fmtFull(d.t0) + '  |  visitor #' + d.visitor + (d.returning ? '  |  returning (' + (d.otherSessions.length + 1) + ' sessions)' : '  |  first visit') }),
      el('div', { style: 'margin-top:.6rem' }, d.goals.length ? d.goals.map(function (g) { return chip(g, 'go'); }) : [chip('no goal action')]),
      el('div', { class: 'facts' }, [
        fact('Device', d.device + (d.screen ? ' (' + d.screen + ' screen)' : '')), fact('Browser / OS', d.browser + ' / ' + d.os), fact('Language', d.language || '-'), fact('Theme', d.theme || '-'),
        fact('Came from', (d.referrer && d.referrer !== 'Direct' ? d.referrer : 'Direct') + (utmTxt ? ' (' + utmTxt + ')' : '')), fact('Region', [d.region, d.continent].filter(Boolean).join(', ') || '-'),
        fact('Local time there', d.visitorHour === null || d.visitorHour === undefined ? '-' : 'about ' + ('0' + d.visitorHour).slice(-2) + ':00'),
        fact('Pages / engaged', d.pages + ' / ' + (d.engaged ? dur(d.engaged) : '-')), fact('Deepest scroll', d.scroll ? d.scroll + '%' : '-'), fact('Interactions', String(d.events))]),
      el('h2', { style: 'font-size:1rem;margin-top:1rem', text: 'What they did' }),
      el('div', { class: 'tl' }, items),
      d.otherSessions.length ? [el('h2', { style: 'font-size:1rem;margin-top:1.2rem', text: 'Other visits from the same visitor' }),
        el('div', { class: 'bars', style: 'margin-top:.5rem' }, d.otherSessions.map(function (o) { return el('div', { class: 'bar click', tabindex: 0, on: { click: function () { openSession(o.sid); }, keydown: function (e) { if (e.key === 'Enter') openSession(o.sid); } } }, [el('span', { text: fmtFull(o.t0) }), el('b', { text: o.pages + (o.pages === 1 ? ' page' : ' pages') })]); }))] : null
    ]);
  }).catch(function (e) { body.textContent = 'Could not load this visit: ' + e.message; });
}
$('#drawerClose').addEventListener('click', closeDrawer);
$('#scrim').addEventListener('click', closeDrawer);
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('#drawer').hidden) closeDrawer(); });

// ---- toolbar ---------------------------------------------------------------------------------------
var RANGES = [['today', 'Today'], ['yesterday', 'Yesterday'], ['7d', '7 days'], ['30d', '30 days'], ['thismonth', 'This month'], ['lastmonth', 'Last month'], ['all', 'All time'], ['custom', 'Custom']];
var FILTERS = [['country', 'All countries'], ['device', 'All devices'], ['src', 'All sources'], ['ret', 'New + returning'], ['lang', 'All languages']];
var FIXED = { device: ['Mobile', 'Desktop', 'Tablet'], src: ['Direct', 'Search', 'Social', 'Email', 'Internal', 'Other'], ret: [['new', 'New visitors'], ['returning', 'Returning visitors']] };
function status(t, err) { var s = $('#status'); s.textContent = t; s.className = 'status' + (err ? ' err' : ''); }
function drawRange() {
  var seg = $('#rangeSeg'); seg.textContent = '';
  RANGES.forEach(function (r) { seg.appendChild(el('button', { type: 'button', class: S.range === r[0] ? 'on' : '', 'aria-pressed': S.range === r[0] ? 'true' : 'false', text: r[1], on: { click: function () { S.range = r[0]; drawRange(); $('#customDates').hidden = r[0] !== 'custom'; if (r[0] !== 'custom' || (S.start && S.end)) renderAll(); } } })); });
}
function fillSelect(sel, opts) {
  var keep = sel.value;
  while (sel.options.length > 1) sel.remove(1);
  opts.forEach(function (o) { var v = Array.isArray(o) ? o[0] : o, t = Array.isArray(o) ? o[1] : o; sel.appendChild(el('option', { value: v, text: t })); });
  sel.value = keep;
}
function syncFilters() { FILTERS.forEach(function (f) { var s = $('#f-' + f[0]); if (s) { s.value = S.f[f[0]] || ''; s.className = S.f[f[0]] ? 'set' : ''; } }); }
function buildFilters() {
  var host = $('#filters');
  FILTERS.forEach(function (f) {
    var sel = el('select', { id: 'f-' + f[0], 'aria-label': f[1] }, [el('option', { value: '', text: f[1] })]);
    sel.addEventListener('change', function () { S.f[f[0]] = sel.value; sel.className = sel.value ? 'set' : ''; renderAll(); });
    host.appendChild(sel);
    if (FIXED[f[0]]) fillSelect(sel, FIXED[f[0]]);
  });
  host.appendChild(el('button', { class: 'btn', type: 'button', text: 'Clear filters', on: { click: function () { S.f = { country: '', device: '', src: '', ret: '', lang: '' }; syncFilters(); renderAll(); } } }));
  api('/api/options', {}, { raw: true }).then(function (o) {
    fillSelect($('#f-country'), o.countries.map(function (c) { return [c, cname(c) + ' (' + c + ')']; }));
    fillSelect($('#f-lang'), o.langs); syncFilters();
  }).catch(function () {});
}

// ---- render loop -------------------------------------------------------------------------------------
var timer = null;
var ORDER = ['overview', 'live', 'sessions', 'pages', 'behavior', 'sources', 'audience', 'goals', 'insights'];
function drawTabs() {
  var nav = $('#tabs'); nav.textContent = '';
  ORDER.forEach(function (t) { nav.appendChild(el('button', { type: 'button', role: 'tab', 'aria-selected': S.tab === t ? 'true' : 'false', id: 'tab-' + t, text: TABS[t].label, on: { click: function () { goTab(t); } } })); });
}
function renderAll(soft) {
  var seq = ++S.seq, tab = TABS[S.tab], y = window.scrollY;
  if (timer) { clearInterval(timer); timer = null; }
  drawTabs();
  if (S.range === 'custom' && (!S.start || !S.end)) { status('Pick a start and an end date.'); return; }
  if (!soft) status('Loading...');
  tab.load().then(function (nodes) {
    if (seq !== S.seq) return;
    var v = $('#view'); v.textContent = ''; add(v, nodes);
    status('Updated ' + new Date().toLocaleTimeString('en-GB'));
    if (soft) window.scrollTo(0, y);
    if (tab.auto) timer = setInterval(function () {
      if (document.hidden || S.tab !== 'live') return;
      tab.load().then(function (n2) { if (S.tab !== 'live') return; var v2 = $('#view'); v2.textContent = ''; add(v2, n2); status('Updated ' + new Date().toLocaleTimeString('en-GB')); }).catch(function () {});
    }, tab.auto);
  }).catch(function (e) { if (seq === S.seq) status('Could not load data: ' + e.message, true); });
}

// ---- boot ------------------------------------------------------------------------------------------------
drawRange(); buildFilters();
$('#refreshBtn').addEventListener('click', function () { cache = {}; SESS.key = ''; renderAll(); });
$('#cmpToggle').addEventListener('change', function (e) { S.cmp = e.target.checked; renderAll(true); });
$('#startDate').addEventListener('change', function (e) { S.start = e.target.value; if (S.start && S.end) renderAll(); });
$('#endDate').addEventListener('change', function (e) { S.end = e.target.value; if (S.start && S.end) renderAll(); });
$('#exportSel').addEventListener('change', function (e) {
  var kind = e.target.value; e.target.value = '';
  if (kind && !(S.range === 'custom' && (!S.start || !S.end))) window.location.href = '/api/export?' + qs({ kind: kind });
});
var h = (location.hash || '').slice(1);
if (TABS[h]) S.tab = h;
window.addEventListener('hashchange', function () { var t = (location.hash || '').slice(1); if (TABS[t] && t !== S.tab) { S.tab = t; renderAll(); } });
renderAll();
})();
