// ---- tabs ----------------------------------------------------------------------------------
var TABS = {};
var ratio = function (a, b) { return b > 0 ? a / b : 0; };
var CLS_COLORS = { 'High intent': '#3ddc84', Engaged: '#4da6ff', Browsed: '#d4a853', Bounced: '#ff8a80' };
function goTab(t) { S.tab = t; if (location.hash !== '#' + t) history.replaceState(null, '', '#' + t); renderAll(); }

function insightCard(i) {
  return el('div', { class: 'card insight ' + i.level }, [el('h3', { text: i.title }), el('p', { text: i.detail }), i.action ? el('div', { class: 'act' }, [el('b', { text: 'Try: ' }), i.action]) : null]);
}

TABS.overview = { label: 'Overview', load: function () {
  return Promise.all([api('/api/overview'), api('/api/insights'), api('/api/health', {}, { raw: true })]).then(function (res) {
    var d = res[0], ins = res[1], hl = res[2], c = d.core, k = c.kpi, p = d.prev ? d.prev.kpi : null, out = [];
    var rs = function (x) { return p ? ratio(x(p), p.sessions) : null; };
    out.push(el('div', { class: 'grid g-kpi' }, [
      kpi('Sessions', nf(k.sessions), delta(k.sessions, p && p.sessions), 'One session = one browser-tab visit'),
      kpi('Unique visitors', nf(k.visitors), delta(k.visitors, p && p.visitors), 'Distinct anonymous visitors (hashed IP); someone who returns counts once'),
      kpi('Page views', nf(k.views), delta(k.views, p && p.views)),
      kpi('Pages / session', ratio(k.views, k.sessions).toFixed(1), delta(ratio(k.views, k.sessions), p ? ratio(p.views, p.sessions) : null)),
      kpi('Avg engaged time', k.with_eng ? dur(k.engaged / k.with_eng) : '-', delta(ratio(k.engaged, k.with_eng), p ? ratio(p.engaged, p.with_eng) : null), 'Time the tab was visible and the visitor was active'),
      kpi('Bounce rate', pc(k.bounced, k.sessions), delta(ratio(k.bounced, k.sessions), rs(function (x) { return x.bounced; }), { rate: true, invert: true }), 'One page, no interaction, under 10 seconds'),
      kpi('Action rate', pc(k.conv, k.sessions), delta(ratio(k.conv, k.sessions), rs(function (x) { return x.conv; }), { rate: true }), 'Sessions that played the video, downloaded a file, started contact or opened a stats profile'),
      kpi('Returning', pc(k.ret_n, k.sessions), delta(ratio(k.ret_n, k.sessions), rs(function (x) { return x.ret_n; }), { rate: true }), 'Sessions from a visitor seen before'),
      kpi('Interactions', nf(k.events), delta(k.events, p && p.events))
    ]));
    // traffic chart
    var vm = {}, em = {}, keys = {};
    d.series.views.forEach(function (x) { vm[x.k] = x; keys[x.k] = 1; });
    d.series.events.forEach(function (x) { em[x.k] = x; keys[x.k] = 1; });
    var ks = fillKeys(Object.keys(keys).sort(), d.series.hourly);
    out.push(card('Traffic and activity', lineChart({
      labels: ks.map(function (x) { return d.series.hourly ? x + ':00' : x.slice(5); }), aria: 'Sessions, visitors and actions over time',
      series: [{ name: 'Sessions', color: '#d4a853', data: ks.map(function (x) { return (vm[x] || {}).sessions || 0; }) },
        { name: 'Visitors', color: '#4da6ff', data: ks.map(function (x) { return (vm[x] || {}).visitors || 0; }) },
        { name: 'Goal actions', color: '#3ddc84', data: ks.map(function (x) { return (em[x] || {}).goals || 0; }) }]
    }), { sub: d.series.hourly ? 'By hour (Belgrade/Ljubljana time)' : 'By day (Belgrade/Ljubljana time)' }));
    // quality + highlights
    var cm = {}; d.classes.forEach(function (x) { cm[x.cls] = x.n; });
    var highlights = ins.insights.slice(0, 3);
    out.push(el('div', { class: 'grid g-2' }, [
      card('Session quality', donut(['High intent', 'Engaged', 'Browsed', 'Bounced'].map(function (n) { return { label: n, value: cm[n] || 0, color: CLS_COLORS[n] }; })), { sub: 'High intent = took a goal action. Engaged = 3+ pages, 1+ min, deep scroll or an interaction.' }),
      card('Highlights', [highlights.length ? highlights.map(function (i) { return el('div', { class: 'insight ' + i.level, style: 'margin-bottom:.8rem;padding-left:.7rem' }, [el('h3', { text: i.title }), el('p', { text: i.detail })]); }) : el('div', { class: 'note', text: 'Not enough data yet.' }),
        el('button', { class: 'btn', type: 'button', text: 'See all insights', on: { click: function () { goTab('insights'); } } })])
    ]));
    out.push(card('When people visit', heatmap(c.heat), { sub: 'Distinct sessions by weekday and hour, Belgrade/Ljubljana time. Darker = busier.' }));
    // top lists
    var pg = (c.pages || []).slice(0, 8).map(function (x) { return { label: pname(x.pg), value: x.views, sub: x.m ? 'scroll ' + Math.round(x.avg_scroll) + '%' : '', on: function () { goTab('pages'); } }; });
    var sr = c.bySrc.map(function (x) { return { label: x.src, value: x.sessions, sub: pc(x.conv, x.sessions) + ' act', title: SRC_HINT[x.src], on: function () { goTab('sources'); } }; });
    var co = c.byCountry.slice(0, 8).map(function (x) { return { label: country(x.country), value: x.sessions, sub: pc(x.conv, x.sessions) + ' act', on: function () { goTab('audience'); } }; });
    var pgl = {}; if (d.prev) (d.prev.goals || []).forEach(function (g) { pgl[g.goal] = g.n; });
    var gl = c.goals.map(function (g) { return { label: g.goal, value: g.n, sub: d.prev && S.cmp ? (g.n >= (pgl[g.goal] || 0) ? '+' : '') + (g.n - (pgl[g.goal] || 0)) + ' vs prev' : g.sessions + ' sess.', on: function () { goTab('goals'); } }; });
    out.push(el('div', { class: 'grid g-2' }, [card('Top pages', bars(pg), { sub: 'Views, with average scroll depth' }), card('Where visitors come from', bars(sr), { sub: 'Sessions and share that took an action' }),
      card('Top countries', bars(co)), card('Goal actions', bars(gl, { empty: 'No goal actions in this range yet' }), { sub: 'Video plays, downloads, contact, profile and social clicks' })]));
    // health
    var cov = ratio(hl.with_engagement, hl.visits);
    out.push(card('Data health', el('div', null, [
      el('div', { class: 'facts' }, [
        el('div', null, [el('small', { text: 'Stored page views' }), nf(hl.visits)]), el('div', null, [el('small', { text: 'Stored interactions' }), nf(hl.events)]),
        el('div', null, [el('small', { text: 'Last page view' }), hl.newest ? ago(hl.newest) : '-']), el('div', null, [el('small', { text: 'Last interaction' }), hl.newest_event ? ago(hl.newest_event) : '-']),
        el('div', null, [el('small', { text: 'With time & scroll data' }), pc(hl.with_engagement, hl.visits)]), el('div', null, [el('small', { text: 'Retention' }), hl.retentionDays === 'never' ? 'kept forever' : hl.retentionDays + ' days']),
        el('div', null, [el('small', { text: 'IP hash' }), hl.hashKeyed ? 'keyed (secure)' : 'unkeyed: set IP_HASH_SECRET'])]),
      el('div', { class: 'note' }, ['To keep your own visits out of the numbers, open ', el('code', { text: 'https://pavleradojevic07.github.io/pavle.radojevic/?notrack=1' }), ' once in each browser you use (',
        el('code', { text: '?notrack=0' }), ' turns tracking back on). ', cov < 0.5 && hl.visits > 20 ? 'Time and scroll data only exist for visits after the updated site script went live.' : ''])
    ])));
    return out;
  });
} };

// ---- Live ------------------------------------------------------------------------------------
TABS.live = { label: 'Live', auto: 15000, load: function () {
  return api('/api/live', {}, { raw: true, fresh: true }).then(function (d) {
    var mins = {}; d.perMinute.forEach(function (x) { mins[x.m] = x.n; });
    var now = new Date(d.now), series = [], labels = [];
    for (var i = 29; i >= 0; i--) { var t = new Date(now.getTime() - i * 60000).toISOString().slice(0, 16); series.push(mins[t] || 0); labels.push(i === 0 ? 'now' : '-' + i + 'm'); }
    var rowsD = d.active;
    return [
      el('div', { class: 'grid g-3' }, [
        card('Active now', [el('div', { class: 'live-n' }, [el('span', { class: 'pulse' }), String(rowsD.length)]), el('div', { class: 'sub', text: 'sessions with a page view in the last 5 minutes' })]),
        card('Page views, last 30 minutes', lineChart({ labels: labels, w: 520, h: 110, series: [{ name: 'Page views', color: '#3ddc84', data: series }], aria: 'Page views per minute' }), { cls: 'wide' })
      ]),
      el('div', { class: 'grid g-2' }, [
        card('Visitors on the site', table([
          { h: 'Visitor', r: function (r) { return country(r.country, r.city); } }, { h: 'Now on', r: function (r) { return pname(r.page); } },
          { h: 'Device', r: function (r) { return r.device; } }, { h: 'Pages', cls: 'n', r: function (r) { return r.pages; } }, { h: 'Last seen', r: function (r) { return ago(r.last); } }
        ], rowsD, { onRow: function (r) { openSession(r.sid); }, empty: 'Nobody on the site right now' }), { sub: 'Click a row for the full visit' }),
        card('Activity feed', el('div', { class: 'feed' }, d.feed.length ? d.feed.map(function (x) {
          return el('div', { class: 'click', tabindex: 0, on: { click: function () { if (x.sid) openSession(x.sid); } } }, [el('time', { text: fmtT(x.t) }), ccBadge(x.country),
            x.kind === 'view' ? ['Viewed ', el('b', { text: pname(x.label) })] : [chip(x.kind, x.goal ? 'go' : 'en'), ' ' + x.label]]);
        }) : el('div', { class: 'note', text: 'No activity in the last hour' })), { sub: 'Last hour, newest first' })
      ])
    ];
  });
} };

// ---- Sessions ----------------------------------------------------------------------------------
var SESS = { only: '', rows: [], total: 0, key: '' };
TABS.sessions = { label: 'Sessions', load: function () {
  var key = qs() + '|' + SESS.only;
  var fresh = SESS.key !== key;
  var req = fresh ? api('/api/sessions', { limit: 50, offset: 0, only: SESS.only }, { fresh: true }) : Promise.resolve({ sessions: SESS.rows, total: SESS.total });
  return req.then(function (d) {
    if (fresh) { SESS.rows = d.sessions; SESS.key = key; }
    SESS.total = d.total;
    var seg = el('div', { class: 'seg' }, [['', 'All sessions'], ['goal', 'Took action'], ['returning', 'Returning'], ['bounced', 'Bounced']].map(function (o) {
      return el('button', { type: 'button', class: SESS.only === o[0] ? 'on' : '', text: o[1], on: { click: function () { SESS.only = o[0]; renderAll(); } } });
    }));
    var t = table([
      { h: 'Started', v: function (r) { return r.t0; }, r: function (r) { return fmtDT(r.t0); } },
      { h: 'Visitor', v: function (r) { return r.country; }, r: function (r) { return [country(r.country, r.city), r.ret ? [' ', chip('returning', 'br')] : null]; } },
      { h: 'Device', v: function (r) { return r.device; }, r: function (r) { return [r.device, el('div', { class: 'note', style: 'margin:0', text: [r.browser, r.os].join(' / ') })]; } },
      { h: 'Source', v: function (r) { return r.src; }, r: function (r) { return [r.src, r.referrer && r.referrer !== 'Direct' ? el('div', { class: 'note', style: 'margin:0', text: r.referrer }) : null]; } },
      { h: 'Journey', r: function (r) { return pname(r.landing) + (r.exit_page && r.exit_page !== r.landing ? ' \u2192 ' + pname(r.exit_page) : ''); } },
      { h: 'Pages', cls: 'n', v: function (r) { return r.pages; }, r: function (r) { return r.pages; } },
      { h: 'Engaged', cls: 'n', v: function (r) { return r.engaged; }, r: function (r) { return r.engaged ? dur(r.engaged) : '-'; } },
      { h: 'Scroll', cls: 'n', v: function (r) { return r.scroll; }, r: function (r) { return r.scroll ? r.scroll + '%' : '-'; } },
      { h: 'Actions', r: function (r) { return (r.goal_names || []).map(function (g) { return chip(g, 'go'); }).concat(r.ev > (r.goal_names || []).length ? [chip(r.ev + ' interactions', 'en')] : []); } },
      { h: 'Quality', v: function (r) { return r.cls; }, r: function (r) { return clsChip(r.cls); } }
    ], SESS.rows, { onRow: function (r) { openSession(r.sid); }, sort: { i: 0, dir: -1 }, empty: 'No sessions match' });
    var more = SESS.rows.length < SESS.total ? el('button', { class: 'btn more', type: 'button', text: 'Load more (' + (SESS.total - SESS.rows.length) + ' left)', on: { click: function () { loadMore(); } } }) : null;
    return [el('div', { class: 'pill-row' }, [seg, el('span', { class: 'note', style: 'margin:0', text: nf(SESS.total) + ' sessions. Click a row to see exactly what that visitor did.' })]), card(null, [t, more])];
  });
} };
function loadMore() {
  api('/api/sessions', { limit: 50, offset: SESS.rows.length, only: SESS.only }, { fresh: true }).then(function (d) { SESS.rows = SESS.rows.concat(d.sessions); renderAll(true); });
}
