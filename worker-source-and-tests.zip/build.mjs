// node build.mjs  ->  worker.js (deploy this) and test/worker.test.mjs (same code + test exports)
import fs from 'node:fs';
const read = f => fs.readFileSync(f, 'utf8').replace(/\r\n/g, '\n');
const esc = s => s.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
let html = read('dashboard/index.html');
const js = fs.readdirSync('dashboard/js').filter(f => f.endsWith('.js')).sort().map(f => read('dashboard/js/' + f)).join('\n');
fs.writeFileSync('dashboard/dashboard.js', js);
html = html.replace('/*__CSS__*/', () => read('dashboard/dashboard.css')).replace('/*__JS__*/', () => js);
const parts = fs.readdirSync('src').filter(f => /^\d+-.*\.js$/.test(f) && !f.includes('.gen.')).sort();
const dash = '// -- Dashboard page (HTML + CSS + JS, served at /dashboard) ----------------------\nconst DASHBOARD_TEMPLATE = `' + esc(html) + '`;\n\n';
let out = '';
for (const f of parts) { if (f.startsWith('60-')) out += dash; out += read('src/' + f).trimEnd() + '\n\n'; }
out = out.replace(/\n{3,}/g, '\n\n');
fs.writeFileSync('worker.js', out);
fs.mkdirSync('test', { recursive: true });
fs.writeFileSync('test/worker.test.mjs', out + '\nexport { localSql, pageSql, buildInsights, scope, SRC_SQL, GOAL_SQL, cleanMeta, hourInZone };\n');
console.log('worker.js', out.length, 'bytes,', out.split('\n').length, 'lines');
