// ---------------------------------------------------------------------------------------------
// Visitor Tracker v2: Cloudflare Worker + D1  (single file: paste it into the Worker editor and Deploy)
//
// Public:    POST /track, /track-event, /track-engage  (from assets/site.js, after the visitor accepted analytics)
//            GET  /statistics.json                      (aggregates for the Visitors page; unchanged contract)
// Private:   GET  /dashboard  (password)  and  GET /api/*  (same session cookie)
//
// Required:  DB (D1 binding), DASHBOARD_PASSWORD (secret)
// Optional:  IP_HASH_SECRET   (secret, strongly recommended: keys the IP hash)
//            SESSION_SECRET   (secret; defaults to DASHBOARD_PASSWORD)
//            ALLOWED_ORIGINS  (comma-separated extra origins, e.g. http://localhost:8000)
//            RETENTION_DAYS   (default 365; "never" disables the purge)
// Cron trigger (optional but recommended): daily, runs the retention purge.
// Tables and new columns are created / migrated automatically on the first request.
// ---------------------------------------------------------------------------------------------

const TIMEZONE = 'Europe/Belgrade';
const SITE_ORIGINS = ['https://pavleradojevic07.github.io'];
const SELF_HOSTS = ['pavleradojevic07.github.io'];
const SESSION_COOKIE = 'dashboard_session';
const SESSION_TTL_SECONDS = 3600;
const LOGIN_MAX_FAILURES = 8;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const DEFAULT_RETENTION_DAYS = 365;
const MAX_BODY_BYTES = 4096;
const GEO_OK = "country NOT IN ('Unknown', 'XX', 'T1')";
const BOT_RE = /bot|crawl|spider|slurp|headless|lighthouse|pingdom|monitor|preview/i;

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const enc = new TextEncoder();

// ── Country names / flags ────────────────────────────────────────────────────
// Names are kept exactly as before (they are matched against the map's GeoJSON).
// Any code missing from this list falls back to Intl.DisplayNames, and flags are
// computed from the country code, so every country is covered.
const countryNameMap = {
  'AF': 'Afghanistan', 'AL': 'Albania', 'DZ': 'Algeria', 'AR': 'Argentina', 'AM': 'Armenia',
  'AU': 'Australia', 'AT': 'Austria', 'AZ': 'Azerbaijan', 'BH': 'Bahrain', 'BD': 'Bangladesh',
  'BY': 'Belarus', 'BE': 'Belgium', 'BO': 'Bolivia', 'BA': 'Bosnia and Herzegovina',
  'BR': 'Brazil', 'BG': 'Bulgaria', 'KH': 'Cambodia', 'CM': 'Cameroon', 'CA': 'Canada',
  'CL': 'Chile', 'CN': 'China', 'CO': 'Colombia', 'CR': 'Costa Rica', 'HR': 'Croatia',
  'CU': 'Cuba', 'CY': 'Cyprus', 'CZ': 'Czech Republic', 'DK': 'Denmark', 'DO': 'Dominican Republic',
  'EC': 'Ecuador', 'EG': 'Egypt', 'SV': 'El Salvador', 'EE': 'Estonia', 'ET': 'Ethiopia',
  'FI': 'Finland', 'FR': 'France', 'GE': 'Georgia', 'DE': 'Germany', 'GH': 'Ghana',
  'GR': 'Greece', 'GT': 'Guatemala', 'HN': 'Honduras', 'HK': 'Hong Kong', 'HU': 'Hungary',
  'IS': 'Iceland', 'IN': 'India', 'ID': 'Indonesia', 'IR': 'Iran', 'IQ': 'Iraq',
  'IE': 'Ireland', 'IL': 'Israel', 'IT': 'Italy', 'JM': 'Jamaica', 'JP': 'Japan',
  'JO': 'Jordan', 'KZ': 'Kazakhstan', 'KE': 'Kenya', 'KW': 'Kuwait', 'LV': 'Latvia',
  'LB': 'Lebanon', 'LY': 'Libya', 'LT': 'Lithuania', 'LU': 'Luxembourg', 'MY': 'Malaysia',
  'MX': 'Mexico', 'MD': 'Moldova', 'MN': 'Mongolia', 'ME': 'Montenegro', 'MA': 'Morocco',
  'MM': 'Myanmar', 'NP': 'Nepal', 'NL': 'Netherlands', 'NZ': 'New Zealand', 'NG': 'Nigeria',
  'KP': 'North Korea', 'MK': 'North Macedonia', 'NO': 'Norway', 'OM': 'Oman', 'PK': 'Pakistan',
  'PS': 'Palestine', 'PA': 'Panama', 'PY': 'Paraguay', 'PE': 'Peru', 'PH': 'Philippines',
  'PL': 'Poland', 'PT': 'Portugal', 'PR': 'Puerto Rico', 'QA': 'Qatar', 'RO': 'Romania',
  'RU': 'Russia', 'SA': 'Saudi Arabia', 'SN': 'Senegal', 'RS': 'Serbia', 'SG': 'Singapore',
  'SK': 'Slovakia', 'SI': 'Slovenia', 'ZA': 'South Africa', 'KR': 'South Korea', 'ES': 'Spain',
  'LK': 'Sri Lanka', 'SD': 'Sudan', 'SE': 'Sweden', 'CH': 'Switzerland', 'SY': 'Syria',
  'TW': 'Taiwan', 'TZ': 'Tanzania', 'TH': 'Thailand', 'TN': 'Tunisia', 'TR': 'Turkey',
  'UG': 'Uganda', 'UA': 'Ukraine', 'AE': 'United Arab Emirates', 'GB': 'United Kingdom',
  'US': 'United States of America', 'UY': 'Uruguay', 'UZ': 'Uzbekistan', 'VE': 'Venezuela',
  'VN': 'Vietnam', 'YE': 'Yemen', 'ZW': 'Zimbabwe', 'SS': 'South Sudan', 'GA': 'Gabon', 'AD': 'Andorra',
  'LI': 'Liechtenstein', 'MC': 'Monaco', 'SM': 'San Marino', 'VA': 'Vatican City', 'BS': 'Bahamas',
  'BB': 'Barbados', 'BZ': 'Belize', 'BJ': 'Benin', 'BT': 'Bhutan', 'BW': 'Botswana', 'BF': 'Burkina Faso',
  'BI': 'Burundi', 'CV': 'Cape Verde', 'CF': 'Central African Republic', 'TD': 'Chad', 'KM': 'Comoros',
  'CG': 'Congo', 'CD': 'DR Congo', 'CI': "Côte d'Ivoire", 'DJ': 'Djibouti', 'DM': 'Dominica',
  'GQ': 'Equatorial Guinea', 'ER': 'Eritrea', 'SZ': 'Eswatini', 'FJ': 'Fiji', 'GM': 'Gambia',
  'GD': 'Grenada', 'GN': 'Guinea', 'GW': 'Guinea-Bissau', 'GY': 'Guyana', 'HT': 'Haiti',
  'KI': 'Kiribati', 'LA': 'Laos', 'LS': 'Lesotho', 'LR': 'Liberia', 'MG': 'Madagascar',
  'MW': 'Malawi', 'MV': 'Maldives', 'ML': 'Mali', 'MT': 'Malta', 'MH': 'Marshall Islands',
  'MR': 'Mauritania', 'MU': 'Mauritius', 'FM': 'Micronesia', 'MZ': 'Mozambique', 'NA': 'Namibia',
  'NR': 'Nauru', 'NI': 'Nicaragua', 'NE': 'Niger', 'PW': 'Palau', 'PG': 'Papua New Guinea', 'RW': 'Rwanda',
  'KN': 'Saint Kitts and Nevis', 'LC': 'Saint Lucia', 'VC': 'Saint Vincent and the Grenadines',
  'WS': 'Samoa', 'ST': 'Sao Tome and Principe', 'SC': 'Seychelles', 'SL': 'Sierra Leone', 'SB': 'Solomon Islands',
  'SR': 'Suriname', 'TL': 'Timor-Leste', 'TG': 'Togo', 'TO': 'Tonga', 'TT': 'Trinidad and Tobago',
  'TM': 'Turkmenistan', 'TV': 'Tuvalu', 'VU': 'Vanuatu', 'ZM': 'Zambia'
};

let regionNames = null;
function countryName(code) {
  if (countryNameMap[code]) return countryNameMap[code];
  if (/^[A-Z]{2}$/.test(code)) {
    try {
      regionNames = regionNames || new Intl.DisplayNames(['en'], { type: 'region' });
      const n = regionNames.of(code);
      if (n && n !== code) return n;
    } catch (e) { /* fall through */ }
  }
  return code;
}

function flagFor(code) {
  if (!/^[A-Z]{2}$/.test(code) || code === 'XX') return '🏳️';
  return String.fromCodePoint(...[...code].map(ch => 0x1F1E6 + ch.charCodeAt(0) - 65));
}

// ── Small utilities ──────────────────────────────────────────────────────────
const pad = n => String(n).padStart(2, '0');

function toHex(bytes) {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function sha256Bytes(str) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(str)));
}

async function sha256Hex(str) {
  return toHex(await sha256Bytes(str));
}

async function hmacHex(secret, message) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return toHex(new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(message))));
}

// Constant-time comparison (hashes first so lengths never leak)
async function safeEqual(a, b) {
  const [ha, hb] = await Promise.all([sha256Bytes(String(a)), sha256Bytes(String(b))]);
  let diff = 0;
  for (let i = 0; i < ha.length; i++) diff |= ha[i] ^ hb[i];
  return diff === 0;
}

function b64url(bytes) {
  let s = '';
  bytes.forEach(b => { s += String.fromCharCode(b); });
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function cleanStr(v, max, fallback = '') {
  if (typeof v !== 'string') return fallback;
  const s = v.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
  return s || fallback;
}

function parseCookies(header) {
  const out = {};
  (header || '').split(';').forEach(part => {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  });
  return out;
}

function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ── Time zone handling (Belgrade days, DST-aware) ────────────────────────────
const partsFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: TIMEZONE, hourCycle: 'h23',
  year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit'
});

function zonedParts(date) {
  const o = {};
  for (const p of partsFmt.formatToParts(date)) if (p.type !== 'literal') o[p.type] = parseInt(p.value, 10);
  return o;
}

function tzOffsetMs(date) {
  const p = zonedParts(date);
  const asUTC = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return asUTC - Math.floor(date.getTime() / 1000) * 1000;
}

function dayString(date) {
  const p = zonedParts(date);
  return `${p.year}-${pad(p.month)}-${pad(p.day)}`;
}

function addDays(day, n) {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

function daysBetween(a, b) {
  const [ay, am, ad] = a.split('-').map(Number);
  const [by, bm, bd] = b.split('-').map(Number);
  return Math.round((Date.UTC(by, bm - 1, bd) - Date.UTC(ay, am - 1, ad)) / 864e5);
}

// The UTC instant at which a Belgrade calendar day begins
function localMidnightToUTC(day) {
  const [y, m, d] = day.split('-').map(Number);
  const guess = Date.UTC(y, m - 1, d);
  const off1 = tzOffsetMs(new Date(guess));
  let utc = guess - off1;
  const off2 = tzOffsetMs(new Date(utc));
  if (off2 !== off1) utc = guess - off2;
  return new Date(utc);
}

function validDay(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !isNaN(d) && d.toISOString().slice(0, 10) === s;
}

// Returns null for "all time", otherwise a half-open [startISO, endISO) window.
function parseRange(params, defaultPreset) {
  const today = dayString(new Date());
  let preset = params.get('range') || null;
  let start = params.get('start');
  let end = params.get('end');
  if (!preset && (start || end)) preset = 'custom';
  if (!preset) preset = defaultPreset || 'all';
  switch (preset) {
    case 'all': return null;
    case 'today': start = end = today; break;
    case 'yesterday': start = end = addDays(today, -1); break;
    case '7d': start = addDays(today, -6); end = today; break;
    case '30d': start = addDays(today, -29); end = today; break;
    case 'thismonth': start = today.slice(0, 8) + '01'; end = today; break;
    case 'lastmonth': {
      const first = today.slice(0, 8) + '01';
      end = addDays(first, -1);
      start = end.slice(0, 8) + '01';
      break;
    }
    case 'custom':
      if (!validDay(start || '') || !validDay(end || '')) throw new HttpError(400, 'Invalid date range');
      break;
    default: throw new HttpError(400, 'Unknown range');
  }
  if (start > end) throw new HttpError(400, 'Invalid date range');
  const days = daysBetween(start, end) + 1;
  if (days > 366) throw new HttpError(400, 'Range too long');
  return {
    preset, start, end, days,
    startISO: localMidnightToUTC(start).toISOString(),
    endISO: localMidnightToUTC(addDays(end, 1)).toISOString()
  };
}

function buildWhere(range, conds = [], binds = []) {
  const c = [...conds];
  const b = [...binds];
  if (range) { c.push('timestamp >= ?', 'timestamp < ?'); b.push(range.startISO, range.endISO); }
  return { sql: c.length ? 'WHERE ' + c.join(' AND ') : '', binds: b };
}

// ── Input cleaning ───────────────────────────────────────────────────────────
function normalizeReferrer(v) {
  const s = cleanStr(v, 300);
  if (!s || s === 'Direct') return 'Direct';
  try {
    const u = new URL(s);
    if (u.protocol === 'http:' || u.protocol === 'https:') return u.hostname.replace(/^www\./, '').toLowerCase().slice(0, 100);
  } catch (e) { /* not a URL: treat as a custom ?ref= tag */ }
  return cleanStr(s, 60);
}

function cleanUtm(u) {
  const out = {};
  if (!u || typeof u !== 'object') return out;
  for (const k of ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content']) {
    const v = cleanStr(u[k], 100).toLowerCase();
    if (v) out[k] = v;
  }
  return out;
}

function parseUA(ua) {
  ua = ua || '';
  let browser = 'Other';
  if (/Edg(e|A|iOS)?\//.test(ua)) browser = 'Edge';
  else if (/OPR\/|Opera/.test(ua)) browser = 'Opera';
  else if (/SamsungBrowser/.test(ua)) browser = 'Samsung Internet';
  else if (/Firefox\/|FxiOS/.test(ua)) browser = 'Firefox';
  else if (/Chrome\/|CriOS/.test(ua)) browser = 'Chrome';
  else if (/Safari\//.test(ua)) browser = 'Safari';
  let os = 'Other';
  if (/Windows/.test(ua)) os = 'Windows';
  else if (/Android/.test(ua)) os = 'Android';
  else if (/iPhone|iPad|iPod/.test(ua)) os = 'iOS';
  else if (/Mac OS X|Macintosh/.test(ua)) os = 'macOS';
  else if (/CrOS/.test(ua)) os = 'ChromeOS';
  else if (/Linux/.test(ua)) os = 'Linux';
  const device = /Mobi|iPhone|iPod/.test(ua) ? 'Mobile' : (/iPad|Android|Tablet/.test(ua) ? 'Tablet' : 'Desktop');
  return { browser, os, device };
}

function expandIPv6(ip) {
  const [left, right] = ip.split('::');
  const l = left ? left.split(':') : [];
  if (right === undefined) return l.map(g => g.padStart(4, '0'));
  const r = right ? right.split(':') : [];
  return [...l, ...Array(Math.max(0, 8 - l.length - r.length)).fill('0'), ...r].map(g => g.padStart(4, '0'));
}

// IPv6 addresses are reduced to their /64 so privacy-extension rotation does not inflate unique counts
function normalizeIp(ip) {
  if (!ip || ip === 'unknown') return 'unknown';
  if (ip.includes(':') && !ip.includes('.')) {
    try { return expandIPv6(ip.split('%')[0]).slice(0, 4).join(':') + '::/64'; } catch (e) { return ip; }
  }
  return ip;
}

async function hashIp(env, ip) {
  const norm = normalizeIp(ip);
  if (env.IP_HASH_SECRET) return hmacHex(env.IP_HASH_SECRET, 'ip:' + norm);
  return sha256Hex(norm); // unkeyed fallback: set IP_HASH_SECRET to make hashes non-reversible
}

// ── CORS / origin checks ─────────────────────────────────────────────────────
function allowedOrigins(env) {
  const extra = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
  return [...SITE_ORIGINS, ...extra];
}

function corsFor(request, env) {
  const origin = request.headers.get('Origin');
  const h = { 'Vary': 'Origin' };
  if (origin && allowedOrigins(env).includes(origin)) {
    h['Access-Control-Allow-Origin'] = origin;
    h['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
    h['Access-Control-Allow-Headers'] = 'Content-Type';
    h['Access-Control-Max-Age'] = '86400';
  }
  return h;
}

function requireAllowedOrigin(request, env) {
  const origin = request.headers.get('Origin');
  if (!origin || !allowedOrigins(env).includes(origin)) throw new HttpError(403, 'Origin not allowed');
}

async function readJson(request) {
  const declared = Number(request.headers.get('Content-Length') || 0);
  if (declared > MAX_BODY_BYTES) throw new HttpError(413, 'Payload too large');
  const text = await request.text();
  if (text.length > MAX_BODY_BYTES) throw new HttpError(413, 'Payload too large');
  try {
    const data = JSON.parse(text);
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('not an object');
    return data;
  } catch (e) {
    throw new HttpError(400, 'Invalid JSON');
  }
}

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers }
  });
}

