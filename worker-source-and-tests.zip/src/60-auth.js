// ── Authentication ───────────────────────────────────────────────────────────
function sessionSecret(env) { return env.SESSION_SECRET || env.DASHBOARD_PASSWORD || ''; }

async function createSession(env) {
  const exp = String(Date.now() + SESSION_TTL_SECONDS * 1000);
  return exp + '.' + await hmacHex(sessionSecret(env), 'dashboard-session:' + exp);
}

async function isAuthed(request, env) {
  const secret = sessionSecret(env);
  if (!secret) return false;
  const token = parseCookies(request.headers.get('Cookie'))[SESSION_COOKIE];
  if (!token) return false;
  const dot = token.indexOf('.');
  if (dot < 1) return false;
  const exp = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  if (!/^\d{10,15}$/.test(exp) || Number(exp) < Date.now()) return false;
  return safeEqual(sig, await hmacHex(secret, 'dashboard-session:' + exp));
}

async function loginBlocked(env, ipHash) {
  const since = new Date(Date.now() - LOGIN_WINDOW_MS).toISOString();
  const row = await env.DB.prepare('SELECT COUNT(*) AS c FROM login_attempts WHERE ip_hash = ? AND timestamp >= ?').bind(ipHash, since).first();
  return (row ? row.c : 0) >= LOGIN_MAX_FAILURES;
}

function newNonce() { return b64url(crypto.getRandomValues(new Uint8Array(16))); }

function htmlHeaders(nonce, extra = {}) {
  return {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'`,
    ...extra
  };
}

function cookieHeader(value, maxAge) {
  return `${SESSION_COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

// ── Pages ────────────────────────────────────────────────────────────────────
function getLoginPage(nonce, errorMsg = '') {
  const msg = errorMsg ? `<p class="err" role="alert">${esc(errorMsg)}</p>` : '';
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="robots" content="noindex, nofollow"><title>Dashboard Login</title>
<style>
body{font-family:system-ui,sans-serif;background:#0a0a0f;color:#e8e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
form{background:#16161f;padding:2rem;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.5);width:min(92vw,340px)}
h2{margin:0 0 1rem}
label{display:block;font-size:.85rem;color:#a0a0b8;margin-bottom:.35rem}
.pw{display:flex;gap:.4rem;margin-bottom:1.1rem}
input{flex:1;min-width:0;padding:.6rem;border:1px solid #252535;border-radius:6px;background:#111118;color:#e8e8f0;font-size:1rem}
input:focus-visible,button:focus-visible{outline:2px solid #d4a853;outline-offset:2px}
button{cursor:pointer;font-weight:600;border-radius:6px;font-size:.9rem}
#pwToggle{background:#111118;color:#e8e8f0;border:1px solid #252535;padding:0 .8rem}
#pwToggle:hover{border-color:#d4a853}
.go{width:100%;background:#d4a853;color:#000;border:none;padding:.7rem 1rem}
.go:hover{filter:brightness(1.1)}
.err{color:#ff8a80;font-size:.9rem;margin:0 0 1rem}
</style></head>
<body><form method="POST" action="/dashboard"><h2>Dashboard</h2>${msg}
<label for="password">Password</label>
<div class="pw"><input id="password" type="password" name="password" autocomplete="current-password" required autofocus>
<button type="button" id="pwToggle" aria-pressed="false" aria-label="Show password">Show</button></div>
<button class="go" type="submit">Log in</button></form>
<script nonce="${nonce}">
(function () {
  var input = document.getElementById('password');
  var btn = document.getElementById('pwToggle');
  btn.addEventListener('click', function () {
    var show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.textContent = show ? 'Hide' : 'Show';
    btn.setAttribute('aria-pressed', show ? 'true' : 'false');
    btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    input.focus();
  });
})();
</script></body></html>`;
}

