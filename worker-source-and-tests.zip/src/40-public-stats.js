// ── Statistics ───────────────────────────────────────────────────────────────
const pct = (n, d) => (d > 0 ? Math.round((n / d) * 100) + '%' : '0%');
const one = r => (r.results && r.results[0]) || {};

async function getStatistics(db, { excludeToken = null, range = null, authed = false } = {}) {
  const now = new Date();
  const todayStartISO = localMidnightToUTC(dayString(now)).toISOString();
  const liveSince = new Date(now.getTime() - 5 * 60 * 1000).toISOString();

  const w = buildWhere(range);
  const wGeo = buildWhere(range, [GEO_OK]);
  const wCity = buildWhere(range, [GEO_OK, "city NOT IN ('', 'Unknown')"]);
  const wDur = buildWhere(range, ['session_duration > 0']);
  const wLast = buildWhere(range, excludeToken ? ['visitor_token != ?'] : [], excludeToken ? [excludeToken] : []);
  const liveTok = excludeToken ? ' AND visitor_token != ?' : '';
  const liveBinds = excludeToken ? [liveSince, excludeToken] : [liveSince];

  const r = await db.batch([
    db.prepare(`SELECT COUNT(*) AS c FROM visits ${w.sql}`).bind(...w.binds),
    db.prepare(`SELECT COUNT(DISTINCT visitor_token) AS c FROM visits ${w.sql}`).bind(...w.binds),
    db.prepare(`SELECT COUNT(DISTINCT ip_hash) AS c FROM visits ${w.sql}`).bind(...w.binds),
    db.prepare('SELECT COUNT(DISTINCT ip_hash) AS c FROM visits WHERE timestamp >= ?').bind(todayStartISO),
    db.prepare(`SELECT country, COUNT(DISTINCT ip_hash) AS visitors, COUNT(*) AS page_views, MAX(timestamp) AS last_visit
                FROM visits ${wGeo.sql} GROUP BY country ORDER BY visitors DESC, page_views DESC`).bind(...wGeo.binds),
    db.prepare(`SELECT COUNT(*) AS c FROM (SELECT DISTINCT city, country FROM visits ${wCity.sql})`).bind(...wCity.binds),
    db.prepare(`SELECT COUNT(DISTINCT ip_hash) AS c FROM visits WHERE timestamp >= ?${liveTok}`).bind(...liveBinds),
    db.prepare(`SELECT DISTINCT country FROM visits WHERE timestamp >= ? AND ${GEO_OK}${liveTok}`).bind(...liveBinds),
    db.prepare(`SELECT AVG(d) AS a, COUNT(*) AS n FROM (SELECT MAX(session_duration) AS d FROM visits ${wDur.sql} GROUP BY visitor_token)`).bind(...wDur.binds),
    db.prepare(`SELECT country, timestamp FROM visits ${wLast.sql} ORDER BY id DESC LIMIT 1`).bind(...wLast.binds),
    db.prepare(`SELECT COUNT(*) AS total, SUM(CASE WHEN pv = 1 THEN 1 ELSE 0 END) AS bounces
                FROM (SELECT visitor_token, COUNT(*) AS pv FROM visits ${w.sql} GROUP BY visitor_token)`).bind(...w.binds),
    db.prepare(`SELECT COUNT(*) AS c FROM (SELECT ip_hash FROM visits ${w.sql} GROUP BY ip_hash) r
                WHERE (SELECT COUNT(DISTINCT v.visitor_token) FROM visits v WHERE v.ip_hash = r.ip_hash) > 1`).bind(...w.binds)
  ]);

  const pageViews = one(r[0]).c || 0;
  const sessions = one(r[1]).c || 0;
  const unique = one(r[2]).c || 0;
  const today = one(r[3]).c || 0;
  const countries = r[4].results || [];
  const citiesCount = one(r[5]).c || 0;
  const live = one(r[6]).c || 0;
  const liveCountries = (r[7].results || []).map(x => ({ country: countryName(x.country), flag: flagFor(x.country) }));
  const avg = one(r[8]);
  const last = one(r[9]);
  const bounce = one(r[10]);
  const returning = one(r[11]).c || 0;

  // No data means no number — never a made-up default
  let avgSession = '—';
  if (avg.n > 0 && avg.a !== null && avg.a !== undefined) {
    const secs = Math.round(avg.a);
    avgSession = `${Math.floor(secs / 60)}m ${pad(secs % 60)}s`;
  }

  const out = {
    totalVisitors: unique,
    visitorsToday: today,
    countries: countries.map(c => ({ country: countryName(c.country), flag: flagFor(c.country), visitors: c.visitors, pageViews: c.page_views, lastVisit: c.last_visit })),
    citiesCount,
    cities: [],
    avgSession,
    returningVisitors: pct(returning, unique),
    liveVisitors: live,
    liveCountries,
    lastVisitor: last.timestamp ? { country: countryName(last.country), flag: flagFor(last.country), timestamp: last.timestamp } : null,
    status: 'ok'
  };

  if (authed) {
    const wc = buildWhere(range, [GEO_OK, "city NOT IN ('', 'Unknown')"]);
    const cities = await db.prepare(
      `SELECT city, country, COUNT(DISTINCT ip_hash) AS visitors FROM visits ${wc.sql} GROUP BY city, country ORDER BY visitors DESC LIMIT 100`
    ).bind(...wc.binds).all();
    out.cities = cities.results.map(c => ({ city: c.city, country: countryName(c.country), visitors: c.visitors }));
    out.uniqueVisitors = unique;
    out.pageViews = pageViews;
    out.sessions = sessions;
    out.bounceRate = pct(bounce.bounces || 0, bounce.total || 0);
  }
  return out;
}

