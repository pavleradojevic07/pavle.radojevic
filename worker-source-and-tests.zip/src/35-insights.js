// -- Insights (plain rules, no AI call: every sentence is computed from your numbers) ----------------
const PAGE_NAMES = { index: 'Home', basketball: 'Basketball', academic: 'Academic', plates: 'License Plate Atlas', visitors: 'Visitors', privacy: 'Privacy', terms: 'Terms', cookies: 'Cookies' };
const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const pageName = p => PAGE_NAMES[p] || p;
const P = x => Math.round(x * 100) + '%';
const ratio = (a, b) => (b > 0 ? a / b : 0);

function buildInsights(cur, prev, limit = 14) {
  const out = [];
  const add = (level, title, detail, action) => out.push({ level, title, detail, action: action || null });
  const k = cur.kpi, s = k.sessions;
  if (!s) return [{ level: 'info', title: 'No visits in this range', detail: 'Pick a wider date range, remove the filters, or wait for new visits.', action: null }];

  // data quality
  if (ratio(k.with_eng, s) < 0.3) add('info', 'Engagement data is still filling in', `Only ${P(ratio(k.with_eng, s))} of sessions have time-on-page and scroll data. It grows as visitors load the updated site script.`, 'Check that the latest assets/site.js is deployed and the Worker is the new version.');

  // traffic trend
  if (prev && prev.kpi.sessions >= 5 && s + prev.kpi.sessions >= 10) {
    const d = (s - prev.kpi.sessions) / prev.kpi.sessions;
    if (Math.abs(d) >= 0.25) add(d > 0 ? 'good' : 'warn', `Traffic is ${d > 0 ? 'up' : 'down'} ${P(Math.abs(d))}`, `${s} sessions vs ${prev.kpi.sessions} in the previous period.`,
      d < 0 ? 'Think about what drove the previous period: a post, a message to clubs, a tournament? Repeat it.' : 'Find which source brought the extra visits (Sources tab) and do more of it.');
  }

  // conversion
  if (s >= 10) {
    const conv = ratio(k.conv, s), pc = prev && prev.kpi.sessions >= 10 ? ratio(prev.kpi.conv, prev.kpi.sessions) : null;
    const trend = pc === null ? '' : Math.abs(conv - pc) >= 0.05 ? (conv > pc ? ` (up from ${P(pc)})` : ` (down from ${P(pc)})`) : '';
    add(conv >= 0.15 ? 'good' : 'info', `${P(conv)} of sessions took a meaningful action${trend}`, `${k.conv} of ${s} sessions played the video, downloaded something, started contact or opened a stats profile.`);
  }

  // sources
  const total = cur.bySrc.reduce((a, x) => a + x.sessions, 0);
  const direct = cur.bySrc.find(x => x.src === 'Direct');
  if (s >= 20 && direct && ratio(direct.sessions, total) >= 0.6) add('info', `${P(ratio(direct.sessions, total))} of visits are Direct (source unknown)`, 'Links shared in chats, emails and apps often arrive without a source.', 'Add ?ref= to links you share, for example ...?ref=linkedin or ?ref=email-club, so the Sources tab can tell them apart.');
  if (s >= 50 && !cur.bySrc.find(x => x.src === 'Search')) add('info', 'No visits from search engines yet', 'Nobody has arrived from Google, Bing or similar in this range.', 'Submit the site in Google Search Console and add the sitemap so people searching your name can find you.');
  const best = cur.bySrc.filter(x => x.sessions >= 5 && x.src !== 'Internal').map(x => ({ ...x, r: ratio(x.conv, x.sessions) })).sort((a, b) => b.r - a.r)[0];
  if (best && best.r >= 0.2 && best.r >= 1.5 * ratio(k.conv, s)) add('good', `${best.src} visitors convert best (${P(best.r)})`, `${best.conv} of ${best.sessions} ${best.src.toLowerCase()} sessions took an action vs ${P(ratio(k.conv, s))} overall.`, 'Put more effort into this channel.');

  // device gap
  const mob = (cur.byDevice || []).find(x => x.device === 'Mobile'), desk = (cur.byDevice || []).find(x => x.device === 'Desktop');
  if (mob && desk && mob.sessions >= 15 && desk.sessions >= 15) {
    const mc = ratio(mob.conv, mob.sessions), dc = ratio(desk.conv, desk.sessions), mb = ratio(mob.bounced, mob.sessions), db = ratio(desk.bounced, desk.sessions);
    if (mc < dc * 0.6) add('warn', `Mobile visitors act less (${P(mc)} vs ${P(dc)} on desktop)`, `Mobile makes up ${P(ratio(mob.sessions, s))} of sessions.`, 'Open the Basketball page on a phone: is the video box, the player sheet button and the contact button visible without scrolling far?');
    else if (mb > db + 0.2) add('warn', `Mobile bounce rate is ${P(mb)} vs ${P(db)} on desktop`, 'More phone visitors leave right away.', 'Check loading speed and the first screen on a phone.');
  }

  // pages
  const content = (cur.pages || []).filter(p => !['index', 'privacy', 'terms', 'cookies', 'visitors'].includes(p.pg) && p.views >= 10 && p.m >= 5);
  const shallow = content.filter(p => p.avg_scroll < 35).sort((a, b) => a.avg_scroll - b.avg_scroll)[0];
  if (shallow) add('warn', `Visitors leave ${pageName(shallow.pg)} early (average scroll ${Math.round(shallow.avg_scroll)}%)`, `${shallow.views} views, but only ${P(ratio(shallow.s75, shallow.m))} reach 75% of the page.`, 'Move the most important content and buttons higher on that page.');
  const deep = content.filter(p => p.avg_scroll >= 65).sort((a, b) => b.avg_scroll - a.avg_scroll)[0];
  if (deep) add('good', `${pageName(deep.pg)} holds attention (average scroll ${Math.round(deep.avg_scroll)}%)`, `${P(ratio(deep.s75, deep.m))} of views reach at least 75% of the page.`);

  // video, player sheet, contact
  const fn = cur.funnel || {};
  if (fn.s2 >= 10) {
    const vr = ratio(fn.plays, fn.s2);
    if (vr < 0.1) add('warn', `Only ${P(vr)} of Basketball visitors play the highlight video`, `${fn.plays} plays from ${fn.s2} sessions that saw the page.`, 'Move the video higher, or give the play box a more inviting title or poster image.');
    else if (vr >= 0.25) add('good', `${P(vr)} of Basketball visitors play the highlight video`, `${fn.plays} plays from ${fn.s2} sessions.`);
  }
  if (fn.s2 >= 20 && fn.sheet === 0) add('warn', 'Nobody downloaded the player sheet', `${fn.s2} sessions saw the Basketball page.`, 'Make the Player sheet button more prominent or mention it in your messages to clubs.');
  else if (fn.sheet > 0) add('good', `${fn.sheet} ${fn.sheet === 1 ? 'visitor' : 'visitors'} downloaded the player sheet`, `That is ${P(ratio(fn.sheet, fn.s2))} of Basketball sessions.`);
  const contact = cur.goals.find(g => g.goal === 'Contact intent');
  if (contact) add('good', `${contact.sessions} ${contact.sessions === 1 ? 'session' : 'sessions'} started contact`, 'Email button, copy-email, recruiting inquiry or a plate donation offer. Check the Sessions tab, filter "Took action", to see what they viewed first.');

  // timing
  const heat = cur.heat || [];
  const heatTotal = heat.reduce((a, x) => a + x.n, 0);
  if (heatTotal >= 20) {
    const byDow = Array(7).fill(0), byHr = Array(24).fill(0);
    heat.forEach(x => { byDow[x.dow] += x.n; byHr[x.hr] += x.n; });
    const dow = byDow.indexOf(Math.max(...byDow)), hr = byHr.indexOf(Math.max(...byHr));
    add('info', `Busiest time: ${DAY_NAMES[dow]}s, around ${String(hr).padStart(2, '0')}:00`, `${P(ratio(byDow[dow], heatTotal))} of activity falls on ${DAY_NAMES[dow]}s (Belgrade/Ljubljana time).`, 'Send messages or post links shortly before that window.');
  }

  // geography
  const prevCodes = new Set(((prev && prev.byCountry) || []).map(c => c.country));
  const fresh = prev && prev.kpi.sessions >= 5 ? cur.byCountry.filter(c => !prevCodes.has(c.country)).slice(0, 4) : [];
  if (fresh.length) add('info', `New countries: ${fresh.map(c => countryName(c.country)).join(', ')}`, 'They did not appear in the previous period.');
  const bestCountry = cur.byCountry.filter(c => c.sessions >= 5).map(c => ({ ...c, r: ratio(c.conv, c.sessions) })).sort((a, b) => b.r - a.r)[0];
  if (bestCountry && bestCountry.r >= 0.25) add('info', `${countryName(bestCountry.country)} has the most active visitors`, `${P(bestCountry.r)} of its ${bestCountry.sessions} sessions took an action.`);

  // loyalty + quality
  const retRate = ratio(k.ret_n, s);
  if (s >= 20 && retRate >= 0.25) add('good', `${P(retRate)} of sessions are return visitors`, 'People come back, which usually means coaches or scouts checking progress.');
  const bounce = ratio(k.bounced, s);
  if (s >= 20 && bounce >= 0.7) add('warn', `${P(bounce)} of sessions bounce`, 'They view one page, do nothing and leave within seconds.', 'Check the Home page first screen and whether the sources you share bring the right audience.');

  // content demand + language
  const top = type => (cur.topLabels || []).filter(l => l.type === type)[0];
  const faq = top('faq'), globe = top('globe');
  if (faq && faq.n >= 3) add('info', `Most opened FAQ: "${faq.label}"`, `Opened ${faq.n} times. Visitors want this answered fast.`, 'Consider putting that answer in the profile summary at the top of the page.');
  if (globe && globe.n >= 3) add('info', `Most searched Atlas country: ${globe.label.replace('USA-', 'USA, ')}`, `Selected ${globe.n} times on the globe.`);
  const known = (cur.langs || []).reduce((a, x) => a + x.sessions, 0);
  const nonEn = (cur.langs || []).filter(l => l.lang !== 'en');
  if (known >= 20 && ratio(nonEn.reduce((a, x) => a + x.sessions, 0), known) >= 0.3) add('info', `${P(ratio(nonEn.reduce((a, x) => a + x.sessions, 0), known))} of visitors use a browser language other than English`, `Top: ${nonEn.slice(0, 3).map(l => `${l.lang} (${l.sessions})`).join(', ')}.`, 'A short summary in Slovenian or Serbian on the Basketball page could help local coaches.');

  const order = { warn: 0, good: 1, info: 2 };
  return out.sort((a, b) => order[a.level] - order[b.level]).slice(0, limit);
}

async function qInsights(db, range, f) {
  const prev = range ? prevRange(range) : null;
  const [cur, pv] = await Promise.all([qCore(db, scope(range, f)), prev ? qCore(db, scope(prev, f), { light: true }) : null]);
  return { insights: buildInsights(cur, pv), hasPrev: !!pv, sessions: cur.kpi.sessions };
}

