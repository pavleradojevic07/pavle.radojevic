// -- Ingest -------------------------------------------------------------------
const EVENT_TYPES = new Set(['download', 'click', 'contact', 'video', 'search', 'faq', 'course', 'plate', 'globe', 'theme', 'cta', 'copy', 'interaction']);
const SCREEN_CLASSES = new Set(['xs', 'sm', 'md', 'lg', 'xl']);
const VISIT_RATE_LIMIT = 60;    // page views per visitor (hashed IP) per 10 minutes
const EVENT_RATE_LIMIT = 200;   // events per session per 10 minutes
const hourFormats = new Map();

// Hour of day (0-23) in the visitor's own time zone. Only the hour is kept, never the zone name.
function hourInZone(tz) {
  if (typeof tz !== 'string' || !tz) return null;
  try {
    let f = hourFormats.get(tz);
    if (!f) { f = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', hourCycle: 'h23' }); hourFormats.set(tz, f); }
    const h = parseInt(f.format(new Date()), 10);
    return h >= 0 && h <= 23 ? h : null;
  } catch (e) { return null; }
}

const validId = v => (typeof v === 'string' && /^[A-Za-z0-9-]{6,64}$/.test(v) ? v : null);
const clampInt = (v, lo, hi) => { const n = Math.round(Number(v)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : null; };
const tenMinutesAgo = () => new Date(Date.now() - 600000).toISOString();

function cleanMeta(m) {
  if (!m || typeof m !== 'object' || Array.isArray(m)) return null;
  const out = {};
  let n = 0;
  for (const [k, v] of Object.entries(m)) {
    if (n >= 5 || !/^[a-z_]{1,20}$/.test(k)) continue;
    if (typeof v === 'string' || typeof v === 'number') { out[k] = typeof v === 'number' ? v : cleanStr(v, 80); n++; }
  }
  return n ? JSON.stringify(out) : null;
}

async function trackVisit(env, request, data) {
  const ua = request.headers.get('User-Agent') || '';
  if (BOT_RE.test(ua)) return false;

  const parsed = ua ? parseUA(ua) : {
    browser: ['Firefox', 'Chrome', 'Safari'].includes(data.browser) ? data.browser : 'Other',
    os: cleanStr(data.os, 40, 'Other'),
    device: data.device === 'Mobile' || data.device === 'Desktop' ? data.device : 'Unknown'
  };

  const cf = request.cf || {};
  const country = cleanStr(cf.country, 8, 'Unknown');
  const city = cleanStr(cf.city, 80, 'Unknown');
  const region = cleanStr(cf.region, 60);
  const continent = cleanStr(cf.continent, 4);
  const ipHash = await hashIp(env, request.headers.get('CF-Connecting-IP') || 'unknown');
  const now = Date.now();
  const timestamp = new Date(now).toISOString();

  const recent = await env.DB.prepare('SELECT COUNT(*) AS c FROM visits WHERE ip_hash = ? AND timestamp >= ?').bind(ipHash, tenMinutesAgo()).first();
  if (recent && recent.c >= VISIT_RATE_LIMIT) return false;

  const token = typeof data.visitorToken === 'string' && /^[A-Za-z0-9-]{6,64}$/.test(data.visitorToken) ? data.visitorToken : 'unknown';

  let sessionDuration = 0;
  const entry = typeof data.entryTime === 'string' ? Date.parse(data.entryTime) : NaN;
  if (data.previousPage && Number.isFinite(entry) && entry <= now + 60000 && entry >= now - 864e5) {
    sessionDuration = Math.max(0, Math.min(Math.round((now - entry) / 1000), 1800));
  }

  let page = cleanStr(data.page, 200, '/');
  if (!page.startsWith('/')) page = '/';
  const utm = cleanUtm(data.utm);
  const lang = cleanStr(data.language, 16);
  const language = /^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})?$/.test(lang) ? lang : null;

  await env.DB.prepare(
    `INSERT INTO visits (country, city, region, browser, os, device, referrer, page, timestamp, ip_hash, session_duration, visitor_token,
       utm_source, utm_medium, utm_campaign, utm_term, utm_content, pv_id, language, screen, theme, continent, visitor_hour)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    country, city, region, parsed.browser, parsed.os, parsed.device, normalizeReferrer(data.referrer), page, timestamp, ipHash, sessionDuration, token,
    utm.utm_source || null, utm.utm_medium || null, utm.utm_campaign || null, utm.utm_term || null, utm.utm_content || null,
    validId(data.pvId), language, SCREEN_CLASSES.has(data.screen) ? data.screen : null,
    data.theme === 'light' || data.theme === 'dark' ? data.theme : null, continent || null, hourInZone(cf.timezone)
  ).run();
  return true;
}

async function trackEvent(env, request, data) {
  const type = typeof data.type === 'string' && EVENT_TYPES.has(data.type) ? data.type : null;
  if (!type) throw new HttpError(400, 'Invalid event type');
  const ua = request.headers.get('User-Agent') || '';
  if (BOT_RE.test(ua)) return false;

  const token = validId(data.visitorToken);
  if (token) {
    // events only attach to a real, recent session (blocks drive-by spam), and a session cannot flood the table
    const known = await env.DB.prepare('SELECT 1 AS ok FROM visits WHERE visitor_token = ? LIMIT 1').bind(token).first();
    if (!known) return false;
    const recent = await env.DB.prepare('SELECT COUNT(*) AS c FROM events WHERE visitor_token = ? AND timestamp >= ?').bind(token, tenMinutesAgo()).first();
    if (recent && recent.c >= EVENT_RATE_LIMIT) return false;
  }
  let page = cleanStr(data.page, 200);
  if (page && !page.startsWith('/')) page = '';
  const cf = request.cf || {};
  await env.DB.prepare(
    'INSERT INTO events (type, label, url, referrer, country, city, timestamp, visitor_token, pv_id, page, meta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  ).bind(
    type, cleanStr(data.label, 150, '(no label)'), cleanStr(data.url, 300), normalizeReferrer(data.referrer),
    cleanStr(cf.country, 8, 'Unknown'), cleanStr(cf.city, 80, 'Unknown'), new Date().toISOString(),
    token, validId(data.pvId), page || null, cleanMeta(data.meta)
  ).run();
  return true;
}

// Sent when a page is hidden/closed: how long the visitor was really active and how far they scrolled.
async function trackEngage(env, request, data) {
  const ua = request.headers.get('User-Agent') || '';
  if (BOT_RE.test(ua)) return false;
  const pv = validId(data.pvId), token = validId(data.visitorToken);
  const active = clampInt(data.active, 0, 1800), scroll = clampInt(data.scroll, 0, 100);
  if (!pv || !token || active === null || scroll === null) throw new HttpError(400, 'Invalid engagement data');
  const res = await env.DB.prepare(
    `UPDATE visits SET active_s = MAX(COALESCE(active_s, 0), ?), max_scroll = MAX(COALESCE(max_scroll, 0), ?)
     WHERE pv_id = ? AND visitor_token = ?`
  ).bind(active, scroll, pv, token).run();
  return !!(res && res.meta && res.meta.changes);
}

