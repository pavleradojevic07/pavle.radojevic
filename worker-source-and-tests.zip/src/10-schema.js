// -- Schema (auto-created / auto-migrated) ------------------------------------
// Existing tables keep every old column; new columns are added automatically (ALTER TABLE) the first time the Worker runs.
const VISIT_COLUMNS = {
  utm_source: 'TEXT', utm_medium: 'TEXT', utm_campaign: 'TEXT', utm_term: 'TEXT', utm_content: 'TEXT',
  pv_id: 'TEXT',            // random id of one page view (links the engagement beacon to its row)
  language: 'TEXT',         // browser language, e.g. "en-US"
  screen: 'TEXT',           // screen size class: xs / sm / md / lg / xl (not exact pixels)
  theme: 'TEXT',            // light / dark
  continent: 'TEXT',        // from Cloudflare (IP based)
  visitor_hour: 'INTEGER',  // hour of day (0-23) where the visitor is, derived at ingest; the time zone itself is not stored
  active_s: 'INTEGER',      // seconds actually spent on the page (tab visible + recent activity)
  max_scroll: 'INTEGER'     // deepest scroll position reached, 0-100 (%)
};
const EVENT_COLUMNS = { visitor_token: 'TEXT', pv_id: 'TEXT', page: 'TEXT', meta: 'TEXT' };

let schemaReady = false;

async function addMissingColumns(db, table, wanted) {
  const info = await db.prepare(`PRAGMA table_info(${table})`).all();
  const have = new Set(info.results.map(r => r.name));
  for (const [col, type] of Object.entries(wanted)) {
    if (have.has(col)) continue;
    try { await db.prepare(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`).run(); }
    catch (e) { if (!/duplicate column/i.test(String((e && e.message) || e))) throw e; }
  }
}

const WANTED_INDEXES = {
  idx_visits_ts: 'CREATE INDEX IF NOT EXISTS idx_visits_ts ON visits(timestamp)',
  idx_visits_ip: 'CREATE INDEX IF NOT EXISTS idx_visits_ip ON visits(ip_hash)',
  idx_visits_token: 'CREATE INDEX IF NOT EXISTS idx_visits_token ON visits(visitor_token)',
  idx_visits_utm: 'CREATE INDEX IF NOT EXISTS idx_visits_utm ON visits(utm_source)',
  idx_visits_pv: 'CREATE INDEX IF NOT EXISTS idx_visits_pv ON visits(pv_id)',
  idx_events_ts: 'CREATE INDEX IF NOT EXISTS idx_events_ts ON events(timestamp)',
  idx_events_token: 'CREATE INDEX IF NOT EXISTS idx_events_token ON events(visitor_token)',
  idx_login_ip: 'CREATE INDEX IF NOT EXISTS idx_login_ip ON login_attempts(ip_hash, timestamp)'
};

// Cheap on a warm database (3 reads), so a cold start never eats the per-request query budget.
async function ensureSchema(db) {
  if (schemaReady) return;
  const master = await db.prepare("SELECT name FROM sqlite_master WHERE type IN ('table', 'index')").all();
  const have = new Set(master.results.map(r => r.name));
  const create = [];
  if (!have.has('visits')) create.push(db.prepare(`CREATE TABLE IF NOT EXISTS visits (
      id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, city TEXT, region TEXT, browser TEXT, os TEXT, device TEXT,
      referrer TEXT, page TEXT, timestamp TEXT, ip_hash TEXT, session_duration INTEGER DEFAULT 0, visitor_token TEXT)`));
  if (!have.has('events')) create.push(db.prepare(`CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, label TEXT, url TEXT, referrer TEXT, country TEXT, city TEXT, timestamp TEXT)`));
  if (!have.has('login_attempts')) create.push(db.prepare('CREATE TABLE IF NOT EXISTS login_attempts (ip_hash TEXT, timestamp TEXT)'));
  if (create.length) await db.batch(create);
  await addMissingColumns(db, 'visits', VISIT_COLUMNS);
  await addMissingColumns(db, 'events', EVENT_COLUMNS);
  for (const [name, sql] of Object.entries(WANTED_INDEXES)) {
    if (have.has(name)) continue;
    try { await db.prepare(sql).run(); } catch (e) { console.warn('Index creation skipped:', name, e); }
  }
  schemaReady = true;
}

// -- Retention ----------------------------------------------------------------
let lastPurgeAt = 0;

async function purgeOld(env) {
  const raw = String(env.RETENTION_DAYS === undefined ? DEFAULT_RETENTION_DAYS : env.RETENTION_DAYS).trim().toLowerCase();
  if (raw === 'never') return { skipped: true };
  const days = parseInt(raw, 10);
  if (!(days > 0)) return { skipped: true };
  await ensureSchema(env.DB);
  const cutoff = new Date(Date.now() - days * 864e5).toISOString();
  const attemptsCutoff = new Date(Date.now() - 864e5).toISOString();
  await env.DB.batch([
    env.DB.prepare('DELETE FROM visits WHERE timestamp < ?').bind(cutoff),
    env.DB.prepare('DELETE FROM events WHERE timestamp < ?').bind(cutoff),
    env.DB.prepare('DELETE FROM login_attempts WHERE timestamp < ?').bind(attemptsCutoff)
  ]);
  return { cutoff };
}

async function maybePurge(env) {
  if (Date.now() - lastPurgeAt < 864e5) return;
  lastPurgeAt = Date.now();
  try { await purgeOld(env); } catch (e) { console.error('Retention purge failed:', e); }
}

