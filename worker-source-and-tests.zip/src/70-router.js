// ── Router ───────────────────────────────────────────────────────────────────
async function handle(request, env, ctx, cors) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, '') || '/';
  const method = request.method;

  if (method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (path === '/') return new Response('Visitor Tracker API', { headers: cors });
  if (!env.DB) throw new Error('D1 binding "DB" is missing');

  // Public, aggregated statistics (consumed by the Visitors page)
  if (path === '/statistics.json') {
    if (method !== 'GET') throw new HttpError(405, 'Method not allowed');
    await ensureSchema(env.DB);
    const authed = await isAuthed(request, env);
    const stats = await getStatistics(env.DB, {
      excludeToken: url.searchParams.get('token') || null,
      range: parseRange(url.searchParams, 'all'),
      authed
    });
    return json(stats, 200, { ...cors, 'Cache-Control': authed ? 'no-store' : 'public, max-age=15' });
  }

  // Ingest (called by assets/site.js after the visitor accepted analytics)
  if (path === '/track' || path === '/track-event' || path === '/track-engage') {
    if (method !== 'POST') throw new HttpError(405, 'Method not allowed');
    requireAllowedOrigin(request, env);
    const data = await readJson(request);
    await ensureSchema(env.DB);
    const fn = path === '/track' ? trackVisit : path === '/track-event' ? trackEvent : trackEngage;
    const stored = await fn(env, request, data);
    ctx.waitUntil(maybePurge(env));
    return json(stored ? { success: true } : { success: true, skipped: true }, 200, cors);
  }

  // Dashboard
  if (path === '/dashboard' || path === '/dashboard.html') {
    const nonce = newNonce();
    if (method === 'POST') {
      if (!env.DASHBOARD_PASSWORD) {
        return new Response(getLoginPage(nonce, 'Dashboard is not configured (DASHBOARD_PASSWORD is missing).'), { status: 503, headers: htmlHeaders(nonce) });
      }
      const ipHash = await hashIp(env, request.headers.get('CF-Connecting-IP') || 'unknown');
      let blocked = false;
      try { await ensureSchema(env.DB); blocked = await loginBlocked(env, ipHash); } catch (e) { console.error('Login throttle unavailable:', e); }
      if (blocked) {
        return new Response(getLoginPage(nonce, 'Too many attempts. Try again in 15 minutes.'), { status: 429, headers: htmlHeaders(nonce, { 'Retry-After': '900' }) });
      }
      let pass = '';
      try { pass = String((await request.formData()).get('password') || '').slice(0, 200); }
      catch (e) { throw new HttpError(400, 'Invalid form'); }
      if (await safeEqual(pass, env.DASHBOARD_PASSWORD)) {
        try { await env.DB.prepare('DELETE FROM login_attempts WHERE ip_hash = ?').bind(ipHash).run(); } catch (e) { /* non-fatal */ }
        return new Response(null, { status: 302, headers: { 'Location': '/dashboard', 'Set-Cookie': cookieHeader(await createSession(env), SESSION_TTL_SECONDS), 'Cache-Control': 'no-store' } });
      }
      try { await env.DB.prepare('INSERT INTO login_attempts (ip_hash, timestamp) VALUES (?, ?)').bind(ipHash, new Date().toISOString()).run(); } catch (e) { /* non-fatal */ }
      return new Response(getLoginPage(nonce, 'Wrong password'), { status: 401, headers: htmlHeaders(nonce) });
    }
    if (method !== 'GET') throw new HttpError(405, 'Method not allowed');
    if (!(await isAuthed(request, env))) return new Response(getLoginPage(nonce), { headers: htmlHeaders(nonce) });
    return new Response(DASHBOARD_TEMPLATE.replaceAll('__NONCE__', nonce), { headers: htmlHeaders(nonce) });
  }

  if (path === '/dashboard/logout') {
    if (method !== 'POST') throw new HttpError(405, 'Method not allowed');
    return new Response(null, { status: 302, headers: { 'Location': '/dashboard', 'Set-Cookie': cookieHeader('', 0), 'Cache-Control': 'no-store' } });
  }

  // Dashboard data: private, same-origin only (no CORS headers on purpose)
  if (path.startsWith('/api/')) {
    if (method !== 'GET') throw new HttpError(405, 'Method not allowed');
    if (!(await isAuthed(request, env))) throw new HttpError(401, 'Unauthorized');
    await ensureSchema(env.DB);
    const q = url.searchParams;
    const range = parseRange(q, '30d');
    const f = parseFilters(q);
    const db = env.DB;
    switch (path) {
      case '/api/overview': return json(await qOverview(db, range, f));
      case '/api/live': return json(await qLive(db));
      case '/api/pages': return json(await qPages(db, range, f));
      case '/api/behavior': return json(await qBehavior(db, range, f));
      case '/api/sources': return json(await qSources(db, range, f));
      case '/api/audience': return json(await qAudience(db, range, f));
      case '/api/goals': return json(await qGoals(db, range, f));
      case '/api/insights': return json(await qInsights(db, range, f));
      case '/api/options': return json(await qOptions(db));
      case '/api/health': return json(await qHealth(db, env));
      case '/api/session': return json(await qSession(db, q.get('sid') || ''));
      case '/api/sessions':
        return json(await qSessions(db, range, f, { limit: parseInt(q.get('limit'), 10) || 50, offset: parseInt(q.get('offset'), 10) || 0, only: q.get('only') || '' }));
      case '/api/export': {
        const kind = ['sessions', 'visits', 'events'].includes(q.get('kind')) ? q.get('kind') : 'sessions';
        const body = await exportCsv(db, kind, range, f);
        return new Response(body, { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="visitors-${kind}-${dayString(new Date())}.csv"`, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
      }
      default: throw new HttpError(404, 'Not found');
    }
  }

  throw new HttpError(404, 'Not found');
}

export default {
  async fetch(request, env, ctx) {
    const cors = corsFor(request, env);
    try {
      return await handle(request, env, ctx, cors);
    } catch (err) {
      if (err instanceof HttpError) return json({ error: err.message }, err.status, cors);
      console.error('Unhandled error:', err && err.stack ? err.stack : err);
      return json({ error: 'Internal error' }, 500, cors);
    }
  },

  // Cron trigger: daily retention purge
  async scheduled(event, env, ctx) {
    ctx.waitUntil(purgeOld(env));
  }
};
