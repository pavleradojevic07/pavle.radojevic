// -- Analytics ----------------------------------------------------------------
// A "session" is one browser-tab visit (visitor_token). Everything below is built from one scoped CTE chain:
//   v  = page views in range (+ row filters)      vs = same, after session-level filters
//   ss = one row per session                      ev = interaction events of those sessions
//   sx = sessions + event counts + class          sl = sessions + landing-page attributes
const SITE_BASE = '/pavle.radojevic';
const GEO = "('Unknown', 'XX', 'T1')";
const STRONG_GOALS = ['Player sheet download', 'Paper download', 'Contact intent', 'Stats profile click', 'Video play'];
const ACTION_GOALS = ['Player sheet download', 'Paper download', 'Contact intent', 'Stats profile click'];
const sqlList = a => a.map(s => `'${s}'`).join(', ');

const pageSql = c => `CASE WHEN ${c} IN ('/', '/index.html', '${SITE_BASE}', '${SITE_BASE}/', '${SITE_BASE}/index.html') THEN 'index'
  ELSE REPLACE(REPLACE(REPLACE(${c}, '${SITE_BASE}/', ''), '/', ''), '.html', '') END`;

// Belgrade/Ljubljana local time from a UTC ISO timestamp (EU daylight saving: last Sunday of March to last Sunday of October, 01:00 UTC)
const localSql = c => `datetime(substr(${c}, 1, 19), CASE
  WHEN ${c} >= date(substr(${c}, 1, 4) || '-04-01', 'weekday 0', '-7 days') || 'T01:00:00'
   AND ${c} <  date(substr(${c}, 1, 4) || '-11-01', 'weekday 0', '-7 days') || 'T01:00:00' THEN '+2 hours' ELSE '+1 hours' END)`;

const SOCIAL_WORDS = ['instagram', 'facebook', 'linkedin', 'twitter', 'youtube', 'tiktok', 'reddit', 'whatsapp', 'telegram', 'pinterest', 'snapchat', 'messenger', 'threads'];
const SEARCH_WORDS = ['google.', 'bing.', 'duckduckgo', 'yahoo.', 'ecosia', 'yandex', 'baidu', 'startpage', 'qwant', 'search.brave'];
const refLike = words => words.map(w => `refstr LIKE '%${w}%'`).join(' OR ');
// Where a session came from: Email / Social / Search / Internal / Direct / Other
const SRC_SQL = `CASE
  WHEN utm_medium IN ('email', 'newsletter') THEN 'Email'
  WHEN lower(COALESCE(referrer, '')) IN ('t.co', 'x.com', 'fb.com', 'lnkd.in', 'youtu.be', 'l.instagram.com') OR ${refLike(SOCIAL_WORDS)} THEN 'Social'
  WHEN ${refLike(SEARCH_WORDS)} THEN 'Search'
  WHEN referrer LIKE '%pavleradojevic07.github.io%' OR referrer LIKE 'localhost%' THEN 'Internal'
  WHEN referrer IS NULL OR referrer IN ('', 'Direct') THEN 'Direct'
  ELSE 'Other' END`;

// What counts as a goal (edit here to change what the Goals tab and conversion rate measure)
const GOAL_SQL = `CASE
  WHEN type = 'download' AND lower(url) LIKE '%player-sheet%' THEN 'Player sheet download'
  WHEN type = 'download' AND lower(url) LIKE '%fleet-procurement%' THEN 'Paper download'
  WHEN type = 'download' THEN 'Other download'
  WHEN type = 'contact' THEN 'Contact intent'
  WHEN type = 'video' THEN 'Video play'
  WHEN type = 'click' AND (lower(url) LIKE '%eurobasket%' OR lower(url) LIKE '%kzs.si%' OR lower(url) LIKE '%sofascore%' OR lower(url) LIKE '%proballers%') THEN 'Stats profile click'
  WHEN type = 'click' AND (lower(url) LIKE '%instagram.com%' OR lower(url) LIKE '%linkedin.com%' OR lower(url) LIKE '%youtube.com%' OR lower(url) LIKE '%youtu.be%') THEN 'Social click'
  ELSE NULL END`;

const SESSION_CLASS_SQL = `CASE
  WHEN COALESCE(sg.g, 0) > 0 THEN 'High intent'
  WHEN ss.pages >= 3 OR ss.engaged >= 60 OR ss.scroll >= 75 OR COALESCE(sg.n, 0) > 0 THEN 'Engaged'
  WHEN ss.pages >= 2 OR ss.engaged >= 10 THEN 'Browsed'
  ELSE 'Bounced' END`;

const ALL_RANGE = { preset: 'all', start: '', end: '', days: 0, startISO: '0000-01-01T00:00:00.000Z', endISO: '9999-12-31T00:00:00.000Z' };
const SOURCES = ['Direct', 'Search', 'Social', 'Email', 'Internal', 'Other'];

function parseFilters(params) {
  const f = {};
  const c = (params.get('country') || '').toUpperCase();
  if (/^[A-Z]{2}$/.test(c)) f.country = c;
  const d = params.get('device');
  if (d === 'Mobile' || d === 'Desktop' || d === 'Tablet') f.device = d;
  const s = params.get('src');
  if (SOURCES.includes(s)) f.src = s;
  const r = params.get('ret');
  if (r === 'new' || r === 'returning') f.ret = r;
  const l = (params.get('lang') || '').toLowerCase();
  if (/^[a-z]{2,3}$/.test(l)) f.lang = l;
  return f;
}

function prevRange(r) {
  if (!r) return null;
  const start = addDays(r.start, -r.days), end = addDays(r.start, -1);
  return { preset: 'prev', start, end, days: r.days, startISO: localMidnightToUTC(start).toISOString(), endISO: localMidnightToUTC(addDays(end, 1)).toISOString() };
}

const RETURNING_OF = (ip, id, sid) => `EXISTS (SELECT 1 FROM visits o WHERE o.ip_hash = ${ip} AND o.id < ${id} AND COALESCE(NULLIF(o.visitor_token, 'unknown'), 'u' || o.id) != ${sid})`;

function scope(range, f = {}) {
  const r = range || ALL_RANGE;
  const binds = [];
  const where = ['timestamp >= ?', 'timestamp < ?'];
  binds.push(r.startISO, r.endISO);
  if (f.country) { where.push('country = ?'); binds.push(f.country); }
  if (f.device) { where.push('device = ?'); binds.push(f.device); }
  if (f.lang) { where.push('language LIKE ?'); binds.push(f.lang + '%'); }
  const sess = [];
  const sessBinds = [];
  if (f.src) { sess.push('v2.src = ?'); sessBinds.push(f.src); }
  if (f.ret === 'returning') sess.push(RETURNING_OF('v2.ip_hash', 'v2.id', 'v2.sid'));
  if (f.ret === 'new') sess.push('NOT ' + RETURNING_OF('v2.ip_hash', 'v2.id', 'v2.sid'));
  const filtered = Object.keys(f).length > 0;

  let sql = `WITH v AS (SELECT id, country, city, region, continent, browser, os, device, referrer, page, timestamp, ip_hash, visitor_token,
      utm_source, utm_medium, utm_campaign, language, screen, theme, visitor_hour, active_s, max_scroll, pv_id,
      COALESCE(NULLIF(visitor_token, 'unknown'), 'u' || id) AS sid, ${pageSql('page')} AS pg, ${SRC_SQL} AS src, ${localSql('timestamp')} AS lts
    FROM (SELECT *, lower(COALESCE(referrer, '') || ' ' || COALESCE(utm_source, '')) AS refstr FROM visits WHERE ${where.join(' AND ')})),
  fst AS (SELECT sid, MIN(id) AS fid FROM v GROUP BY sid),`;
  if (sess.length) {
    sql += ` vs AS (SELECT * FROM v WHERE sid IN (SELECT f.sid FROM fst f JOIN v v2 ON v2.id = f.fid WHERE ${sess.join(' AND ')})),`;
    binds.push(...sessBinds);
  } else sql += ' vs AS (SELECT * FROM v),';
  sql += ` ss AS (SELECT sid, MIN(id) AS fid, MAX(id) AS lid, COUNT(*) AS pages, MIN(timestamp) AS t0, MAX(timestamp) AS t1,
      SUM(COALESCE(active_s, 0)) AS engaged, MAX(COALESCE(max_scroll, 0)) AS scroll, MIN(ip_hash) AS ip FROM vs GROUP BY sid),
  ev AS (SELECT e.id, e.type, e.label, e.url, e.page, e.meta, e.timestamp, e.visitor_token AS sid, ${GOAL_SQL} AS goal
    FROM events e WHERE e.timestamp >= ? AND e.timestamp < ? AND (e.visitor_token IN (SELECT sid FROM ss)${filtered ? '' : ' OR e.visitor_token IS NULL'})),
  sg AS (SELECT sid, COUNT(*) AS n, SUM(CASE WHEN goal IN (${sqlList(STRONG_GOALS)}) THEN 1 ELSE 0 END) AS g FROM ev WHERE sid IS NOT NULL GROUP BY sid),
  sx AS (SELECT ss.*, COALESCE(sg.n, 0) AS ev, COALESCE(sg.g, 0) AS goals, ${SESSION_CLASS_SQL} AS cls,
      CASE WHEN ${RETURNING_OF('ss.ip', 'ss.fid', 'ss.sid')} THEN 1 ELSE 0 END AS ret
    FROM ss LEFT JOIN sg ON sg.sid = ss.sid),
  sl AS (SELECT sx.*, v.country, v.city, v.region, v.continent, v.device, v.browser, v.os, v.language, v.screen, v.theme, v.src, v.referrer,
      v.utm_source, v.utm_medium, v.utm_campaign, v.pg AS landing, v.visitor_hour AS vhour
    FROM sx JOIN vs v ON v.id = sx.fid)`;
  binds.push(r.startISO, r.endISO);
  return { sql, binds, range: r, filtered };
}

// prepared statement against a scope; `ctes` adds extra CTEs, `select` is the final query
const stmt = (db, S, select, extra = [], ctes = '') => db.prepare(S.sql + (ctes ? ', ' + ctes : '') + ' ' + select).bind(...S.binds, ...extra);
const rows = r => (r && r.results) || [];
const num = v => (typeof v === 'number' && isFinite(v) ? v : 0);

// -- shared building blocks ----------------------------------------------------
const BASKET_FUNNEL_SQL = `SELECT COUNT(*) AS s1, COALESCE(SUM(b), 0) AS s2,
    COALESCE(SUM(CASE WHEN b = 1 AND (vid = 1 OR deep = 1) THEN 1 ELSE 0 END), 0) AS s3,
    COALESCE(SUM(CASE WHEN b = 1 AND act = 1 THEN 1 ELSE 0 END), 0) AS s4,
    COALESCE(SUM(CASE WHEN b = 1 AND vid = 1 THEN 1 ELSE 0 END), 0) AS plays,
    COALESCE(SUM(CASE WHEN b = 1 AND dl = 1 THEN 1 ELSE 0 END), 0) AS sheet
  FROM (SELECT sx.sid,
    EXISTS (SELECT 1 FROM vs WHERE vs.sid = sx.sid AND vs.pg = 'basketball') AS b,
    EXISTS (SELECT 1 FROM vs WHERE vs.sid = sx.sid AND vs.pg = 'basketball' AND vs.max_scroll >= 75) AS deep,
    EXISTS (SELECT 1 FROM ev WHERE ev.sid = sx.sid AND ev.type = 'video') AS vid,
    EXISTS (SELECT 1 FROM ev WHERE ev.sid = sx.sid AND ev.goal IN (${sqlList(ACTION_GOALS)})) AS act,
    EXISTS (SELECT 1 FROM ev WHERE ev.sid = sx.sid AND ev.goal = 'Player sheet download') AS dl
    FROM sx)`;

const GROUP_STATS = `COUNT(*) AS sessions, SUM(pages) AS views, SUM(CASE WHEN goals > 0 THEN 1 ELSE 0 END) AS conv,
  SUM(CASE WHEN cls = 'Bounced' THEN 1 ELSE 0 END) AS bounced, SUM(engaged) AS engaged, SUM(CASE WHEN engaged > 0 THEN 1 ELSE 0 END) AS with_eng`;

async function pageRows(db, S) {
  const r = await db.batch([
    stmt(db, S, `SELECT pg, COUNT(*) AS views, COUNT(DISTINCT sid) AS sessions, AVG(active_s) AS avg_active, AVG(max_scroll) AS avg_scroll,
      SUM(CASE WHEN max_scroll IS NOT NULL THEN 1 ELSE 0 END) AS m, SUM(CASE WHEN max_scroll < 25 THEN 1 ELSE 0 END) AS s0,
      SUM(CASE WHEN max_scroll >= 25 AND max_scroll < 50 THEN 1 ELSE 0 END) AS s25, SUM(CASE WHEN max_scroll >= 50 AND max_scroll < 75 THEN 1 ELSE 0 END) AS s50,
      SUM(CASE WHEN max_scroll >= 75 THEN 1 ELSE 0 END) AS s75, SUM(CASE WHEN id IN (SELECT fid FROM ss) THEN 1 ELSE 0 END) AS entrances,
      SUM(CASE WHEN id IN (SELECT lid FROM ss) THEN 1 ELSE 0 END) AS exits
      FROM vs GROUP BY pg ORDER BY views DESC LIMIT 30`),
    stmt(db, S, `SELECT ${pageSql('page')} AS pg, COUNT(*) AS n, SUM(CASE WHEN goal IN (${sqlList(STRONG_GOALS)}) THEN 1 ELSE 0 END) AS goals
      FROM ev WHERE page IS NOT NULL GROUP BY pg`)
  ]);
  const evByPage = {};
  rows(r[1]).forEach(x => { evByPage[x.pg] = x; });
  return rows(r[0]).map(p => ({ ...p, events: (evByPage[p.pg] || {}).n || 0, goals: (evByPage[p.pg] || {}).goals || 0 }));
}

// -- core bundle: used by Overview and by the Insights rules ---------------------
async function qCore(db, S, { light = false } = {}) {
  const sts = [
    stmt(db, S, `SELECT COUNT(*) AS sessions, COALESCE(SUM(pages), 0) AS views, COUNT(DISTINCT ip) AS visitors, COALESCE(SUM(engaged), 0) AS engaged,
      COALESCE(SUM(CASE WHEN engaged > 0 THEN 1 ELSE 0 END), 0) AS with_eng, COALESCE(SUM(CASE WHEN cls = 'Bounced' THEN 1 ELSE 0 END), 0) AS bounced,
      COALESCE(SUM(CASE WHEN goals > 0 THEN 1 ELSE 0 END), 0) AS conv, COALESCE(SUM(ev), 0) AS events, COALESCE(SUM(ret), 0) AS ret_n FROM sx`),
    stmt(db, S, `SELECT goal, COUNT(*) AS n, COUNT(DISTINCT sid) AS sessions FROM ev WHERE goal IS NOT NULL GROUP BY goal ORDER BY n DESC`),
    stmt(db, S, `SELECT src, ${GROUP_STATS} FROM sl GROUP BY src ORDER BY sessions DESC`),
    stmt(db, S, `SELECT country, ${GROUP_STATS} FROM sl WHERE country NOT IN ${GEO} GROUP BY country ORDER BY sessions DESC LIMIT 25`)
  ];
  if (!light) sts.push(
    stmt(db, S, `SELECT device, ${GROUP_STATS} FROM sl GROUP BY device ORDER BY sessions DESC`),
    stmt(db, S, BASKET_FUNNEL_SQL),
    stmt(db, S, `SELECT type, label, COUNT(*) AS n FROM ev WHERE type IN ('faq', 'globe', 'plate', 'course', 'search') GROUP BY type, label ORDER BY n DESC LIMIT 80`),
    stmt(db, S, `SELECT CAST(strftime('%w', lts) AS INTEGER) AS dow, CAST(strftime('%H', lts) AS INTEGER) AS hr, COUNT(DISTINCT sid) AS n FROM vs GROUP BY dow, hr`),
    stmt(db, S, `SELECT substr(language, 1, 2) AS lang, COUNT(*) AS sessions FROM sl WHERE language IS NOT NULL GROUP BY lang ORDER BY sessions DESC LIMIT 10`)
  );
  const r = await db.batch(sts);
  const out = { kpi: one(r[0]), goals: rows(r[1]), bySrc: rows(r[2]), byCountry: rows(r[3]) };
  if (!light) {
    out.byDevice = rows(r[4]); out.funnel = one(r[5]); out.topLabels = rows(r[6]); out.heat = rows(r[7]); out.langs = rows(r[8]);
    out.pages = await pageRows(db, S);
  }
  return out;
}

// -- Overview -------------------------------------------------------------------
async function qOverview(db, range, f) {
  const S = scope(range, f);
  const prev = range ? prevRange(range) : null;
  const hourly = range && range.days === 1;
  const [core, prevCore, r] = await Promise.all([
    qCore(db, S),
    prev ? qCore(db, scope(prev, f), { light: true }) : null,
    db.batch([
      stmt(db, S, hourly
        ? `SELECT strftime('%H', lts) AS k, COUNT(*) AS views, COUNT(DISTINCT sid) AS sessions, COUNT(DISTINCT ip_hash) AS visitors FROM vs GROUP BY k ORDER BY k`
        : `SELECT date(lts) AS k, COUNT(*) AS views, COUNT(DISTINCT sid) AS sessions, COUNT(DISTINCT ip_hash) AS visitors FROM vs GROUP BY k ORDER BY k`),
      stmt(db, S, hourly
        ? `SELECT strftime('%H', ${localSql('timestamp')}) AS k, COUNT(*) AS events, SUM(CASE WHEN goal IN (${sqlList(STRONG_GOALS)}) THEN 1 ELSE 0 END) AS goals FROM ev GROUP BY k ORDER BY k`
        : `SELECT date(${localSql('timestamp')}) AS k, COUNT(*) AS events, SUM(CASE WHEN goal IN (${sqlList(STRONG_GOALS)}) THEN 1 ELSE 0 END) AS goals FROM ev GROUP BY k ORDER BY k`),
      stmt(db, S, `SELECT cls, COUNT(*) AS n FROM sx GROUP BY cls`),
      db.prepare(`SELECT country, COUNT(*) AS n FROM visits WHERE country NOT IN ${GEO} GROUP BY country ORDER BY n DESC LIMIT 60`),
      db.prepare(`SELECT substr(language, 1, 2) AS lang, COUNT(*) AS n FROM visits WHERE language IS NOT NULL GROUP BY lang ORDER BY n DESC LIMIT 15`),
      stmt(db, S, `SELECT ret, COUNT(*) AS sessions, SUM(CASE WHEN goals > 0 THEN 1 ELSE 0 END) AS conv FROM sx GROUP BY ret`)
    ])
  ]);
  return {
    core, prev: prevCore, series: { hourly, views: rows(r[0]), events: rows(r[1]) }, classes: rows(r[2]),
    options: { countries: rows(r[3]).map(c => ({ code: c.country, name: countryName(c.country), flag: flagFor(c.country) })), langs: rows(r[4]).map(l => l.lang), sources: SOURCES },
    retSplit: rows(r[5])
  };
}

// -- Pages ----------------------------------------------------------------------
async function qPages(db, range, f) {
  const S = scope(range, f);
  const [pages, r] = await Promise.all([pageRows(db, S), db.batch([
    stmt(db, S, `SELECT prev AS src, pg AS dst, COUNT(*) AS n FROM t WHERE prev IS NOT NULL AND prev != pg GROUP BY prev, pg ORDER BY n DESC LIMIT 20`, [],
      `t AS (SELECT sid, id, pg, LAG(pg) OVER (PARTITION BY sid ORDER BY id) AS prev FROM vs)`),
    stmt(db, S, `SELECT path, COUNT(*) AS n FROM (SELECT sid, GROUP_CONCAT(pg, ' > ') AS path FROM p GROUP BY sid) GROUP BY path ORDER BY n DESC LIMIT 15`, [],
      `p AS (SELECT sid, pg FROM (SELECT sid, id, pg, LAG(pg) OVER (PARTITION BY sid ORDER BY id) AS prev FROM vs) WHERE prev IS NULL OR prev != pg ORDER BY sid, id)`),
    stmt(db, S, `SELECT landing, COUNT(*) AS sessions, SUM(CASE WHEN cls = 'Bounced' THEN 1 ELSE 0 END) AS bounced FROM sl GROUP BY landing ORDER BY sessions DESC LIMIT 10`)
  ])]);
  return { pages, transitions: rows(r[0]), paths: rows(r[1]), landings: rows(r[2]) };
}

// -- Interactions ---------------------------------------------------------------
async function qBehavior(db, range, f) {
  const S = scope(range, f);
  const r = await db.batch([
    stmt(db, S, `SELECT type, COUNT(*) AS n, COUNT(DISTINCT sid) AS sessions FROM ev GROUP BY type ORDER BY n DESC`),
    stmt(db, S, `SELECT type, label, COUNT(*) AS n, COUNT(DISTINCT sid) AS sessions FROM ev GROUP BY type, label ORDER BY n DESC LIMIT 300`),
    stmt(db, S, `SELECT ${pageSql('page')} AS pg, type, COUNT(*) AS n FROM ev WHERE page IS NOT NULL GROUP BY pg, type ORDER BY n DESC LIMIT 60`),
    stmt(db, S, BASKET_FUNNEL_SQL),
    stmt(db, S, `SELECT COUNT(*) AS sessions, COALESCE(SUM(CASE WHEN ev > 0 THEN 1 ELSE 0 END), 0) AS interacted FROM sx`)
  ]);
  const byType = {};
  rows(r[1]).forEach(x => { (byType[x.type] = byType[x.type] || []).push(x); });
  Object.keys(byType).forEach(k => { byType[k] = byType[k].slice(0, 10); });
  return { types: rows(r[0]), labels: byType, byPage: rows(r[2]), funnel: one(r[3]), sessions: one(r[4]) };
}

// -- Sources --------------------------------------------------------------------
async function qSources(db, range, f) {
  const S = scope(range, f);
  const r = await db.batch([
    stmt(db, S, `SELECT src, ${GROUP_STATS} FROM sl GROUP BY src ORDER BY sessions DESC`),
    stmt(db, S, `SELECT referrer, src, ${GROUP_STATS} FROM sl GROUP BY referrer, src ORDER BY sessions DESC LIMIT 25`),
    stmt(db, S, `SELECT COALESCE(utm_source, '') AS source, COALESCE(utm_medium, '') AS medium, COALESCE(utm_campaign, '') AS campaign, ${GROUP_STATS}
      FROM sl WHERE utm_source IS NOT NULL GROUP BY utm_source, utm_medium, utm_campaign ORDER BY sessions DESC LIMIT 30`),
    stmt(db, S, `SELECT landing, src, COUNT(*) AS sessions, SUM(CASE WHEN goals > 0 THEN 1 ELSE 0 END) AS conv FROM sl GROUP BY landing, src ORDER BY sessions DESC LIMIT 20`)
  ]);
  return { sources: rows(r[0]), referrers: rows(r[1]), campaigns: rows(r[2]), landings: rows(r[3]) };
}

// -- Audience -------------------------------------------------------------------
async function qAudience(db, range, f) {
  const S = scope(range, f);
  const r = await db.batch([
    stmt(db, S, `SELECT country, COUNT(DISTINCT ip) AS visitors, ${GROUP_STATS} FROM sl WHERE country NOT IN ${GEO} GROUP BY country ORDER BY sessions DESC LIMIT 40`),
    stmt(db, S, `SELECT city, country, COUNT(*) AS sessions, SUM(CASE WHEN goals > 0 THEN 1 ELSE 0 END) AS conv FROM sl WHERE city NOT IN ('', 'Unknown') GROUP BY city, country ORDER BY sessions DESC LIMIT 30`),
    stmt(db, S, `SELECT device, screen, ${GROUP_STATS} FROM sl GROUP BY device, screen ORDER BY sessions DESC`),
    stmt(db, S, `SELECT browser, COUNT(*) AS sessions FROM sl GROUP BY browser ORDER BY sessions DESC LIMIT 10`),
    stmt(db, S, `SELECT os, COUNT(*) AS sessions FROM sl GROUP BY os ORDER BY sessions DESC LIMIT 10`),
    stmt(db, S, `SELECT substr(language, 1, 2) AS lang, ${GROUP_STATS} FROM sl WHERE language IS NOT NULL GROUP BY lang ORDER BY sessions DESC LIMIT 15`),
    stmt(db, S, `SELECT vhour AS hr, COUNT(*) AS n FROM sl WHERE vhour IS NOT NULL GROUP BY vhour`),
    stmt(db, S, `SELECT CAST(strftime('%w', lts) AS INTEGER) AS dow, CAST(strftime('%H', lts) AS INTEGER) AS hr, COUNT(DISTINCT sid) AS n FROM vs GROUP BY dow, hr`),
    stmt(db, S, `SELECT ret, ${GROUP_STATS} FROM sl GROUP BY ret`),
    stmt(db, S, `SELECT theme, COUNT(*) AS sessions FROM sl WHERE theme IS NOT NULL GROUP BY theme`),
    stmt(db, S, `SELECT continent, COUNT(*) AS sessions FROM sl WHERE continent IS NOT NULL AND continent != '' GROUP BY continent ORDER BY sessions DESC`)
  ]);
  return { countries: rows(r[0]), cities: rows(r[1]), devices: rows(r[2]), browsers: rows(r[3]), os: rows(r[4]), langs: rows(r[5]), localHours: rows(r[6]),
    heat: rows(r[7]), returning: rows(r[8]), themes: rows(r[9]), continents: rows(r[10]) };
}

// -- Goals + funnel -------------------------------------------------------------
async function qGoals(db, range, f) {
  const S = scope(range, f);
  const prev = range ? prevRange(range) : null;
  const [cur, pv, r] = await Promise.all([
    db.batch([stmt(db, S, `SELECT goal, COUNT(*) AS n, COUNT(DISTINCT sid) AS sessions FROM ev WHERE goal IS NOT NULL GROUP BY goal ORDER BY n DESC`)]),
    prev ? db.batch([stmt(db, scope(prev, f), `SELECT goal, COUNT(*) AS n FROM ev WHERE goal IS NOT NULL GROUP BY goal`)]) : null,
    db.batch([
      stmt(db, S, BASKET_FUNNEL_SQL),
      stmt(db, S, `SELECT ${pageSql('page')} AS pg, goal, COUNT(*) AS n FROM ev WHERE goal IS NOT NULL AND page IS NOT NULL GROUP BY pg, goal ORDER BY n DESC LIMIT 40`),
      stmt(db, S, `SELECT date(${localSql('timestamp')}) AS k, COUNT(*) AS n FROM ev WHERE goal IN (${sqlList(STRONG_GOALS)}) GROUP BY k ORDER BY k`),
      stmt(db, S, `SELECT device, ${GROUP_STATS} FROM sl GROUP BY device`),
      stmt(db, S, `SELECT src, ${GROUP_STATS} FROM sl GROUP BY src`),
      stmt(db, S, `SELECT COUNT(*) AS sessions, COALESCE(SUM(CASE WHEN goals > 0 THEN 1 ELSE 0 END), 0) AS conv FROM sx`)
    ])
  ]);
  const prevMap = {};
  if (pv) rows(pv[0]).forEach(g => { prevMap[g.goal] = g.n; });
  const goals = rows(cur[0]).map(g => ({ ...g, prev: pv ? (prevMap[g.goal] || 0) : null, strong: STRONG_GOALS.includes(g.goal) }));
  return { goals, funnel: one(r[0]), byPage: rows(r[1]), daily: rows(r[2]), byDevice: rows(r[3]), bySrc: rows(r[4]), totals: one(r[5]), hasPrev: !!pv };
}

// -- Sessions -------------------------------------------------------------------
async function qSessions(db, range, f, { limit = 50, offset = 0, only = '', max = 5000 } = {}) {
  const S = scope(range, f);
  const cond = only === 'goal' ? 'WHERE goals > 0' : only === 'bounced' ? "WHERE cls = 'Bounced'" : only === 'returning' ? 'WHERE ret = 1' : '';
  const lim = Math.min(max, Math.max(1, limit));
  const [list, total] = await Promise.all([
    db.batch([stmt(db, S, `SELECT sl.sid, t0, t1, pages, engaged, scroll, ev, goals, cls, ret, country, city, region, device, browser, os, language, screen, src, referrer, utm_campaign, landing,
      (SELECT pg FROM vs WHERE vs.id = sl.lid) AS exit_page FROM sl ${cond} ORDER BY t0 DESC LIMIT ? OFFSET ?`, [lim, Math.max(0, offset)])]),
    db.batch([stmt(db, S, `SELECT COUNT(*) AS n FROM sl ${cond}`)])
  ]);
  const sessions = rows(list[0]);
  const ids = sessions.map(s => s.sid);
  if (ids.length) {
    const ph = ids.map(() => '?').join(',');
    const g = await db.prepare(`SELECT visitor_token AS sid, ${GOAL_SQL} AS goal FROM events WHERE visitor_token IN (${ph})`).bind(...ids).all();
    const map = {};
    rows(g).forEach(x => { if (x.goal) (map[x.sid] = map[x.sid] || new Set()).add(x.goal); });
    sessions.forEach(s => { s.goal_names = [...(map[s.sid] || [])]; });
  }
  return { sessions, total: one(total[0]).n || 0 };
}

async function qSession(db, sid) {
  if (!/^[A-Za-z0-9-]{1,64}$/.test(sid)) throw new HttpError(400, 'Invalid session id');
  const byRowId = /^u\d+$/.test(sid);
  const views = await db.prepare(byRowId
    ? 'SELECT * FROM visits WHERE id = ? ORDER BY id'
    : 'SELECT * FROM visits WHERE visitor_token = ? ORDER BY id').bind(byRowId ? Number(sid.slice(1)) : sid).all();
  const v = rows(views);
  if (!v.length) throw new HttpError(404, 'Session not found');
  const first = v[0];
  const [ev, hist] = await db.batch([
    db.prepare(`SELECT id, type, label, url, page, meta, timestamp, ${GOAL_SQL} AS goal FROM events WHERE visitor_token = ? ORDER BY id`).bind(byRowId ? '-' : sid),
    db.prepare(`SELECT COALESCE(NULLIF(visitor_token, 'unknown'), 'u' || id) AS sid, MIN(timestamp) AS t0, COUNT(*) AS pages FROM visits WHERE ip_hash = ? GROUP BY sid ORDER BY t0 DESC LIMIT 25`).bind(first.ip_hash)
  ]);
  const events = rows(ev);
  const timeline = [
    ...v.map(x => ({ t: x.timestamp, kind: 'view', page: x.page, pg: x.page, active_s: x.active_s, scroll: x.max_scroll, referrer: x.referrer, order: 0 })),
    ...events.map(x => ({ t: x.timestamp, kind: 'event', type: x.type, label: x.label, url: x.url, page: x.page, goal: x.goal, meta: x.meta, order: 1 }))
  ].sort((a, b) => (a.t < b.t ? -1 : a.t > b.t ? 1 : a.order - b.order));
  const history = rows(hist);
  const engaged = v.reduce((a, x) => a + (x.active_s || 0), 0);
  return {
    sid, visitor: (first.ip_hash || '').slice(0, 8), t0: v[0].timestamp, t1: v[v.length - 1].timestamp, pages: v.length, engaged,
    scroll: Math.max(0, ...v.map(x => x.max_scroll || 0)), events: events.length, goals: [...new Set(events.filter(e => e.goal).map(e => e.goal))],
    country: first.country, countryName: countryName(first.country), flag: flagFor(first.country), city: first.city, region: first.region, continent: first.continent,
    device: first.device, browser: first.browser, os: first.os, language: first.language, screen: first.screen, theme: first.theme, visitorHour: first.visitor_hour,
    referrer: first.referrer, utm: { source: first.utm_source, medium: first.utm_medium, campaign: first.utm_campaign, term: first.utm_term, content: first.utm_content },
    returning: history.length > 1, otherSessions: history.filter(h => h.sid !== sid), timeline
  };
}

// -- Live -----------------------------------------------------------------------
async function qLive(db) {
  const now = Date.now();
  const since5 = new Date(now - 5 * 60e3).toISOString(), since60 = new Date(now - 60 * 60e3).toISOString(), since30 = new Date(now - 30 * 60e3).toISOString();
  const r = await db.batch([
    db.prepare(`SELECT sid, MAX(timestamp) AS last, MIN(timestamp) AS first, COUNT(*) AS pages, country, city, device, MAX(id) AS lid FROM
        (SELECT *, COALESCE(NULLIF(visitor_token, 'unknown'), 'u' || id) AS sid FROM visits WHERE timestamp >= ?) GROUP BY sid ORDER BY last DESC LIMIT 30`).bind(since5),
    db.prepare(`SELECT * FROM (
        SELECT 'view' AS kind, timestamp AS t, page AS label, country, COALESCE(NULLIF(visitor_token, 'unknown'), 'u' || id) AS sid, NULL AS goal FROM visits WHERE timestamp >= ?
        UNION ALL SELECT type AS kind, timestamp AS t, label, country, visitor_token AS sid, ${GOAL_SQL} AS goal FROM events WHERE timestamp >= ?
      ) ORDER BY t DESC LIMIT 40`).bind(since60, since60),
    db.prepare(`SELECT substr(timestamp, 1, 16) AS m, COUNT(*) AS n FROM visits WHERE timestamp >= ? GROUP BY m ORDER BY m`).bind(since30)
  ]);
  const active = rows(r[0]);
  const pageIds = active.map(a => a.lid);
  let pages = {};
  if (pageIds.length) {
    const ph = pageIds.map(() => '?').join(',');
    rows(await db.prepare(`SELECT id, page FROM visits WHERE id IN (${ph})`).bind(...pageIds).all()).forEach(x => { pages[x.id] = x.page; });
  }
  const label = p => (p || '').replace(SITE_BASE, '').replace(/^\/+/, '').replace(/\.html$/, '') || 'index';
  return {
    now: new Date(now).toISOString(),
    active: active.map(a => ({ sid: a.sid, last: a.last, first: a.first, pages: a.pages, country: a.country, countryName: countryName(a.country), flag: flagFor(a.country), city: a.city, device: a.device, page: label(pages[a.lid]) })),
    feed: rows(r[1]).map(x => ({ ...x, flag: flagFor(x.country), countryName: countryName(x.country), label: x.kind === 'view' ? label(x.label) : x.label })),
    perMinute: rows(r[2])
  };
}

// -- Filter options (cheap, all-time) ------------------------------------------------
async function qOptions(db) {
  const r = await db.batch([
    db.prepare(`SELECT country, COUNT(*) AS n FROM visits WHERE country NOT IN ${GEO} GROUP BY country ORDER BY n DESC LIMIT 80`),
    db.prepare(`SELECT substr(language, 1, 2) AS lang, COUNT(*) AS n FROM visits WHERE language IS NOT NULL GROUP BY lang ORDER BY n DESC LIMIT 20`)
  ]);
  return { countries: rows(r[0]).map(c => c.country), langs: rows(r[1]).map(l => l.lang) };
}

// -- Data health ----------------------------------------------------------------
async function qHealth(db, env) {
  const r = await db.prepare(`SELECT (SELECT COUNT(*) FROM visits) AS visits, (SELECT COUNT(*) FROM events) AS events, (SELECT MIN(timestamp) FROM visits) AS oldest,
    (SELECT MAX(timestamp) FROM visits) AS newest, (SELECT MAX(timestamp) FROM events) AS newest_event,
    (SELECT COUNT(*) FROM visits WHERE active_s IS NOT NULL) AS with_engagement, (SELECT COUNT(*) FROM visits WHERE language IS NOT NULL) AS with_language,
    (SELECT COUNT(*) FROM visits WHERE timestamp >= ?) AS last_7d`).bind(new Date(Date.now() - 7 * 864e5).toISOString()).first();
  const raw = String(env.RETENTION_DAYS === undefined ? DEFAULT_RETENTION_DAYS : env.RETENTION_DAYS);
  return { ...r, retentionDays: raw, hashKeyed: !!env.IP_HASH_SECRET };
}

// -- CSV export (formula-injection safe) -------------------------------------------
const csvCell = v => {
  let s = v === null || v === undefined ? '' : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
const toCsv = (cols, data) => '\ufeff' + cols.join(',') + '\r\n' + data.map(r => cols.map(c => csvCell(r[c])).join(',')).join('\r\n') + '\r\n';

async function exportCsv(db, kind, range, f) {
  if (kind === 'sessions') {
    const { sessions } = await qSessions(db, range, f, { limit: 5000, max: 5000 });
    const data = sessions.map(s => ({ ...s, goal_names: (s.goal_names || []).join('; '), country_name: countryName(s.country) }));
    return toCsv(['t0', 't1', 'sid', 'country', 'country_name', 'region', 'city', 'device', 'browser', 'os', 'language', 'screen', 'src', 'referrer', 'utm_campaign', 'landing', 'exit_page', 'pages', 'engaged', 'scroll', 'ev', 'goals', 'goal_names', 'cls', 'ret'], data);
  }
  const S = scope(range, f);
  if (kind === 'events') {
    const r = await stmt(db, S, `SELECT timestamp, sid, type, label, url, page, meta, goal FROM ev ORDER BY id DESC LIMIT 20000`).all();
    return toCsv(['timestamp', 'sid', 'type', 'label', 'url', 'page', 'meta', 'goal'], rows(r));
  }
  const r = await stmt(db, S, `SELECT timestamp, sid, country, region, city, pg, page, device, browser, os, language, screen, theme, referrer, src, utm_source, utm_medium, utm_campaign, active_s, max_scroll FROM vs ORDER BY id DESC LIMIT 20000`).all();
  return toCsv(['timestamp', 'sid', 'country', 'region', 'city', 'pg', 'page', 'device', 'browser', 'os', 'language', 'screen', 'theme', 'referrer', 'src', 'utm_source', 'utm_medium', 'utm_campaign', 'active_s', 'max_scroll'], rows(r));
}

