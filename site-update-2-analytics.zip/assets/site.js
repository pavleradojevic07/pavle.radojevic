/* site.js - behaviour shared by every page. One copy instead of eight pasted ones.
   Sections: 1 search index  2 theme + menu  3 consent + analytics  4 shared UI  5 video facade
   When you add a page or a section worth finding, add a line to SITE_INDEX below. */
(function () {
    'use strict';

    /* named interactions: a no-op until the visitor accepted analytics, then reported by section 3 */
    var trackImpl = null;
    function siteTrack(type, label, url, meta) { if (trackImpl) trackImpl(type, label, url, meta); }
    window.siteTrack = siteTrack;

    /* ── 1. Search index (the only copy) ── */
    var SITE_INDEX = [
        { title: 'Home', url: 'index.html', desc: 'Basketball, academics, license plate atlas' },
        { title: 'Basketball', url: 'basketball.html', desc: 'Player profile, height, weight, position' },
        { title: 'Playing history', url: 'basketball.html', desc: 'KK Portoro\u017e, KK Borac Zemun, Honv\u00e9d Academy, EYBL' },
        { title: 'Highlight video', url: 'basketball.html#highlights', desc: 'Highlights 2025/26, Eurobasket, KZS, SofaScore, Proballers' },
        { title: 'Player sheet (PDF)', url: 'files/pavle-radojevic-player-sheet.pdf', desc: 'One-page profile for coaches, clubs and recruiters' },
        { title: 'Career achievements', url: 'basketball.html#achievements', desc: 'National team camp, NB II champion, tournaments' },
        { title: 'Career highs', url: 'basketball.html#career-highs', desc: 'Points, rebounds, assists, blocks' },
        { title: 'Basketball FAQ', url: 'basketball.html#faq', desc: 'Contact, stats, recruiting questions' },
        { title: 'Academic', url: 'academic.html', desc: 'University of Primorska, FAMNIT, Koper' },
        { title: 'Courses', url: 'academic.html#courses', desc: 'Completed at University of Belgrade: programming, linear algebra, logic' },
        { title: 'Languages', url: 'academic.html#languages', desc: 'Serbian, English, Hungarian' },
        { title: 'Activities & leadership', url: 'academic.html#activities', desc: 'GDG on Campus UP core team: events, marketing, tech support' },
        { title: 'License plate atlas', url: 'plates.html', desc: 'Interactive globe and collection stats' },
        { title: 'Visitor map', url: 'visitors.html', desc: 'Visitor statistics by country' },
        { title: 'Privacy policy', url: 'privacy.html', desc: 'Data, analytics, your rights' },
        { title: 'Terms & conditions', url: 'terms.html', desc: 'Use of this site' },
        { title: 'Cookie policy', url: 'cookies.html', desc: 'Cookies, storage, consent' }
    ];

    function cookieFlags() { return ';path=/;max-age=' + (60 * 60 * 24 * 365) + ';SameSite=Lax' + (location.protocol === 'https:' ? ';Secure' : ''); }

    /* ── 2. Theme toggle + mobile menu ── */
    var themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '\u2600\uFE0F' : '\uD83C\uDF19';
        themeToggle.addEventListener('click', function () {
            var html = document.documentElement;
            var next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            themeToggle.textContent = next === 'dark' ? '\u2600\uFE0F' : '\uD83C\uDF19';
            document.cookie = 'theme=' + next + cookieFlags();
            siteTrack('theme', 'to ' + next);
        });
    }
    var mobileMenuBtn = document.getElementById('mobileMenuBtn');
    var navLinks = document.getElementById('navLinks');
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function () {
            navLinks.classList.toggle('mobile-open');
            var open = navLinks.classList.contains('mobile-open');
            mobileMenuBtn.textContent = open ? '\u2715' : '\u2630';
            mobileMenuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    /* ── 3. Consent banner + first-party analytics (only runs after Accept, never after Decline) ── */
    (function () {
        var WORKER_URL = 'https://visitor-tracker.pavle-radojevic3.workers.dev';
        var MAX_IDLE_MINUTES = 30;
        var CONSENT_COOKIE = 'analytics-consent';
        var IGNORE_COOKIE = 'analytics-ignore';
        var SESSION_KEYS = ['visitorToken', 'entryTime', 'lastPage', 'utmParams'];

        function getCookie(name) {
            var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
            return match ? match[2] : null;
        }
        function clearSession() { SESSION_KEYS.forEach(function (k) { try { sessionStorage.removeItem(k); } catch (e) {} }); }
        function setConsentCookie(value) {
            if (value !== 'accepted') clearSession();
            document.cookie = CONSENT_COOKIE + '=' + value + cookieFlags();
        }
        function uid() { return crypto.randomUUID ? crypto.randomUUID() : (Math.random().toString(36).slice(2) + Date.now().toString(36)); }
        function getUTMParams() {
            var params = new URLSearchParams(window.location.search);
            var utm = {}, found = false;
            ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'].forEach(function (k) {
                var v = params.get(k);
                if (v) { utm[k] = v.slice(0, 100); found = true; }
            });
            if (found) { sessionStorage.setItem('utmParams', JSON.stringify(utm)); return utm; }
            try { var stored = sessionStorage.getItem('utmParams'); return stored ? JSON.parse(stored) : {}; } catch (e) { return {}; }
        }
        function post(path, body, keepalive) {
            return fetch(WORKER_URL + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), keepalive: !!keepalive }).catch(function () {});
        }
        function where(el) {
            return el.closest('#floatingContactPanel') ? 'floating' : el.closest('.contact-footer') ? 'footer' : el.closest('.profile-cta') ? 'profile' : el.closest('.home-intro') ? 'home' : 'page';
        }

        function runTracking() {
            if (!sessionStorage.getItem('visitorToken')) sessionStorage.setItem('visitorToken', uid());
            var visitorToken = sessionStorage.getItem('visitorToken');
            var pvId = uid();                       // one id per page view: ties the time/scroll report to its row

            function getEntryTime() {
                var stored = sessionStorage.getItem('entryTime');
                if (!stored) return null;
                if (Date.now() - new Date(stored).getTime() > MAX_IDLE_MINUTES * 60 * 1000) { sessionStorage.removeItem('entryTime'); return null; }
                return stored;
            }
            var entryTime = getEntryTime();
            if (!entryTime) { entryTime = new Date().toISOString(); sessionStorage.setItem('entryTime', entryTime); }

            var refTag = (new URLSearchParams(window.location.search).get('ref') || '').slice(0, 60);   // ?ref=linkedin tags a shared link
            var referrer = refTag || document.referrer || 'Direct';
            var w = window.innerWidth;
            var ua = navigator.userAgent;
            post('/track', {
                browser: ua.includes('Firefox') ? 'Firefox' : ua.includes('Chrome') ? 'Chrome' : ua.includes('Safari') ? 'Safari' : 'Other',
                os: navigator.platform || 'Unknown',
                device: /Mobi|Android/i.test(ua) ? 'Mobile' : 'Desktop',
                referrer: referrer,
                page: window.location.pathname,
                entryTime: entryTime,
                previousPage: sessionStorage.getItem('lastPage') || null,
                visitorToken: visitorToken,
                utm: getUTMParams(),
                pvId: pvId,
                language: (navigator.language || '').slice(0, 16),
                screen: w < 480 ? 'xs' : w < 768 ? 'sm' : w < 1100 ? 'md' : w < 1600 ? 'lg' : 'xl',        // a size class, never exact pixels
                theme: document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark'
            });
            sessionStorage.setItem('lastPage', window.location.pathname);

            /* what the visitor does: named interactions (a label, never typed text) */
            var sent = 0, lastKey = '', lastAt = 0;
            trackImpl = function (type, label, url, meta) {
                var key = type + '|' + label, now = Date.now();
                if (sent >= 60 || (key === lastKey && now - lastAt < 1500)) return;     // no floods, no double clicks
                sent++; lastKey = key; lastAt = now;
                post('/track-event', { type: type, label: String(label || '').slice(0, 150), url: url || '', referrer: refTag || document.referrer || 'Direct',
                    page: window.location.pathname, visitorToken: visitorToken, pvId: pvId, meta: meta || null });
            };

            document.addEventListener('click', function (e) {
                var t = e.target;
                if (!t || !t.closest) return;
                var link = t.closest('a');
                if (link) {
                    var href = link.getAttribute('href') || '';
                    var label = link.getAttribute('data-label') || link.textContent.replace(/\s+/g, ' ').trim();
                    var meta = { where: where(link) };
                    if (link.classList.contains('video-facade')) trackImpl('video', label || 'Video', href, meta);
                    else if (/^mailto:/i.test(href)) trackImpl('contact', label || 'Email link', href, meta);
                    else if (/\.pdf$/i.test(href) || link.hasAttribute('download') || link.classList.contains('pdf-link')) trackImpl('download', label || 'PDF Download', href, meta);
                    else if (link.hostname && link.hostname !== window.location.hostname) trackImpl('click', label || link.href, href, meta);
                    else if (link.classList.contains('intro-btn')) trackImpl('cta', label, href, meta);
                    return;
                }
                var el;
                if ((el = t.closest('.course-card')) && el.classList.contains('open')) {            // opened (not closed) a course
                    var nm = el.querySelector('.course-name');
                    trackImpl('course', nm ? nm.textContent.replace(/\s+/g, ' ').trim() : 'Course');
                } else if ((el = t.closest('.gallery-item'))) {
                    trackImpl('plate', (el.getAttribute('aria-label') || '').replace(/^View | plate$/g, '') || 'Plate');
                } else if ((el = t.closest('.plate-item'))) {
                    trackImpl('plate', (el.getAttribute('aria-label') || '').replace(/^.* from /, '') || 'Plate');
                } else if ((el = t.closest('#searchDropdown li'))) {
                    trackImpl('globe', el.getAttribute('data-name') || 'Country');
                } else if (t.closest('#donationBtn')) {
                    var box = document.getElementById('donationText');
                    if (box && box.value.trim()) trackImpl('contact', 'Plate donation offer', '', { where: 'atlas' });
                }
            });

            /* how long they really stayed (tab visible and recent activity) and how far they scrolled */
            var active = 0, lastAct = Date.now(), maxScroll = 0, sentA = -1, sentS = -1;
            ['mousemove', 'keydown', 'scroll', 'touchstart', 'click', 'wheel'].forEach(function (ev) { window.addEventListener(ev, function () { lastAct = Date.now(); }, { passive: true }); });
            setInterval(function () { if (document.visibilityState === 'visible' && Date.now() - lastAct < 15000 && active < 1800) active++; }, 1000);
            function measureScroll() {
                var d = document.documentElement, sh = d.scrollHeight, ch = d.clientHeight, st = window.pageYOffset || d.scrollTop || 0;
                var pct = sh - ch <= 4 ? 100 : Math.min(100, Math.round((st + ch) / sh * 100));
                if (pct > maxScroll) maxScroll = pct;
            }
            window.addEventListener('scroll', measureScroll, { passive: true });
            measureScroll();
            function flush() {
                measureScroll();
                if (active === sentA && maxScroll === sentS) return;
                sentA = active; sentS = maxScroll;
                post('/track-engage', { pvId: pvId, visitorToken: visitorToken, active: active, scroll: maxScroll }, true);
            }
            document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
            window.addEventListener('pagehide', flush);
            setInterval(function () { if (document.visibilityState === 'visible') flush(); }, 30000);
        }

        /* Opt-out link for your own browsers: open any page with ?notrack=1 (and ?notrack=0 to undo) */
        var optOut = new URLSearchParams(window.location.search).get('notrack');
        if (optOut === '1') document.cookie = IGNORE_COOKIE + '=1' + cookieFlags();
        else if (optOut === '0') document.cookie = IGNORE_COOKIE + '=; path=/; max-age=0; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
        if (getCookie(IGNORE_COOKIE) === '1' && optOut !== '0') return;

        var consent = getCookie(CONSENT_COOKIE);
        var banner = document.getElementById('analytics-consent-banner');
        if (consent === 'accepted') {
            runTracking();
        } else if (consent !== 'declined' && banner) {
            banner.classList.add('visible');
            var acceptBtn = document.getElementById('acAcceptBtn');
            var declineBtn = document.getElementById('acDeclineBtn');
            if (acceptBtn) acceptBtn.addEventListener('click', function () { setConsentCookie('accepted'); banner.classList.remove('visible'); runTracking(); });
            if (declineBtn) declineBtn.addEventListener('click', function () { setConsentCookie('declined'); banner.classList.remove('visible'); });
        }
    })();

    /* ── 4. Shared UI: progress bar, back to top, floating contact, search, copy email, cookie modal, FAQ, shortcuts ── */
    var progressBar = document.getElementById('scrollProgressBar');
    var backToTopBtn = document.getElementById('backToTopBtn');
    function onScroll() {
        var doc = document.documentElement;
        var scrollTop = doc.scrollTop || document.body.scrollTop;
        var scrollable = doc.scrollHeight - doc.clientHeight;
        if (progressBar) progressBar.style.width = (scrollable > 0 ? (scrollTop / scrollable) * 100 : 0) + '%';
        if (backToTopBtn) backToTopBtn.classList.toggle('visible', scrollTop > 400);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    if (backToTopBtn) {
        backToTopBtn.addEventListener('click', function () {
            var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
        });
    }

    var fcToggle = document.getElementById('floatingContactToggle');
    var fcPanel = document.getElementById('floatingContactPanel');
    var fcWrap = document.getElementById('floatingContact');
    function closeFc() {
        if (!fcPanel || !fcToggle) return;
        fcPanel.classList.remove('open');
        fcToggle.setAttribute('aria-expanded', 'false');
    }
    if (fcToggle && fcPanel) {
        fcToggle.addEventListener('click', function () {
            var open = fcPanel.classList.toggle('open');
            fcToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        document.addEventListener('click', function (e) { if (fcWrap && !fcWrap.contains(e.target)) closeFc(); });
    }

    var banner = document.getElementById('analytics-consent-banner');
    function adjustForBanner() {
        if (!banner || !fcWrap || !backToTopBtn) return;
        var offset = banner.classList.contains('visible') ? banner.offsetHeight + 16 : 24;
        fcWrap.style.bottom = offset + 'px';
        backToTopBtn.style.bottom = offset + 'px';
    }
    adjustForBanner();
    if (banner && window.MutationObserver) new MutationObserver(adjustForBanner).observe(banner, { attributes: true, attributeFilter: ['class'] });
    window.addEventListener('resize', adjustForBanner);

    /* Site search */
    var searchTrigger = document.getElementById('siteSearchTrigger');
    var searchOverlay = document.getElementById('siteSearchOverlay');
    var searchInputEl = document.getElementById('siteSearchInput');
    var searchResultsEl = document.getElementById('siteSearchResults');
    var lastFocus = null;
    function escapeHtml(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
    function renderResults(q) {
        if (!searchResultsEl) return;
        var query = q.trim().toLowerCase();
        var matches = SITE_INDEX.filter(function (item) {
            return !query || item.title.toLowerCase().indexOf(query) !== -1 || item.desc.toLowerCase().indexOf(query) !== -1;
        });
        if (matches.length === 0) { searchResultsEl.innerHTML = '<div id="siteSearchEmpty">No matches. Try a different word.</div>'; return; }
        searchResultsEl.innerHTML = matches.map(function (item) {
            return '<a href="' + item.url + '"><strong>' + escapeHtml(item.title) + '</strong><div class="result-desc">' + escapeHtml(item.desc) + '</div></a>';
        }).join('');
    }
    function openSearch() {
        if (!searchOverlay) return;
        lastFocus = document.activeElement;
        searchOverlay.classList.add('open');
        renderResults('');
        setTimeout(function () { if (searchInputEl) searchInputEl.focus(); }, 30);
    }
    function closeSearch() {
        if (!searchOverlay) return;
        searchOverlay.classList.remove('open');
        if (searchInputEl) searchInputEl.value = '';
        if (lastFocus && lastFocus.focus) lastFocus.focus();
    }
    if (searchTrigger) searchTrigger.addEventListener('click', openSearch);
    if (searchInputEl) {
        searchInputEl.addEventListener('input', function () { renderResults(this.value); });
        searchInputEl.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                var first = searchResultsEl && searchResultsEl.querySelector('a');
                if (first) { var st = first.querySelector('strong'); siteTrack('search', st ? st.textContent : 'Result'); window.location.href = first.getAttribute('href'); }
            }
        });
    }
    if (searchOverlay) searchOverlay.addEventListener('click', function (e) { if (e.target === searchOverlay) closeSearch(); });
    if (searchResultsEl) searchResultsEl.addEventListener('click', function (e) { var a = e.target.closest && e.target.closest('a'); if (a) { var st = a.querySelector('strong'); siteTrack('search', st ? st.textContent : 'Result'); } });

    /* Copy email */
    document.querySelectorAll('.copy-email-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var email = btn.getAttribute('data-email');
            function done() { siteTrack('contact', 'Copy email', 'mailto:' + email, { where: 'footer' }); btn.textContent = 'Copied'; setTimeout(function () { btn.textContent = 'Copy'; }, 1800); }
            function fallback() {
                var ta = document.createElement('textarea');
                ta.value = email; ta.style.position = 'fixed'; ta.style.opacity = '0';
                document.body.appendChild(ta); ta.select();
                try { document.execCommand('copy'); done(); } catch (err) { btn.textContent = 'Press Ctrl+C'; }
                document.body.removeChild(ta);
            }
            if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(email).then(done).catch(fallback);
            else fallback();
        });
    });

    /* Cookie preferences: confirm, then clear the consent choice so the banner returns */
    var cookieModal = document.getElementById('cookiePrefsConfirmModal');
    var cookieCancelBtn = document.getElementById('cookiePrefsCancelBtn');
    var cookieConfirmBtn = document.getElementById('cookiePrefsConfirmBtn');
    var cookieLastFocus = null;
    function openCookieModal() {
        if (!cookieModal) return;
        cookieLastFocus = document.activeElement;
        cookieModal.classList.add('open');
        if (cookieConfirmBtn) cookieConfirmBtn.focus();
    }
    function closeCookieModal() {
        if (!cookieModal) return;
        cookieModal.classList.remove('open');
        if (cookieLastFocus && cookieLastFocus.focus) cookieLastFocus.focus();
    }
    if (cookieCancelBtn) cookieCancelBtn.addEventListener('click', closeCookieModal);
    if (cookieModal) cookieModal.addEventListener('click', function (e) { if (e.target === cookieModal) closeCookieModal(); });
    if (cookieConfirmBtn) cookieConfirmBtn.addEventListener('click', function () {
        ['visitorToken', 'entryTime', 'lastPage', 'utmParams'].forEach(function (k) { try { sessionStorage.removeItem(k); } catch (e) {} });
        document.cookie = 'analytics-consent=; path=/; max-age=0; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
        location.reload();
    });
    window.openCookiePrefsConfirm = openCookieModal;
    ['cookiePrefsBtn', 'cookiePrefsBtnMain'].forEach(function (id) {
        var b = document.getElementById(id);
        if (b) b.addEventListener('click', openCookieModal);
    });

    /* FAQ accordion */
    document.querySelectorAll('.faq-item').forEach(function (item) {
        function toggle() {
            var opening = item.getAttribute('aria-expanded') !== 'true';
            item.setAttribute('aria-expanded', opening ? 'true' : 'false');
            if (opening) { var q = item.querySelector('.faq-question'); siteTrack('faq', q ? q.textContent.trim() : 'FAQ'); }
        }
        item.addEventListener('click', toggle);
        item.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') { e.preventDefault(); toggle(); }
        });
    });

    /* Shortcuts: Ctrl/Cmd+K opens search, Escape closes any open overlay */
    document.addEventListener('keydown', function (e) {
        if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) { e.preventDefault(); openSearch(); }
        if (e.key === 'Escape') {
            if (searchOverlay && searchOverlay.classList.contains('open')) closeSearch();
            if (cookieModal && cookieModal.classList.contains('open')) closeCookieModal();
            closeFc();
        }
    });

    /* ── 5. Video facade: nothing is requested from YouTube until the visitor presses play ── */
    document.querySelectorAll('.video-facade').forEach(function (facade) {
        facade.addEventListener('click', function (e) {
            if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return;   // let "open in new tab" work
            var id = facade.getAttribute('data-video-id') || '';
            if (!/^[A-Za-z0-9_-]{6,20}$/.test(id)) return;                          // bad id: fall back to the plain link
            e.preventDefault();
            var frame = document.createElement('iframe');
            frame.src = 'https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0';
            frame.title = facade.getAttribute('data-title') || 'Video';
            frame.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
            frame.setAttribute('allowfullscreen', '');
            frame.referrerPolicy = 'strict-origin-when-cross-origin';
            facade.parentNode.replaceChild(frame, facade);
            frame.focus();
        });
    });
})();
