#!/usr/bin/env python3
"""apply_dashboard_update.py - makes the consent banner, Privacy Policy and Cookie Policy describe the richer analytics
that the new assets/site.js collects (time on page, scroll depth, key interactions, language, screen-size class...).

Run from the repository root (the folder with index.html), AFTER copying the bundle in:

    python apply_dashboard_update.py --dry-run
    python apply_dashboard_update.py

Safe to run twice. Each page is all-or-nothing: if a sentence cannot be found, that page is left untouched and the
problem is printed. Windows (CRLF) line endings are preserved.
"""
import argparse
import datetime
import re
import sys
from pathlib import Path

ROOT = Path.cwd()
PAGES = ["index", "basketball", "academic", "plates", "visitors", "privacy", "terms", "cookies"]
d = datetime.date.today()
TODAY = f"{d:%B} {d.day}, {d.year}"

BANNER_OLD = r"\(page views, browser/device, approximate location, and clicks on outbound links and downloads\) to see where visitors come from\."
BANNER_NEW = ("(page views, browser/device and language, approximate location, time on page and scroll depth, and clicks on key buttons, "
              "links and downloads) to understand how the site is used.")


class Ctx:
    def __init__(self):
        self.log, self.problems = [], []
    def ok(self, m): self.log.append("  + " + m)
    def skip(self, m): self.log.append("  . " + m + " (already done)")
    def bad(self, m): self.problems.append(m); self.log.append("  ! " + m)


def sub1(text, ctx, label, pattern, repl, marker, flags=re.S):
    if marker in text:
        ctx.skip(label); return text
    new, n = re.subn(pattern, lambda m: repl(m) if callable(repl) else repl, text, count=1, flags=flags)
    if n == 0:
        ctx.bad(f"{label}: sentence not found"); return text
    ctx.ok(label); return new


def step_banner(text, ctx):
    return sub1(text, ctx, "consent banner text", BANNER_OLD, BANNER_NEW, "time on page and scroll depth")


def step_privacy(text, ctx):
    t = sub1(text, ctx, "privacy: browser/device bullet", r"<li>Browser type, operating system, and device type \(mobile/desktop\)</li>",
             "<li>Browser type, operating system, device type (mobile/desktop), your browser language, a screen-size class (small, medium or large, never exact pixels) "
             "and whether you use the light or dark theme</li>", "a screen-size class")
    t = sub1(t, ctx, "privacy: location bullet", r"<li>Approximate location \(country/city, derived from your IP address\)</li>",
             "<li>Approximate location (country, region and city, derived from your IP address) and the time of day where you are. Only the hour is kept, not your time zone</li>",
             "and the time of day where you are")
    t = sub1(t, ctx, "privacy: time and scroll bullet", r"(<li>Session timing \(arrival time, time spent\).*?</li>)",
             lambda m: m.group(1) + "\n                    <li>How long you were actually active on each page (while the tab is visible and you are moving, scrolling or typing) and how far down the page you scrolled, as a percentage</li>",
             "how far down the page you scrolled")
    t = sub1(t, ctx, "privacy: interactions bullet", r"(<li>Clicks on outbound links.*?</li>)",
             lambda m: m.group(1) + "\n                    <li>Key interactions, each recorded only as a name and never as text you typed: pressing play on the highlight video, downloading the player sheet or other files, "
             "pressing an email or contact button or copying the email address, opening an FAQ answer or a course, opening a license plate or choosing a country on the Atlas, "
             "picking a result in the site search, and switching between light and dark theme</li>", "Key interactions, each recorded only as a name")
    t = sub1(t, ctx, "privacy: purpose sentence", r"This data is used only to see which pages and countries visitors come from\.",
             "This data is used only to understand how the site is used (which pages, sections and countries get attention) so that I can improve it.",
             "so that I can improve it")
    t = sub1(t, ctx, "privacy: opt-out sentence",
             r"(<p>You can change your analytics choice at any time using the <strong>Cookie Preferences</strong> link in the footer of any page, or by clearing this site's cookies in your browser settings\.)(</p>)",
             lambda m: m.group(1) + " You can also switch analytics off for good in a browser by opening any page of this site with <code>?notrack=1</code> at the end of the address (<code>?notrack=0</code> turns it back on)." + m.group(2),
             "?notrack=1")
    return t


COOKIE_ROW = """
                            <tr>
                                <td><code>analytics-ignore</code></td>
                                <td>First-party cookie</td>
                                <td>Only set if you open a page of this site with <code>?notrack=1</code> at the end of the address. It tells the site not to run analytics in that browser</td>
                                <td>1 year</td>
                                <td><span class="pill pill-necessary">Necessary</span></td>
                            </tr>"""


def step_cookies(text, ctx):
    return sub1(text, ctx, "cookies: analytics-ignore row", r"(<tr>\s*<td><code>analytics-consent</code></td>.*?</tr>)",
                lambda m: m.group(1) + COOKIE_ROW, "analytics-ignore")


STEPS = {p: [step_banner] for p in PAGES}
STEPS["privacy"].append(step_privacy)
STEPS["cookies"].append(step_cookies)
LEGAL_DATED = {"privacy", "cookies"}


def process(page, dry):
    path = ROOT / f"{page}.html"
    ctx = Ctx()
    if not path.exists():
        ctx.bad("file not found"); return ctx
    raw = path.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    original = raw.replace("\r\n", "\n")
    text = original
    for step in STEPS[page]:
        text = step(text, ctx)
    if text != original and not ctx.problems and page != "terms":
        text, n = re.subn(r"(Content last updated |Last updated: )[A-Z][a-z]+ \d{1,2}, \d{4}", lambda m: m.group(1) + TODAY, text)
        if n:
            ctx.ok(f"'last updated' date set to {TODAY}")
    if ctx.problems:
        ctx.log.append("  -> NOT written (fix the items marked ! and run again)")
    elif text == original:
        ctx.log.append("  -> nothing to do")
    elif not dry:
        path.write_bytes((text.replace("\n", "\r\n") if crlf else text).encode("utf-8"))
        ctx.log.append("  -> written")
    else:
        ctx.log.append("  -> would be written (dry run)")
    return ctx


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dry-run", action="store_true", help="show what would change without writing anything")
    args = ap.parse_args()
    if not (ROOT / "index.html").exists():
        sys.exit("Run this from the repository root (the folder that contains index.html).")
    if not (ROOT / "assets/site.js").exists():
        sys.exit("assets/site.js not found. Apply the previous update (apply_updates.py) first.")
    failed = 0
    for page in PAGES:
        print(f"{page}.html")
        ctx = process(page, args.dry_run)
        print("\n".join(ctx.log))
        failed += bool(ctx.problems)
    print("\n" + ("Dry run finished." if args.dry_run else "Done.") + (f" {failed} page(s) need attention (lines marked !)." if failed else " All pages OK."))
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
